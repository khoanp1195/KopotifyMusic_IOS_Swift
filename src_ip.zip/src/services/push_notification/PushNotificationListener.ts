import React, { useEffect } from 'react';
import messaging from '@react-native-firebase/messaging';
import PushNotification, { Importance } from "react-native-push-notification";
import { Alert, Platform } from "react-native";
import PushNotificationIOS from '@react-native-community/push-notification-ios';

export const PushNotificationListener = () => {
    const chanel = "VNA DCM";
    useEffect(() => {
        // Đăng ký để lắng nghe sự kiện push notification
        const unsubscribe = messaging().onMessage(async (remoteMessage: any) => {
            PushNotification.channelExists(chanel, function (exists: any) {
                if (!exists) {
                    PushNotification.createChannel(
                        {
                            channelId: chanel,
                            channelName: chanel,
                            channelDescription: chanel,
                            importance: Importance.HIGH,
                            vibrate: true,

                        }
                    );
                }
            });
            if (Platform.OS === 'android') {
                PushNotification.localNotification({
                    channelId: chanel,
                    channelName: chanel,
                    importance: Importance.HIGH,
                    vibrate: true,
                    message: "a",
                    title: "a",
                    showWhen: true,
                    userInfo: "a",
                    when: new Date().getTime(),
                    invokeApp: true,

                });
            }
            else {
                PushNotificationIOS.addNotificationRequest({
                    id: remoteMessage.messageId,
                    body: remoteMessage.notification.body,
                    title: remoteMessage.notification.title,
                    userInfo: remoteMessage.data,
                  });
            }
            console.log('Received a new push notification', JSON.stringify(remoteMessage));
        });

        // Hủy đăng ký listener khi component unmounts
        return unsubscribe;
    }, []);
    useEffect(() => {
        // Đăng ký để lắng nghe sự kiện push notification
        const unsubscribe = messaging().setBackgroundMessageHandler(async (remoteMessage: any) => {
            PushNotification.channelExists('VNA DCM', function (exists: any) {
                if (!exists) {
                    PushNotification.createChannel(
                        {
                            channelId: 'VNA DCM',
                            channelName: 'VNA DCM',
                            channelDescription: 'VNA DCM',
                            importance: Importance.HIGH,
                            vibrate: true,

                        }
                    );
                }
            });
            if (Platform.OS === 'android') {
                PushNotification.localNotification({
                    channelId: chanel,
                    channelName: chanel,
                    importance: Importance.HIGH,
                    vibrate: true,
                    message: "a",
                    title: "a",
                    showWhen: true,
                    userInfo: "a",
                    when: new Date().getTime(),
                    invokeApp: true,

                });
            }
            else {     
                
                messaging().onNotificationOpenedApp(remoteMessage => {
                console.log('onNotificationOpenedApp')
                // Alert.prompt(
                //     'Token  Push notification',
                //     'Token here',
                    
                //     [
                //         {
                //             text: 'OK',
                //             onPress: (password) => {
                //                 console.log('OK Pressed, password: ' + remoteMessage);
                //                 const editedDeviceToken = password;
                //             },
                //         },
                //     ],
                //     'plain-text',
                    
                // );
            });
              
                PushNotification.localNotification({
                    title: "a",
                    message: "a",
                    userInfo: "a",
                    invokeApp: true,
                });
            }
            console.log('Received a new push notification', JSON.stringify(remoteMessage));
        });

        // Hủy đăng ký listener khi component unmounts
        return unsubscribe;
    }, []);
    useEffect(() => {
        const getPushToken = async () => {
            const token = await messaging().getToken();
            console.log('Push Token:', token);
        };

        getPushToken();
    }, []);
    return null; // Không cần render gì cả
};

