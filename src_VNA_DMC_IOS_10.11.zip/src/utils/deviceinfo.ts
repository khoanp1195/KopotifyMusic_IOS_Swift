import AsyncStorage from '@react-native-async-storage/async-storage';
import DeviceInfo from 'react-native-device-info';
export async function getDeviceInfo() {
   let divceInfo = new FormData();
   

    const deviceToken = await AsyncStorage.getItem('deviceToken')
    const data =  JSON.stringify({
        AppVersion: DeviceInfo.getReadableVersion(),
        DeviceId: DeviceInfo.getDeviceId(),
        DeviceModel: DeviceInfo.getModel(),
        DeviceName: await DeviceInfo.getDeviceName(),
        DeviceOS: 1,
        DeviceOSVersion: DeviceInfo.getSystemVersion(),
        DevicePushToken: deviceToken
    });
    divceInfo.append("data",JSON.stringify(data));
    return divceInfo
}
