import {Image, StyleSheet, Text, TouchableOpacity, useWindowDimensions, View} from "react-native";
import {ListLoadMore} from "components/ListLoadMore";
import {getComments, getDocumentInteractive} from "services/api/apiProvider";
import {useSelector} from "react-redux";
import {currentUserStore} from "../../config/constants";
import React from "react";
import {FastImageCustom} from "components/FastImageCustom";
import FastImage from "react-native-fast-image";
import {dimensWidth} from "../../config/font";
import {Animations, format_dd_mm_yy, format_yy_mm_mm_dd_hh, getParameterUrlDoc, isNullOrEmpty} from "../../utils/function";
import {AppBarCustom} from "components/AppBarCustom";
import HTML from 'react-native-render-html';
import {Comment} from "services/database/models/Comment";
import {goToDocumentDetail} from "navigation/goToDetailNavigation";
import { SafeAreaView } from "react-native-safe-area-context";
import * as Animatable from 'react-native-animatable';

// @ts-ignore
export const CommentsScreen = ({navigation}) => {
    // @ts-ignore
    const currentLanguage = useSelector((state) => state.languages.currentLanguage);
    // @ts-ignore
    const translations = useSelector((state) => state.languages.translations);
    const currentTranslations = translations[currentLanguage];
    // @ts-ignore
    const {isConnected} = useSelector((state) => state.netInfo);
    const animation = Animations[Math.floor(Math.random() * Animations.length)]
    // @ts-ignore
    const itemRender = ({item, index}) => {
        const windowWidth = useWindowDimensions().width;
        const customHTMLElementModels = {
            label: {
                contentModel: 'flow', // Set the content model as 'flow' or 'block' as appropriate
                isOpaque: true, // Set to true if this element contains its own children
            },
        };
        // @ts-ignore
        return <Animatable.View 
        animation= {animation}
        duration={900}
        delay={index * 5}
        >
                 <TouchableOpacity onPress={() =>  goToDocumentDetail(navigation,item.ResourceUrl,isConnected,false)}>
            <View
                style={[{backgroundColor: index % 2 == 0 ? '#F1FAFF' : 'white'}, styles.root]}>
                <FastImageCustom urlOnline={item.Thumbnail}
                                 defaultImage={require('assets/images/icon_document_default.png')}
                                 styleImg={styles.img}
                                 resizeMode={FastImage.resizeMode.stretch}/>
                <View style={{flex: 1}}>
                    <Text style={styles.textTilte} numberOfLines={1}>{item.Title}</Text>
                    <Text numberOfLines={1} style={{marginTop: '8%',fontSize:11}}>
                    <HTML source={{html: item.Content}} contentWidth={windowWidth}  
                        // @ts-ignore
                          customHTMLElementModels={customHTMLElementModels}
                          ignoredDomTags={['label']}
                    />
                    </Text>
                   
                </View>
                <View>
                    {
                        !isNullOrEmpty(item.Created) && (<View>
                            <Text style={styles.textCreated}>{format_yy_mm_mm_dd_hh(item.Created)}</Text>
                        </View>)
                    }
                    {
                        !isNullOrEmpty(item.Status) && (<View style={{marginTop: 10}}>
                            <TextStatus item={item}/>
                        </View>)
                    }
                </View>
            </View>
        </TouchableOpacity>
        </Animatable.View>
   
    }
    // @ts-ignore
    const TextStatus = ({item}) => {
        const statusMap = {
            '-1': {backgroundColor: '#FFCDCD', text: currentTranslations.status_delete},
            '1': {backgroundColor: '#D1E9FF', text: currentTranslations.status_approving},
            '0': {backgroundColor: '#D1FDCE', text: currentTranslations.status_approved},
            default: {backgroundColor: '#FFCDCD', text: currentTranslations.status_refuse},
        };

        // @ts-ignore
        const statusInfo = statusMap[item.Status] || statusMap.default;

        return (
            <View style={{backgroundColor: statusInfo.backgroundColor,height:20, alignItems: 'center',alignContent:'center',justifyContent:'center'}}>
                <Text style={styles.textStatus}>{statusInfo.text}</Text>
            </View>
        );
    };
    const getData = async (limit: number, offet: number, isOnline: any) => {
        if (isOnline) {
            const data = await getComments(offet, limit, {
                "Parameters": {
                    "CommentTitle": null,
                    "CommentStorageCode": null,
                    "CommentVersion": null,
                    "CommentDate": null,
                    "CommentIsApproved": null,
                    "CommentStatus": null
                }
            });
            if (data != null) {
                Comment.insertOrUpdateAll(data);
            }
            return data;
        } else {
            return Comment.getAll(limit, offet);
        }
    }
    return <View style={{height:'100%',width:'100%', backgroundColor:'white'}}>
        <View style={{flex: 1, flexDirection: 'column'}}>
        <AppBarCustom onPress={null} navigation={navigation} title={currentTranslations.list_comment} RightControl={null}/>
        {/* <View style={{width: '100%', height: 0.75, backgroundColor: 'grey'}}/> */}
        <ListLoadMore numColumn={1} callData={getData} ItemRenderFlatlist={itemRender} enableMoreData={true} limit={15}/>
    </View>
    </View>
}
const styles = StyleSheet.create({
    root: {
        flexDirection: 'row',
        paddingHorizontal: 20,
        paddingVertical: 10
    },
    img: {
        height: 45,
        wight: 30,
        borderRadius: dimensWidth(0)
    },
    textStatus: {

        fontFamily: 'heritage_regular',
        lineHeight: 15,
        color:'black',
        fontSize:12
    },
    textTilte: {
        color: 'black',
        fontSize: 13,
        fontFamily: 'heritage_regular',
        lineHeight: 15,
        
    },
    textCreated: {
        fontFamily: 'heritage_regular',
        lineHeight: 15,
        color:'#7B7B7B',
        marginLeft:'10%',
        fontSize:11
    }
})

