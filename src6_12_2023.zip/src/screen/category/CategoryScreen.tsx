import { FlatList, ImageBackground, RefreshControl, StyleSheet, Text, TouchableOpacity, View } from "react-native";
import React, { useEffect, useState } from "react";
import { DocumentAreaCategory } from "services/database/models/DocumentAreaCategory";
import { currentUserStore } from "../../config/constants";
import { FastImageCustom } from "components/FastImageCustom";
import { getAllMasterData } from "services/api/apiProvider";
import { getModified, saveModified } from "../../utils/asyncStrorage";
import { FavoriteFolder } from "services/database/models/FavoriteFolder";
import { DocumentType } from "services/database/models/DocumentType";
import { addPositionStayCategory } from "../../redux/category/reducer";
import { useDispatch, useSelector } from "react-redux";
import { dimensWidth, windowWidth } from "../../config/font";
import FastImage from "react-native-fast-image";
import { setChildCategory, setIsAlreadySwitchSite } from "../../redux/app_bar_dasboard/reducer";
import { Animations, getCurrentTimeFormatted } from "../../utils/function";
import * as Animatable from 'react-native-animatable';

export const CategoryScreen = () => {
    const dispatch = useDispatch();
    const [data, setData] = useState([]);
    const [refreshing, setRefreshing] = useState(false);
    const currentLanguage = useSelector((state: any) => state.languages.currentLanguage);
    const { currentSite } = useSelector((state: any) => state.sub_site);
    const { isAlreadySwitchSite } = useSelector(
        (state: any) => state.appbar
    );
    const animation = Animations[Math.floor(Math.random() * Animations.length)]
    console.log('isAlreadySwitchSite - here ' + isAlreadySwitchSite)
    const fetchData = async () => {
       DocumentAreaCategory.getParentCategories().then((values) => {
            // @ts-ignore
            setData(values);
            setRefreshing(false); // Stop the refreshing indicator
        });
    };


    useEffect(() => {
        if (isAlreadySwitchSite) {
            DocumentAreaCategory.getParentCategories().then((values) => {
                setData(values);
                setRefreshing(false);
            });
            setTimeout(() => {
                dispatch(setIsAlreadySwitchSite(false));
            }, 3000);
        }
        else {
        }
    }, [isAlreadySwitchSite, currentLanguage, currentSite, data]);


    useEffect(() => {
        fetchData();
    }, [currentLanguage, currentSite]);


    const onRefresh = async () => {
        setRefreshing(true); // Start the refreshing indicator
        getAllMasterData("DocumentAreaCategory,FavoriteFolder,DocumentType", await getModified()).then(values => {
            DocumentAreaCategory.insertOrUpdateAll(values.DocumentAreaCategory);
            FavoriteFolder.insertOrUpdateAll(values.FavoriteFolder);
            DocumentType.insertOrUpdateAll(values.DocumentType);
            saveModified(getCurrentTimeFormatted());
            fetchData(); // Fetch data again when refreshing
        });

    };

    return (
        <ImageBackground source={require('assets/images/background.png')} style={styles.imgBackground}>
            <FlatList
                style={{ marginBottom: 60, paddingTop: 10, width: '100%' }}
                data={data}
                numColumns={2}
                renderItem={({ item, index }) => (

                    <TouchableOpacity onPress={() => {
                        dispatch(setChildCategory(true))
                        dispatch(addPositionStayCategory(item))
                    }}>
                        <Animatable.View
                            animation={animation}
                            duration={1000}
                            delay={index * 30}
                        >
                            <View style={styles.gridItem}>
                                <View style={styles.imageContainer}>
                                    <FastImageCustom
                                        resizeMode={'stretch'}
                                        urlOnline={(item["Image"] && JSON.parse(item["Image"]).Path) ? JSON.parse(item["Image"]).Path : 'null'}

                                        defaultImage={require('assets/images/icon_thumbnail_category_default.png')}
                                        styleImg={styles.image}
                                    />
                                </View>
                                <Text
                                    style={styles.title}>{currentLanguage !== 'en' ? item["Title"] : item["TitleEN"]}</Text>
                                <Text style={styles.description} numberOfLines={2}>{item["Description"]}</Text>
                            </View>
                        </Animatable.View>

                    </TouchableOpacity>
                )}
                keyExtractor={({ PrimaryKey }) => {
                    return PrimaryKey;
                }}
                refreshControl={
                    <RefreshControl
                        refreshing={refreshing}
                        onRefresh={onRefresh}
                    />
                }
            />
        </ImageBackground>
    );
};

const styles = StyleSheet.create({
    imageContainer: {
        padding: 10,
        backgroundColor: '#E2F9FF',
        alignItems: 'center',
        justifyContent: 'center',
        height: '60%',
        width:  '65%',
        borderRadius: 12,
        shadowColor: "#000",
        shadowOffset: {
          width: 3,
          height: 3,
        },
        shadowOpacity: 0.2,
        shadowRadius: 3.84,
        elevation: 5,
    },
    imgBackground: {
        height: '100%',
        width: "100%"
    },
    image: {
        marginLeft: 10,
        height: 90,
        width: 90,
    },
    title: {
        color: 'black',
        fontFamily: 'heritage_regular',
        lineHeight: 15,
        marginTop: 10,
        textAlign: 'center'
    },
    description: {
        fontFamily: 'heritage_regular',
        lineHeight: 15,
        marginTop: 10,
        textAlign: 'center',
        height: 50,
        color: '#7B7B7B',
        width: '80%'
    },
    container: {
        flex: 1,
        height: '100%',
        width: '100%',
        justifyContent: 'flex-start',
        alignItems: 'flex-start',
    },
    gridItem: {
        width: windowWidth / 2,
        height: 220,
        justifyContent: 'center',
        alignItems: 'center',
        marginTop: 0,
    },
    centeredItem: {
        alignSelf: 'center',
    },
});
