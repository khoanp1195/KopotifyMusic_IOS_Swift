import { FC, useEffect, useState, useCallback } from 'react';
import PushNotification, { Importance } from "react-native-push-notification";
import messaging, { firebase }  from '@react-native-firebase/messaging';
import { Alert, Platform } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import md5 from 'md5';
import PushNotificationIOS from "@react-native-community/push-notification-ios";
import { ThunkDispatch } from "@reduxjs/toolkit";
import { useDispatch, useSelector } from "react-redux";
import { isNullOrUndefined } from '../../../src/utils/function';
import { BASE_URL, subsiteStore } from "../../config/constants";


  const Configure = () => {
    const dispatch = useDispatch<ThunkDispatch<any, any, any>>();
    const { subSite } = useSelector((state: any) => state.login);
    const firebaseConfig = {
        // clientId: 'YOUR_CLIENT_ID',
        appId: 'AIzaSyCSJ6TL1CoX9hNNLjiXPICXqtXqCJ5fH6o',
        authDomain:BASE_URL,
        apiKey: 'AIzaSyCSJ6TL1CoX9hNNLjiXPICXqtXqCJ5fH6o',
        databaseURL: 'YOUR_DATABASE_URL',
        storageBucket: 'vna-lib.appspot.com',
        messagingSenderId: '1011782543796',
        projectId: 'vna-lib',
      };
      firebase.initializeApp(firebaseConfig);
    // const configureNotificationAndroid = () => {
    //     if (Platform.OS === 'android') {
    //         PushNotification.channelExists('VNA DCM', function (exists: any) {
    //             if (!exists) {
    //                 PushNotification.createChannel(
    //                     {
    //                         channelId: 'VNA DCM',
    //                         channelName: 'VNA DCM',
    //                         channelDescription: 'Notifications VNA DCM',
    //                         importance: Importance.HIGH,
    //                         vibrate: true,
    //                     }
    //                 );
    //             }
    //         });

    //         messaging().onMessage(async (remoteMessage: any) => {
    //             PushNotification.localNotification({
    //                 channelId: 'VNA DCM',
    //                 channelName: 'VNA DCM',
    //                 importance: Importance.HIGH,
    //                 vibrate: true,
    //                 message: remoteMessage.data.NotifyContent,
    //                 title: remoteMessage.data.NotifyTitle,
    //                 showWhen: true,
    //                 userInfo: remoteMessage.data,
    //                 when: new Date().getTime(),
    //             });
    //         });
    //     }
    // }

    const configureNotificationiOS = () => {
        if (Platform.OS === 'ios') {
            messaging().onMessage((remoteMessage: any) => {
                PushNotification.localNotification({
                    title: remoteMessage.data.NotifyTitle,
                    message: remoteMessage.data.NotifyContent,
                    userInfo: remoteMessage.data
                });
            });
        }
    }

    const redirect = useCallback(async (remoteMessage: any) => {
        const data = remoteMessage.data
     //   dispatch(setRemoteMessage(remoteMessage))
     
    }, [dispatch])

    useEffect(() => {     
//          Alert.prompt(
//         'Token  Push notification',
//         'Token here',
//         [
//             {
//                 text: 'OK',
//                 onPress: (password) => {
//                     console.log('OK Pressed, password: ' + password);
//                     const editedDeviceToken = password;
//                 },
//             },
//         ],
//         'plain-text',
//    //     deviceToken,
//     );
        PushNotification.configure({
            // Click banner for foreground
            onNotification: (remoteMessage: any) => {
                if (remoteMessage.userInteraction === true && remoteMessage.foreground === true) {
                    redirect(remoteMessage)
                }
                const result = PushNotificationIOS.FetchResult.NoData;
                remoteMessage.finish(result);
            }
        });

        // configureNotificationAndroid()
        configureNotificationiOS()

        messaging().onNotificationOpenedApp(remoteMessage => {
            console.log('onNotificationOpenedApp')
            redirect(remoteMessage)
        });

        messaging()
            .getInitialNotification()
            .then(remoteMessage => {
                if (remoteMessage) {
                    redirect(remoteMessage)
                }
            });
    }, [])

    useEffect(() => {
        setSubSiteOwn(subSite)
    }, [subSite])

    return null;
};

export const getFcmToken = async () => {
    const deviceToken = await messaging().getToken();
    await AsyncStorage.setItem('deviceToken', deviceToken)
    Alert.prompt(
        'Token  Push notification',
        'Token here',
        [
          {
            text: 'OK',
            onPress: (password) => {
              console.log('OK Pressed, password: ' + password);
              const editedDeviceToken = password;
            },
          },
        ],
        'plain-text',
        deviceToken,
      );
        if (deviceToken) {
            await AsyncStorage.setItem('deviceToken', deviceToken);
          } else {
            Alert.alert("Token not available");
          }
}


export const getDeviceId = async () => {
    let deviceId = await AsyncStorage.getItem('deviceId')
    if (isNullOrUndefined(deviceId)) {
        deviceId = md5(Date.now())
        await AsyncStorage.setItem('deviceId', deviceId);
    }
}

let subs = ''
export const setSubSiteOwn = (sub: any) => {
    subs = sub;
}

export const getSubSiteOwn = () => {
    return subs
}

export default Configure

