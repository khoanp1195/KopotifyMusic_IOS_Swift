import { FlatList, ImageBackground, RefreshControl, ScrollView, StyleSheet, Text, TouchableOpacity, View } from "react-native";
import React, { useEffect, useState } from "react";
import { DocumentAreaCategory } from "services/database/models/DocumentAreaCategory";
import { currentUserStore } from "../../config/constants";
import { FastImageCustom } from "components/FastImageCustom";
import { getAllMasterData } from "services/api/apiProvider";
import { getModified, saveModified } from "../../utils/asyncStrorage";
import { FavoriteFolder } from "services/database/models/FavoriteFolder";
import { DocumentType } from "services/database/models/DocumentType";
import { addPositionStayCategory } from "../../redux/category/reducer";
import { useDispatch, useSelector } from "react-redux";
import { dimensWidth, windowWidth } from "../../config/font";
import FastImage from "react-native-fast-image";
import { setChildCategory, setIsAlreadySwitchSite } from "../../redux/app_bar_dasboard/reducer";
import { Animations, getCurrentTimeFormatted } from "../../utils/function";
import * as Animatable from 'react-native-animatable';
import SortableGridView from 'react-native-sortable-gridview'
export const CategoryScreen = () => {
    const dispatch = useDispatch();
    const [data, setData] = useState([]);
    const [refreshing, setRefreshing] = useState(false);
    const currentLanguage = useSelector((state: any) => state.languages.currentLanguage);
    const { currentSite } = useSelector((state: any) => state.sub_site);
    const { isAlreadySwitchSite } = useSelector(
        (state: any) => state.appbar
    );
    const animation = Animations[Math.floor(Math.random() * Animations.length)]
    console.log('isAlreadySwitchSite - here ' + isAlreadySwitchSite)
    const fetchData = async () => {
        DocumentAreaCategory.getParentCategories().then((values) => {
            // @ts-ignore
            setData(values);
            setRefreshing(false); // Stop the refreshing indicator
        });
    };


    useEffect(() => {
        if (isAlreadySwitchSite) {
            DocumentAreaCategory.getParentCategories().then((values) => {
                setData(values);
                setRefreshing(false);
            });
            setTimeout(() => {
                dispatch(setIsAlreadySwitchSite(false));
            }, 3000);
        }
        else {
        }
    }, [isAlreadySwitchSite, currentLanguage, currentSite, data]);


    useEffect(() => {
        fetchData();
    }, [currentLanguage, currentSite]);


    const onRefresh = async () => {
        setRefreshing(true); // Start the refreshing indicator
        getAllMasterData("DocumentAreaCategory,FavoriteFolder,DocumentType", await getModified()).then(values => {
            DocumentAreaCategory.insertOrUpdateAll(values.DocumentAreaCategory);
            FavoriteFolder.insertOrUpdateAll(values.FavoriteFolder);
            DocumentType.insertOrUpdateAll(values.DocumentType);
            saveModified(getCurrentTimeFormatted());
            fetchData(); // Fetch data again when refreshing
        });

    };

    return (
        <ImageBackground source={require('assets/images/background.png')} style={styles.imgBackground}>

                <SortableGridView
                    data={data}
                    numPerRow={5} // let each row has four items. Default is 3
                    aspectRatio={1.2} // let height = width * 1.2. Default is 1
                    gapWidth={8} // let the gap between items become to 8. Default is 16
                    paddingTop={8} // let container's paddingTop become to 8. Default is 16
                    paddingBottom={8} // let container's paddingBottom become to 8. Default is 16
                    paddingLeft={8} // let container's paddingLeft become to 8. Default is 16
                    paddingRight={8} // let container's paddingRight become to 8. Default is 16

                    refreshControl={
                        <RefreshControl
                            refreshing={refreshing}
                            onRefresh={onRefresh}
                        />
                    }
                    keyExtractor={({ PrimaryKey }) => {
                        return PrimaryKey;
                    }}
                    renderItem={(item, index) => {
                        const jsonString = `${item?.Image}`;
                        const jsonObject = JSON.parse(jsonString);
                        const path = jsonObject.Path;
                        return (
                            <Animatable.View
                                animation={animation}
                                duration={1000}
                                delay={index * 300}
                            >
                                <TouchableOpacity style={[styles.item, { backgroundColor: '#E2F9FF' }]}
                                    onPress={() => {
                                        dispatch(setChildCategory(true))
                                        dispatch(addPositionStayCategory(item))
                                    }}>
                                    <View style={styles.text}>
                                        <FastImage
                                            defaultImage={require('assets/images/icon_thumbnail_category_default.png')}
                                            style={styles.image}
                                            source={{ uri: (item["Image"] && JSON.parse(item["Image"]).Path) ? JSON.parse(item["Image"]).Path : 'null' }}
                                        />
                                    </View>
                                </TouchableOpacity>
                                <View style={{ marginTop: 122, marginLeft: '8%', justifyContent: 'center', alignItems: 'center' }}>
                                    <Text style={[{ top: '50%', width: 140, color: item.color, position: 'absolute', textAlign: 'center' }]} numberOfLines={1}>
                                        {currentLanguage !== 'en' ? item["Title"] : item["TitleEN"]}
                                    </Text>
                                    <Text style={[{ height: 50, marginTop: 89, color: 'gray', width: 190, textAlign: 'center' }]}
                                        numberOfLines={2}>{item.Description}</Text>
                                </View>

                            </Animatable.View >

                        )
                    }}
                />
                {/* <FlatList
    //   style={{ marginBottom: 50, paddingTop: 10, width: '100%' }}
    contentContainerStyle={{ marginLeft: 5 }}
    data={data}
    numColumns={5}
    renderItem={({ item, index }) => (

        <TouchableOpacity onPress={() => {
            dispatch(setChildCategory(true))
            dispatch(addPositionStayCategory(item))
        }}>
            <Animatable.View
                animation={animation}
                duration={1000}
                delay={index * 30}
            >
                <View style={styles.gridItem}>
                    <View style={styles.imageContainer}>
                        <FastImageCustom
                            resizeMode={'stretch'}
                            urlOnline={(item["Image"] && JSON.parse(item["Image"]).Path) ? JSON.parse(item["Image"]).Path : 'null'}

                            defaultImage={require('assets/images/icon_thumbnail_category_default.png')}
                            styleImg={styles.image}
                        />
                    </View>
                    <Text
                        style={styles.title}>{currentLanguage !== 'en' ? item["Title"] : item["TitleEN"]}</Text>
                    <Text style={styles.description} numberOfLines={2}>{item["Description"]}</Text>
                </View>
            </Animatable.View>

        </TouchableOpacity>
    )}
    keyExtractor={({ PrimaryKey }) => {
        return PrimaryKey;
    }}
    refreshControl={
        <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
        />
    }
/> */}
            </ImageBackground>
    );
};

const styles = StyleSheet.create({
    imageContainer: {
        flexDirection: 'row',
        backgroundColor: 'white',
        borderRadius: 3,
        width: 185,
        height: 270,
        borderColor: 'lightgray',
        borderWidth: 0.5,
        position: 'absolute',
    },
    imgBackground: {
        height: '100%',
        width: "100%"
    },
    image: {
        shadowColor: "#000",
        shadowOffset: {
            width: 0,
            height: 2,
        },
        shadowOpacity: 0.23,
        shadowRadius: 2.62,
        height: dimensWidth(40),
        width: dimensWidth(40), alignContent: 'center',
        elevation: 4,
        borderRadius: 8,
    },
    title: {
        color: 'black',
        fontFamily: 'heritage_regular',
        lineHeight: 15,
        marginTop: 10,
        textAlign: 'center'
    },
    description: {
        fontFamily: 'heritage_regular',
        lineHeight: 15,
        marginTop: 10,
        textAlign: 'center',
        height: 50,
        color: '#7B7B7B',
        width: '80%'
    },
    container: {
        flex: 1,
        height: '100%',
        width: '100%',
        justifyContent: 'flex-start',
        alignItems: 'flex-start',
    },
    gridItem: {
        flexDirection: 'row',
        backgroundColor: 'rgba(0, 0, 0, 0)',
        marginHorizontal: dimensWidth(15),
        borderRadius: 5,
        width: 200,
        height: 250,

        paddingHorizontal: '6.6%',
        marginLeft: 31,
        shadowColor: "#000",
        shadowOffset: {
            width: 0,
            height: 2,
        },
        shadowOpacity: 0.23,
        shadowRadius: 2.62,
        elevation: 4,
    },
    centeredItem: {
        alignSelf: 'center',
    },
    text: {
        justifyContent: 'center',
        alignContent: 'center',
        alignItems: 'center'
    },
    item: {
        borderRadius: 5,
        shadowColor: "#000",
        flexDirection: 'column',
        shadowOffset: {
            width: 5,
            height: 5,
        },
        shadowOpacity: 0.5,
        shadowRadius: 3.84,

        elevation: 5,
        backgroundColor: 'white',
        position: 'absolute',
        width: ' 70%',
        height: 160,
        top: 0,
        left: '17%',
        right: 0,
        bottom: 0,
        marginTop: 20,
        justifyContent: 'center',
        alignItems: 'center',
        alignContent: 'center'

    },
});
