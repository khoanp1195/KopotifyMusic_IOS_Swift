import { createSlice } from '@reduxjs/toolkit';
import { Subsite, subsiteStore } from 'helpers/Constants';


const subSiteSlice = createSlice({
    name: 'sub_site',
    initialState: {
        currentSite:Subsite,
        isVisibleSubSite:false
    },
    reducers: {
        setSubSite: (state, action) => {
            subsiteStore.setSubsite(action.payload)
            state.currentSite= action.payload;
        },
        showSubSite: (state) => {
            state.isVisibleSubSite = true;
        },
        hideSubSite: (state) => {
            state.isVisibleSubSite = false;
        },
    },
});

export const {
    setSubSite,
    showSubSite,
    hideSubSite }
    = subSiteSlice.actions;
const {reducer}=subSiteSlice;
export default  reducer;
