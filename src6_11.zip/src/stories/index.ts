import loginReducer from './login/reducer';
import dashBoardReducer from './dashboard/reducer';
import commentReducer from './profile/comment/reducer';
import categoryReducer from './category/reducer';
import languagesReducer from './languages/reducer';
import recentlyReducer from './dashboard/recentlyReducer';
import searchResultReducer from './lookup/search_result/reducer'
import {
  combineReducers,
  configureStore,
  getDefaultMiddleware,
} from '@reduxjs/toolkit';
import { createSelectorHook, useDispatch } from 'react-redux';
import { createTransform, persistReducer, persistStore } from 'redux-persist';
import { PersistedState } from 'redux-persist/es/types';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { LogBox } from 'react-native';
import Flatted from "flatted";
import 'react-native-gesture-handler';
import autoMergeLevel2 from 'redux-persist/es/stateReconciler/autoMergeLevel2';
import mostViewReducer from './dashboard/mostViewReducer';
import documentNewReducer from './dashboard/documentNewReducer'
import favoriteReducer from './dashboard/favoriteReducer';
import netInfoReducer from './net_info/reducer';
import subSiteReducer from './subsite/reducer'
import favoritesScreenReducer from './favorite/reducer'
import appBarReducer from './app_bar_dasboard/reducer'
const PersistVersion = 1;
const rootReducer = combineReducers({
  login: loginReducer,
  dashboard: dashBoardReducer,
  category: categoryReducer,
  languages: languagesReducer,
  comment: commentReducer,
  recentlyViewedDocument: recentlyReducer,
  search_result:searchResultReducer,
  sub_site:subSiteReducer,
  documentMostView: mostViewReducer,
  documentFavorite: favoriteReducer,
  viewDocumentNew: documentNewReducer,
  netInfo: netInfoReducer,
  favoritesScreen: favoritesScreenReducer,
  appbar:appBarReducer,
});
const transformCircular = createTransform(
  (inboundState, key) => Flatted.stringify(inboundState),
  (outboundState, key) => Flatted.parse(outboundState),
)
const persistConfig: any = {
  key: 'VnaDcm',
  storage: AsyncStorage,
  whitelist: [
    'auth',
    'unReadNotify',
    'recentlyViewedDocument',
    'documentMostView',
    'viewDocumentNew',
    'languages',
    'sub_site'],
  blacklist: [],
  transforms:[transformCircular],
  stateReconciler: autoMergeLevel2,
  version: PersistVersion,
  migrate: (state: PersistedState) => {
    if (PersistVersion !== state?._persist.version) {
      return Promise.resolve(null as unknown as PersistedState);
    }
    return Promise.resolve(state);
  },
};
const persistedReducer = persistReducer(persistConfig, rootReducer);

LogBox.ignoreLogs(['Warning: ...']); //Hide warnings

LogBox.ignoreAllLogs();//Hide all warning notifications on front-end

const store = configureStore({
  devTools: process.env.NODE_ENV === 'development',
  reducer: persistedReducer,
  // @see httpss://redux-toolkit.js.org/usage/usage-guide#use-with-redux-persist
  middleware: getDefaultMiddleware({
    serializableCheck: false,
  }),
});
export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;
// export const useAppSelector = createSelectorHook<RootState>();
export const useAppDispatch = () => useDispatch<AppDispatch>();
export const persistor = persistStore(store);
export default store;
