import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import { RESONSE_STATUS_SUCCESS } from 'helpers/Constants';
import { isNullOrUndefined } from 'helpers/Functions';
import { get } from '../../../services/ApiServices';
import axios from 'axios';

export const GetListCommentDocument = createAsyncThunk(
    'home/GetListCommentDocument',
    async (payload: any) => {
      const { limit, offset } = payload;
      const LangId = 1066;
      try {
        let data = new FormData();
        const jsonData = {
          Parameters: {
            CommentTitle: null,
            CommentStorageCode: null,
            CommentVersion:null,
            CommentDate:null,
            CommentIsApproved: null,
            CommentStatus: null
          }
        };
      //https://vnadmsuatportal.vuthao.com/psd/API/ApiMobile.ashx?func=GetCommentByUser&Params=Offset%2CLimit&Offset=0&Limit=20&enc=RSA
        data.append("data", JSON.stringify(jsonData));
        let config = {
            method: 'post',
            url: `https://vnadmsuatportal.vuthao.com/psd/API/ApiMobile.ashx?func=GetCommentByUser&Params=Offset%2CLimit&Offset=${offset}&Limit=${limit}`,
            data: data,
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'multipart/form-data',
            },
        };
        const response = await axios(config);
        console.log('responseGetListCommentDocument', response?.data);
  
        return {
          totalRecord: response?.data.data.MoreInfo[0].totalRecord,
          dataListComment: response?.data?.data?.Data,
          offset
        }
      } catch (ex) {
        console.error('Error in fetchGetWorkflowItem:', ex);
      }
    }
  )
  
const listcommentSlice = createSlice({
    name: 'listcomment',
    initialState: {
        listcommentDocs: {
            data: [],
            isLoading: false,
            totalRecord: 0
        }
    },
    reducers: {
        resetlistcommentAction(state, action) {
            return {
                ...state,
                listcommentDocs: {
                    data: [],
                    isLoading: false,
                    totalRecord: 0
                }
            };
        },
    },
    extraReducers: builder => {
        builder.
            addCase(GetListCommentDocument.pending, (state: any, action: any) => {
                state.listcommentDocs.isLoading = true
            }).
            addCase(GetListCommentDocument.fulfilled, (state: any, action: any) => {
                const { Offset } = action.payload
                state.listcommentDocs = {
                    data: Offset === 0 ? action.payload.data : state.listcommentDocs.data.concat(action.payload.data),
                    totalRecord: action.payload.totalRecord,
                    isLoading: false,
                }
            }).
            addCase(GetListCommentDocument.rejected, (state: any, action: any) => {
                state.listcommentDocs.isLoading = false
            })
    }
});
export const { resetlistcommentAction } = listcommentSlice.actions;
const { reducer } = listcommentSlice;
export default reducer;
