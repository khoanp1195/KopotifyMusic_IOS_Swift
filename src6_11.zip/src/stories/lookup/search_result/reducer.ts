// textSearchSlice.js
import { createSlice } from '@reduxjs/toolkit';
import { getCurrentTimeFormatted, isNullOrEmpty } from 'helpers/Functions';
import {SearchHistory} from "../../../database/models/SearchHistory";

const searchResultSlice = createSlice({
    name: 'search_result',
    initialState: {
        searchTerm: '', // Initial search term is empty
    },
    reducers: {
        setSearchTerm: (state, action) => {
            state.searchTerm = action.payload;
            if (!isNullOrEmpty(action.payload)) {
                SearchHistory.insertOrUpdateAll([{
                    Title: action.payload,
                    Modified: getCurrentTimeFormatted()
                }])
            }
        },
    },
});

export const { setSearchTerm } = searchResultSlice.actions;
const {reducer}=searchResultSlice;
export default reducer;
