import React, { useCallback, useEffect, useState } from 'react';
import { View, Text, StyleSheet, Image, TouchableOpacity, Alert, ScrollView, RefreshControl } from 'react-native';
import { ThunkDispatch } from "@reduxjs/toolkit";
import { useDispatch, useSelector } from 'react-redux';
import AsyncStorage from '@react-native-async-storage/async-storage';
import SortableGridView from 'react-native-sortable-gridview'
import { GetCategoryFromServer, setCategoryDocAction } from 'stories/category/reducer';
import { Header } from '@react-navigation/stack';
import FastImage from 'react-native-fast-image';
import { dimensWidth, windowHeight, windowWidth } from 'helpers/Constants';
import HeaderWithAvatar from 'components/HeaderWithAvatar';
import styles from './Aplication.Style';
import { fetchCurrentUsers } from 'stories/dashboard/reducer';
import { RootState } from 'stories/index';
import { DocumentAreaCategory } from '../../database/models/DocumentAreaCategory';
import * as Animatable from 'react-native-animatable';
import { Animations, getCurrentTimeFormatted } from 'helpers/Functions';
import { getModified, saveModified } from '../../utils/asyncStrorage';
import { getAllMasterData } from 'services/apiProvider';
import { DocumentType } from '../../database/models/DocumentType';
type Props = {
  navigation: any;
  route: any;
};

const ApplicationScreen = ({ navigation }: Props) => {
  const dispatch = useDispatch<ThunkDispatch<any, any, any>>();
  const [dataCategoryState, setdataCategoryState] = useState([]);
  const [dataMenuCategoryState, setdataMenuCategoryState] = useState([]);
  const [refreshing, setRefreshing] = useState(false);
  const dataCategory = useSelector(
    (state: any) => state.category
  )
  const {currentSite} = useSelector((state: any) => state.sub_site);
  const [data, setData] = useState([]);
  const currentUser = useSelector((state: any) => state.dashboard);
  const { languages, languagesText } = useSelector((state: RootState) => state.languages);
  const {
    dataCurrentUser,
  } = currentUser;

  const fetchData = () => {
    // Simulate fetching data from an API, replace with your actual data fetching logic
    DocumentAreaCategory.getParentCategories().then((values) => {
        // @ts-ignore
        setData(values);
        setRefreshing(false); // Stop the refreshing indicator
    });
};

useEffect(() => {
  fetchData();
}, [languagesText,currentSite]);

  //fetchGetDataCategory
  useEffect(() => {
    const langId = languagesText === 'EN' ? 1033 : 1066
    dispatch(GetCategoryFromServer(langId))
  }, [dispatch, languagesText]);

  useEffect(() => {
    setdataCategoryState(dataCategory?.dataCategory);
    // dispatch(setCategoryDocAction(dataCategory?.dataCategory));
  }, [dataCategory])
  console.log('dataCategory =>> ' + dataCategoryState)
  const filteredCategories = dataCategory?.dataCategory.filter((category: { ParentId: null; }) => category.ParentId === null);
  //lstCategories = lstCategories.FindAll(o => o.ParentId == null);
  //ParentId IS NOT NULL AND ParentId = " + cateParent.ID + " Order By Rank,
  useEffect(() => {
    dispatch(fetchCurrentUsers());
  }, [languagesText])






  const onRefresh = async () => {
    const langId = languagesText === 'EN' ? 1033 : 1066
    // dispatch(GetCategoryFromServer(langId))
    getAllMasterData("DocumentAreaCategory,FavoriteFolder,DocumentType", await getModified()).then(values => {
      DocumentAreaCategory.insertOrUpdateAll(values.DocumentAreaCategory);
      DocumentType.insertOrUpdateAll(values.DocumentType);
      saveModified(getCurrentTimeFormatted());
      fetchData(); // Fetch data again when refreshing
  });
  };

  //gotoDetailPress
  const gotoDetailPress = useCallback(
    (item: any) => {
      const cateParentID = item?.ID
      const filteredCategories = dataCategory?.dataCategory.filter((category: { ParentId: null; }) => category.ParentId === cateParentID);
      // Sort the filtered list by Rank
      filteredCategories.sort(({ a, b }: any) => a?.Rank - b?.Rank);

      console.log('filteredCategoriesMenu =>  ', + filteredCategories)
      navigation.navigate({
        name: "DoucumentListView",
        params: {
          id: item?.ID,
          parenttitle: item?.Title,
          item,
          filteredCategories,
          cateParentID,
          isClickLeftMenu: false,
          isFirst: true,
          dataCategory: dataCategory?.dataCategory
        },
      });
    },
    [],
  )
  const animation = Animations[Math.floor(Math.random() * Animations.length)]


  return (
    <View style={styles.container}>
      <FastImage
        style={styles.vnaBackgroundImage}
        resizeMode='contain'
        source={require('../../../src/assets/images/img_background_home.png')}
      />
      <HeaderWithAvatar item={currentUser.dataCurrentUsers}
        title={languages.tab_category}
        urlOnline={currentUser.dataCurrentUsers?.ImagePath}
        dataCategory={dataCategory?.dataCategory}
      />

      <ScrollView style={{ marginLeft: -10 }}>
        <SortableGridView
          data={filteredCategories}
          numPerRow={5} // let each row has four items. Default is 3
          aspectRatio={1.2} // let height = width * 1.2. Default is 1
          gapWidth={8} // let the gap between items become to 8. Default is 16
          paddingTop={8} // let container's paddingTop become to 8. Default is 16
          paddingBottom={8} // let container's paddingBottom become to 8. Default is 16
          paddingLeft={8} // let container's paddingLeft become to 8. Default is 16
          paddingRight={8} // let container's paddingRight become to 8. Default is 16
          onDragStart={() => {
            console.log('CustomLayout onDragStart');
          }}
          onDragRelease={(data) => {
            console.log('CustomLayout onDragRelease', data);
          }}
          refreshControl={
            <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor='#0054AE' />
          }
          renderItem={(item, index) => {
            const jsonString = `${item?.Image}`;
            const jsonObject = JSON.parse(jsonString);
            const path = jsonObject.Path;
            return (
              <Animatable.View 
              animation= {animation}
              duration={1000}
              delay={index * 300}
              >
                <TouchableOpacity onPress={() => gotoDetailPress(item)} style={[styles.item, { backgroundColor: '#E2F9FF' }]}>
                  <View style={styles.text}>
                    <FastImage style={styles.img_content}
                      source={{ uri: path }}
                    />
                  </View>
                </TouchableOpacity>
                <View style={{ marginTop: 122, marginLeft: '8%', justifyContent: 'center', alignItems: 'center' }}>
                  <Text style={[{ top: '50%', width: 140, color: item.color, position: 'absolute', textAlign: 'center' }]} numberOfLines={1}>
                    {languagesText == 'EN' ? item.TitleEN : item.Title}
                  </Text>
                  <Text style={[{ height: 50, marginTop: 89, color: 'gray', width: 190, textAlign: 'center' }] }numberOfLines={2}>{item.Description}</Text>
                </View>

              </Animatable.View >

            )
          }}
        />
      </ScrollView>


    </View>
  );
};


export default ApplicationScreen;
