import React, { useCallback, useEffect, useRef, useState } from 'react';
import { View, Text, StyleSheet, Image, TouchableOpacity, Alert, ScrollView, FlatList, RefreshControl, Animated } from 'react-native';
import { ThunkDispatch } from "@reduxjs/toolkit";
import { useDispatch, useSelector } from 'react-redux';
import AsyncStorage from '@react-native-async-storage/async-storage';
import SortableGridView from 'react-native-sortable-gridview'
import { GetCategoryFromServer, GetListSubCategory } from 'stories/category/reducer';
import FastImage from 'react-native-fast-image';
import { FontSize, dimensWidth, windowHeight, windowWidth } from 'helpers/Constants';
import HeaderWithAvatar from 'components/HeaderWithAvatar';
import { fetchCurrentUsers, getAutoLoginMobile } from 'stories/dashboard/reducer';
import { RootState } from 'stories/index';
import styles from './DoucumentListView.Style';
import HeaderDetail from 'components/HeaderDetail';
import Header from 'components/Header';
import colors from 'helpers/Colors';
import FastImageCustom from 'components/FastImageCustom';
import ModalLeftMenu from './ModalLeftMenu';
import { Animations, arrayIsEmpty, format_dd_mm_yy } from 'helpers/Functions';
import NoDataView from 'components/NoDataView';
import { Col, Row } from 'react-native-flex-grid';
import TextCusTom from 'components/TextCusTom';
import { useNavigation } from '@react-navigation/native';
import LoadingDots from "react-native-loading-dots";
import { Q } from '@nozbe/watermelondb';
import { database } from '../../../../App';
import { DocumentAreaCategory } from '../../../database/models/DocumentAreaCategory';
import * as Animatable from 'react-native-animatable';

type Props = {
  navigation: any
  route: any
}
// @ts-ignore
const LeftMenu = ({isOpen, onClose, onMenuItemClick, menuItems}) => {
  const slideAnimation = useRef(new Animated.Value(0)).current;
  const currentLanguage = useSelector((state: any) => state.languages.currentLanguage);
  const closeMenu = () => {
      Animated.timing(slideAnimation, {
          toValue: -200,
          duration: 300,
          useNativeDriver: true,
      }).start(() => {
          onClose();
      });
  };

  if (isOpen) {
      slideAnimation.setValue(0);
  }

  return (
      <Animated.View
          style={[
              styles.menuContainer,
              isOpen ? styles.openMenu : styles.closedMenu,
              {transform: [{translateX: slideAnimation}]},
          ]}
      >
          {
              menuItems.length != 0 ? menuItems.map((item: any) => (
                      <TouchableOpacity
                          key={item.PrimaryKey}
                          onPress={() => {
                              onMenuItemClick(item);
                              closeMenu(); // Close the menu when an item is clicked
                          }}
                      >
                          <Text
                              style={styles.menuItem}>{currentLanguage !== 'en' ? item["Title"] : item["TitleEN"]}</Text>
                      </TouchableOpacity>
                  )) :
                  <NoDataView/>
          }
      </Animated.View>
  );
};




const DoucumentListView = ({ route }: Props) => {
  const dispatch = useDispatch<ThunkDispatch<any, any, any>>();
  const [dataCategoryState, setdataCategoryState] = useState([]);
  const dataSubCategory = useSelector(
    (state: any) => state.category
  )
  const currentUser = useSelector((state: any) => state.dashboard);
  const { languages, languagesText } = useSelector((state: RootState) => state.languages);
  const {
    dataCurrentUser,
  } = currentUser;
  const [visibleModalLeftMenu, setvisibleModalLeftMenu] = useState(false);
  const [dataSubCategoryState, setdataSubCategoryState] = useState([]);
  const { id } = route.params
  const { parenttitle } = route.params
  const { item } = route.params
  const { cateParentID } = route.params
  const { filteredCategories } = route.params
  const {dataCategory} = route.params
  const {data} = route.params
  const { isFirst } = route.params
  const [filteredCategoriesState, setfilteredCategoriesState] = useState([]);
  const { titleChild } = route.params
  const [loading, setloading] = useState(true)
  const [error, setError] = useState(null)
  const [Offset, setOffset] = useState(0);
  const [imageData, setImageData] = useState(null);
  const [isTypeGrid, setIsTypeGrid] = useState(false)
  const navigation = useNavigation()
  const defaultThumbnailUri = '../../../assets/images/icon_thumbDefault.png';
  const { isClickLeftMenu } = route.params
  const [refreshing, setRefreshing] = useState(false);
  const isLoadingdataSubCategory = useSelector((state: any) => state.category)
  const [menus, setMenus] = useState();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const animation = Animations[Math.floor(Math.random() * Animations.length)]

     // @ts-ignore
     const positionStayCategory = useSelector((state: any) => state.category);
     useEffect(() => {
      try {
        DocumentAreaCategory.getChildByParentId(positionStayCategory[positionStayCategory.length - 1].PrimaryKey).then(values => {
          setMenus(values)
     })
        } catch (e) {
        console.log('DocumentAreaCategory  - Error ')
        }
   
  }, [positionStayCategory]);
console.log("MenuData Here e=>> " + menus)


  useEffect(() => {
    dispatch(fetchCurrentUsers());
  }, [languagesText])
  const onReModalPress = useCallback(() => {
    setvisibleModalLeftMenu(false);
  }, [visibleModalLeftMenu, filteredCategories]);

  const fetchGetListSubcategoryRequest = useCallback((payload: any) => {
    dispatch(GetListSubCategory(payload));
  }, [dispatch])
  //GetListSubCategory
  useEffect(() => {
    const langId = languagesText === 'EN' ? 1033 : 1066
    fetchGetListSubcategoryRequest({ limit: 20, offset: Offset, id, langId })
  }, [fetchGetListSubcategoryRequest]);// languagesText, Offset, id

  // const fetchGetListSubcategoryRequest = useCallback(async () => {
  //   try {
  //     const langId = languagesText === 'EN' ? 1033 : 1066;
  //     await dispatch(GetListSubCategory({ limit: 20, offset: Offset, id, langId }))
  //     setloading(false)
  //   }
  //   catch (err: any) {
  //     setError(err)
  //     setloading(false)
  //   }
  // }, [dispatch, languagesText, Offset, id])
  

  // useEffect(() => {
  //   fetchGetListSubcategoryRequest();
  // }, [fetchGetListSubcategoryRequest]);

  const onRefresh = useCallback(() => {
    setRefreshing(true);
    setOffset(0);
    const langId = languagesText === 'EN' ? 1033 : 1066
     dispatch(GetListSubCategory({ limit: 20, offset: Offset, id, langId }))
  }, [languagesText,refreshing]);

  useEffect(() => {
    setdataSubCategoryState(dataSubCategory.dataSubCategory);
    if (refreshing) setRefreshing(false);
  }, [dataSubCategory])

  const onPressLeftMenu = useCallback(() => {
    const cateParentID = item?.ID
    const filteredCategories = dataCategory.filter((category: { ParentId: null; }) => category.ParentId === cateParentID);
    filteredCategories.sort(({ a, b }: any) => a?.Rank - b?.Rank);
    setfilteredCategoriesState(filteredCategories)
    setvisibleModalLeftMenu(true);
  }, [visibleModalLeftMenu, filteredCategories])

  const onPressChangeType = useCallback(() => {
    setIsTypeGrid(true);
  }, [isTypeGrid])

  const onPressChangeType2 = useCallback(() => {
    setIsTypeGrid(false);
  }, [isTypeGrid])
  const renderSeparator = () => {
    return <View style={styles.separator} />;
  };

  const ItemDoc = ({ item, index,animation }: any) => {
    const formatDate = format_dd_mm_yy(item?.IssueDate)
    const idOdd = index % 2 === 0;
    const thumbnailUri = item.Thumbnail ? item.Thumbnail : defaultThumbnailUri;
    return (
      <Animatable.View 
      animation= {animation}
      duration={1000}
      delay={index * 300}
      >
        {isTypeGrid ?
          (<View style={[styles.viewScrollViewGrid, idOdd && { backgroundColor: '#F1FAFF' }]} >
            <View key={index} style={{ marginVertical: 5 }} >
              <TouchableOpacity onPress={() => gotoDetailPress(item?.StorageCode)} >
                <Row style={styles.cellContent}>
                  <Col style={{ padding: 10, width: 210, flexDirection: 'row' }}>
                    <FastImage style={{
                      height: dimensWidth(15),
                      width: dimensWidth(15),
                      marginLeft: dimensWidth(10),
                    }}
                    source={{ uri: thumbnailUri }}
                    />
                    <Text style={{ width: 550, marginLeft: 20, marginTop: 10, color: '#2376E0', width: 200 }}>{item.Code}</Text>
                  </Col>
                  <Col style={{ marginLeft: 10, justifyContent: 'center' }}>
                    <Text style={{ textAlign: 'center' }}>{item.Title}</Text>
                  </Col>
                  <Col style={{ justifyContent: 'center' }}>
                    <Text style={{ marginLeft: '20%', width: 80 }}>{formatDate}</Text>
                  </Col>
                  <Col style={{ justifyContent: 'center' }}>
                    <Text style={{ marginLeft: '10%', width: 80 }}>{formatDate}</Text>
                  </Col>
                </Row>
              </TouchableOpacity>

            </View>
          </View>
          ) :

          (<View>
            <TouchableOpacity onPress={() => gotoDetailPress(item?.StorageCode)} style={[stylesDoucument.itemNewDocuments, { backgroundColor: 'rgba(0, 0, 0, 0)' }]}>
              <View style={stylesDoucument.itemNewDocumentsChild}>
                <FastImageCustom urlOnline={item?.Thumbnail} styleImg={styles.itemNewDocumentsChild} />
              </View>
              <TextCusTom i18nKey={item?.Title} style={stylesDoucument.titleItemNewDoc} numberOfLines={2} />
              <TextCusTom i18nKey={formatDate} style={stylesDoucument.dateItemNewDoc} />
            </TouchableOpacity>
          </View>)}

      </Animatable.View >

    );
  };

  //gotoDetailPress
  const gotoDetailPress = useCallback(
    (ResourceUrl: any) => {
      dispatch(getAutoLoginMobile());
      navigation.navigate({
        name: "DashboardDetailScreen",
        params: { urlThongBao: ResourceUrl },
      });
      console.log("item?.Link =>>> " + ResourceUrl)
    },
    [dispatch, navigation],
  )
  return (
    <View style={{ flex: 1, backgroundColor: colors.white }}>
      <FastImage
        style={styles.vnaBackgroundImage}
        resizeMode='contain'
        source={require('../../../assets/images/img_background_home.png')}
      />
      <HeaderWithAvatar
        item={currentUser.dataCurrentUsers}
        title={languages.tab_category}
        urlOnline={currentUser.dataCurrentUsers?.ImagePath}
        isCategory={true}
        isClickLeftMenu={isClickLeftMenu}
        id ={id}
        dataSubCategory={dataSubCategoryState}
        dataCategory ={dataCategory}
        filteredCategories={filteredCategoriesState}
         />

      <View style={styles.view_header}>

        <TouchableOpacity style={{ marginTop: 20 }} onPress={onPressLeftMenu}>
          <FastImage
            style={styles.icon_back}
            resizeMode='contain'
            source={require('../../../assets/images/icon_menu_category.png')}
          />
        </TouchableOpacity>
        <Text style={styles.txtHeader}>{parenttitle}</Text>
        {isFirst ? (<View>
        </View>) :
          (
            <View >
              <Text style={styles.txtHeader}>/</Text>
              <Text style={{
                fontSize: 20,
                fontWeight: '600',
                color: '#000000',
                marginLeft: 45,
                marginTop: -23
              }}>{titleChild}</Text>
            </View>
          )}

        <View style={styles.imgUser}>
          {isTypeGrid ? (
            <TouchableOpacity style={styles.view_right} onPress={onPressChangeType2}>
              <FastImage
                style={styles.icon_back}
                resizeMode='contain'
                source={require('../../../assets/images/icon_changeTypeCategory.png')}
              />
            </TouchableOpacity>
          ) :
            <TouchableOpacity style={styles.view_right} onPress={onPressChangeType}>
              <FastImage
                style={styles.icon_back}
                resizeMode='contain'
                source={require('../../../assets/images/icon_changeTypeCategory2.png')}
              />
            </TouchableOpacity>}
        </View>
        <View style={styles.dashed} />
      </View>


      {isTypeGrid ? (
        <View style={styles.headerContainer}>
          <Text style={styles.textHeader_category_first} >
            Mã văn bản
          </Text>
          <TextCusTom i18nKey={'Tên văn bản'} style={styles.textHeader_category} />
          <TextCusTom i18nKey={'Ngày ban hành'} style={styles.textHeaderRight} />
          <TextCusTom i18nKey={'Ngày hiệu lực'} style={styles.textHeaderRight} />
        </View>
      ) : null}
      <ScrollView style={{ marginTop: isTypeGrid ? 0 : 20, height: 1000, width: windowWidth }}>
        {!arrayIsEmpty(dataSubCategoryState) ? (
          <FlatList
            contentContainerStyle={{ marginLeft: 5 }}
            key={isTypeGrid ? 'grid' : 'list'}
            data={dataSubCategoryState}
            extraData={dataSubCategoryState}
            numColumns={isTypeGrid ? 0 : 5}
            refreshControl={
              <RefreshControl refreshing={isLoadingdataSubCategory} onRefresh={onRefresh} tintColor='#0054AE' />
            }
            renderItem={({ item, index }) => (
              <ItemDoc item={item} index={index} animation={animation} />
            )}
            keyExtractor={(item, index) => index.toString()}
            ItemSeparatorComponent={renderSeparator}
            onEndReachedThreshold={0.5}
          />
        ) : (
          <NoDataView />
        )}
      </ScrollView>

      <ModalLeftMenu
        onPressFilter={onPressLeftMenu}
        modalVisible={visibleModalLeftMenu}
        onReFilterModal={onReModalPress}
        ID={id}
        filteredCategories={filteredCategoriesState}
        title={parenttitle}
        dataCategory = {dataCategory}
        menuItems={menus}
      />
    </View>
  );
};


export default DoucumentListView;
const stylesDoucument = StyleSheet.create({
  itemContainer: {
    width: 160,
    height: 250,
    marginLeft: 20
  },
  imgThumbnail: {
    height: 200,
    width: 160
  },
  cap1: {
    fontSize: FontSize.SMALL,
    color: colors.text_grey26,
    fontWeight: '400',
    marginTop: 7,
    textAlign: 'center'
  },

  itemNewDocuments: {
    flexDirection: 'row',
    backgroundColor: 'rgba(0, 0, 0, 0)',
    marginHorizontal: dimensWidth(15),
    borderRadius: 5,
    width: 100,
    height: 350,

    paddingHorizontal: '6.6%',
    marginLeft: 31,
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.23,
    shadowRadius: 2.62,
    elevation: 4,

  },
  itemNewDocumentsChild: {
    flexDirection: 'row',
    backgroundColor: 'white',
    borderRadius: 3,
    width: 185,
    height: 270,
    borderColor: 'lightgray',
    borderWidth: 0.5,
    position: 'absolute',
  },

  titleItemNewDoc: {
    position: 'absolute',
    bottom: 35,
    marginLeft: -10,
    width: 210,
    textAlign: 'center',
    color: '#262626',
    fontSize: 15,
    fontWeight: 'bold'


  },
  dateItemNewDoc: {
    position: 'absolute',
    bottom: 15,
    marginLeft: -10,
    width: 210,
    textAlign: 'center',
    color: '#262626',
    fontSize: 15,
    fontWeight: '300'
  },
  codeItemNewDoc: {
    position: 'absolute',
    textAlign: 'center',
    alignItems: 'center',
    bottom: 10,
    color: '#7B7B7B',
    right: -5,
    width: 200,
    height: 20

  },
})