import colors from "helpers/Colors";
import * as React from "react";
import Svg, { Path } from "react-native-svg";

function SvgComponent(props) {
  const { focused = false } = props;
  return (
    <Svg
      width={36}
      height={34}
      viewBox="0 0 26 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <Path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M13.47.34l11.307 10.323c.397.363.529.922.335 1.425a1.284 1.284 0 01-1.205.827H22.1v10.342c0 .41-.332.743-.74.743h-6.198a.742.742 0 01-.74-.743v-6.28h-3.643v6.28c0 .41-.332.743-.741.743H3.84a.742.742 0 01-.742-.743V12.915H1.294c-.538 0-1.011-.325-1.205-.827a1.288 1.288 0 01.334-1.425L11.73.34a1.284 1.284 0 011.74 0zm3.46 1.142h4.977c.41 0 .74.333.74.743v4.467l-5.717-5.21z"
        fill={focused ? '#DBA410': 'lightgray'}
      />
    </Svg>
  );
}

export default SvgComponent;
