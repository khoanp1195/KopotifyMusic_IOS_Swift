import colors from "helpers/Colors";
import * as React from "react";
import Svg, { Path } from "react-native-svg";

function SvgComponent(props) {
  const { focused } = props;
  return (
    <Svg
      width={36}
      height={34}
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <Path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M12.4.4v1.2H7.2V.4c0-.22.18-.4.4-.4H12c.22 0 .4.18.4.4zm-6 3.2v1.6H0V3.6c0-.22.18-.4.4-.4H6c.22 0 .4.18.4.4zM0 6v13.2h6.4V6H0zm4.8 5.2H1.6a.4.4 0 01-.4-.4V7.6c0-.22.18-.4.4-.4h3.2c.22 0 .4.18.4.4v3.2a.4.4 0 01-.4.4zM0 21.6v2c0 .22.18.4.4.4H6a.4.4 0 00.4-.4v-2H0zM6.4 20H0v.8h6.4V20zm.8 0h5.2v.8H7.2V20zm0-15.6h5.2v.779a.403.403 0 01.296-.367l6-1.6a.41.41 0 01.492.288l.574 2.203-6.774 1.806-.576-2.209a.405.405 0 01-.012-.078V19.2H7.2V4.4zm0 19.2v-2h5.2v2a.4.4 0 01-.4.4H7.6a.4.4 0 01-.4-.4zm0-21.2h5.2v1.2H7.2V2.4zm6.205 6.705l-.215-.822 6.775-1.806.214.821-6.774 1.807zm3.128 11.992l6.774-1.806-.429-1.645-6.774 1.807.43 1.644zm3.848-13.025l2.295 8.8-6.774 1.807-2.296-8.8 6.775-1.807zm-3.646 13.8l6.774-1.807.48 1.835a.403.403 0 01-.285.488l-6 1.6A.465.465 0 0117.6 24c-.07 0-.14-.02-.2-.056a.401.401 0 01-.188-.244l-.477-1.829z"
        fill={focused ? '#DBA410': 'lightgray'}
      />
    </Svg>
  );
}

export default SvgComponent;
