import colors from "helpers/Colors";
import * as React from "react";
import Svg, { Path } from "react-native-svg";

function SvgComponent(props) {
  const { focused } = props;
  return (
    <Svg
      width={36}
      height={34}
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <Path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M6.328 15.563c2.74 0 4.969 2.207 4.969 4.921V6.328C11.297 2.838 9.14 0 5.625 0v15.563h.703zm.83 4.218c.951 0 1.875.192 2.73.561-.076-1.873-1.644-3.373-3.56-3.373h-2.11V2.812H2.814v16.97h4.345zM24 22.594V7.03h-1.406v14.157h-5.752c-1.84 0-2.996.868-3.503 1.249-.099.074-.173.13-.222.157h-2.234a2.378 2.378 0 01-.222-.157c-.507-.38-1.664-1.25-3.503-1.25H1.406V5.626H0v16.969h7.152c1.746 0 2.745 1.037 3.029 1.332a.86.86 0 00.075.074h3.488a.861.861 0 00.074-.073c.284-.292 1.293-1.333 3.03-1.333H24zM16.842 4.219c-1.49 0-2.924.39-4.188 1.136.032.32.05.644.05.973v14.83c.093-.068.201-.144.324-.225 1.826-1.218 3.174-1.202 6.23-1.166.578.007 1.216.014 1.93.014V4.22h-4.346z"
        fill={focused ? '#DBA410': 'lightgray'}
      />
    </Svg>
  );
}

export default SvgComponent;
