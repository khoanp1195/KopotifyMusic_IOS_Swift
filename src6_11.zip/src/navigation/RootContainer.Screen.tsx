import React, {useState, useEffect} from 'react';
import styles from './RootContainer.Style';
import {View, StatusBar} from 'react-native';
import {
  NavigationContainer,
  createNavigationContainerRef,
} from '@react-navigation/native';
import {createStackNavigator} from '@react-navigation/stack';
import LoginScreen from '../login/Login.Screen';
import {useSelector} from 'react-redux';
import DrawerNavigatorStack from './DrawerNavigatorStack';
export type StackParamList = {
  LoginScreen: undefined;
  DrawerNavigatorStack: undefined;
};
import {SafeAreaProvider, SafeAreaView} from 'react-native-safe-area-context';
import {RootState} from '~/stories';
import FastImage from 'react-native-fast-image';

export const navigationRef = createNavigationContainerRef();
export const navigate = (name: any, params: any) => {
  if (navigationRef.isReady()) {
    navigationRef.navigate(name, params);
  }
};

const Stack = createStackNavigator<StackParamList>();

const RootContainerScreen = () => {
  const {isLogging} = useSelector((state: RootState) => state.login);

  return (
    <SafeAreaProvider>

      {isLogging ? (
        
        <SafeAreaView style={styles.mainContainer}>
          <StatusBar barStyle="light-content" backgroundColor={'blue'} />
          <DrawerNavigatorStack />
        </SafeAreaView>
      ) : (
        <>
          <StatusBar
            barStyle="light-content"
            backgroundColor="transparent"
            translucent={true}
         
          />
             {isLogging ? (
                        <View style={styles.bg_login}>
                        <FastImage
                           style={styles.vnaBackgroundImage}
                           source={require('../assets/images/img_vnaPlane.png')}
                         />
                         <FastImage
                           style={styles.vnaImage}
                           
                           source={require('../assets/images/vietname_airline.png')}
                         />      
                        </View>
             ): (
              <Stack.Navigator
              initialRouteName="LoginScreen"
              screenOptions={{
                headerShown: false,
              }}>
              <Stack.Screen
                name="LoginScreen"
                component={LoginScreen}
                options={{gestureEnabled: true, gestureDirection: 'horizontal'}}
              />
            </Stack.Navigator>
             )}
                 
  
        </>
      )}
    </SafeAreaProvider>
  );
};

export default RootContainerScreen;
