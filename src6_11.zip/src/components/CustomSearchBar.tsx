import { useNavigation } from '@react-navigation/native';
import { SearchIcon } from 'assets/svg';
import { windowWidth } from 'helpers/Constants';
import React from 'react';
import { View, TextInput, TouchableOpacity, StyleSheet } from 'react-native';
import { useDispatch, useSelector } from 'react-redux';
import { RootState } from 'stories/index';
import { setSearchTerm } from 'stories/lookup/search_result/reducer';

const CustomSearchBar = ({ value, onChange, onSearch,searchKey}) => {
  const { languages, languagesText } = useSelector((state: RootState) => state.languages);
  const dispatch = useDispatch();
  const navigation = useNavigation()
  return (
    <View style={styles.container}>
        <SearchIcon/>
      <TextInput
            onSubmitEditing={() => {
     
              dispatch(setSearchTerm(searchKey))
                       // @ts-ignore
                       navigation.navigate({
                        name: "LookupDetail",
                        params: { searchKey },
                      });
          }}
        style={styles.input}
        placeholder={languages.search_hint}
        value={searchKey}
        onChangeText={onChange}
      />
      <TouchableOpacity style={styles.button} onPress={onSearch}>
        {/* You can add a search icon or text here */}
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 8,
    backgroundColor: '#FFFAEE',
    borderRadius: 20,
    borderWidth: 1, // You can adjust the border width as needed
    borderColor: '#DBA410', // You can adjust the border color as needed
    width: windowWidth - 300,
    marginLeft: 150,
    marginTop: -15
},
  input: {
    flex: 1,
    padding: 8,
  },
  button: {
    padding: 8,
  },
});

export default CustomSearchBar;
