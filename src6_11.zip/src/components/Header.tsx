import { BackIcon, NotificationIcon } from 'assets/svg';
import React, { FC } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import FastImageCustom from './FastImageCustom';
import { FontSize, dimensWidth } from 'helpers/Constants';
import TextCusTom from './TextCusTom';
import colors from 'helpers/Colors';
import { TouchableOpacity } from 'react-native-gesture-handler';
import { useNavigation } from '@react-navigation/native';

const Header: any = ({ children, urlOnline, notificationCount = '0', title, ...props }: any) => {
    const navigation = useNavigation()
    return (
        <View style={styles.container}>
            <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}>
        <BackIcon />
            </TouchableOpacity>
            <TextCusTom allowFontScaling={false} {...props} i18nKey={title} style={styles.textTitle} />
            <View style={styles.viewRight} />
        </View>
    );
};
const styles = StyleSheet.create({
    container: { flexDirection: 'row', alignItems: 'center', padding: 20, backgroundColor: colors.white },
    backButton:{
    height: 30,
    width: 30,
    borderRadius:15,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.bg_app_color,    
    },
    textTitle: { fontSize: FontSize.LARGE_X, fontWeight: '700', color: colors.DarkCyan },
    viewRight: { flex: 1, alignItems: 'flex-end' },
    viewNotification: { backgroundColor: colors.red, height: 20, width: 20, borderRadius: 10, position: 'absolute', right: -7, top: -5, justifyContent: 'center', alignItems: 'center' },
    textNotification: { color: colors.white, fontSize: 12, }
});
export default React.memo(Header);
