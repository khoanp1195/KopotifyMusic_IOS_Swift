import React, {useState, useCallback,useEffect, useMemo} from 'react';
import {Text, View, } from 'react-native';
import {useDispatch, useSelector} from 'react-redux';
import styles from './Login.Style';
import {loginRequestApi, setHideWarning, setIsLogging} from '../stories/login/reducer';
import {KeyboardAwareScrollView} from 'react-native-keyboard-aware-scroll-view';
import TextCusTom from 'components/TextCusTom';
import { setLanguagesAction } from 'stories/languages/reducer';
import { RootState } from 'stories/index';
import FastImage from 'react-native-fast-image';
import TextInputCustom from 'components/TextInputCustom';
import { ClearTextRedIcon, HideGreyIcon, PasswordGreyIcon, UserGreyIcon } from 'assets/svg';
import { TouchableOpacity } from 'react-native-gesture-handler';
import ButtonCusTom from 'components/ButtonCusTom';
import colors from 'helpers/Colors';
import { checkIsEmpty, isNullOrUndefined } from 'helpers/Functions';
import LoadingView from 'components/LoadingView';
import AsyncStorage from '@react-native-async-storage/async-storage';

const LoginScreen = () => {
  const dispatch: any = useDispatch();
  const {isLogging,isAuth, isLoading, isShowWarning} = useSelector((state: RootState) => state.login);
  const {languages, languagesText} = useSelector((state: RootState) => state.languages);
  const [userName, onChangeUserName] = useState(''); //vnadmsuat.adminsite
  const [password, onChangePassword] = useState(''); //vnadmsuat@123$%
  const [isHidePassword, setIsHidePassword] = useState(false)

  const loginRequest = useCallback(
    async (userName: any, password: any) => {
      dispatch(
        loginRequestApi({
          userName,
          password,
        }),
      );
    },
    [dispatch],
  );

  const onLoginPress = useCallback(() => {
    loginRequest(userName, password);
  }, [userName, password, dispatch]);
  const isEnableLogin = useMemo(() => checkIsEmpty(userName) && checkIsEmpty(password), [userName, password])
  const changeLanguage = () => {
      dispatch(setLanguagesAction(languagesText))
  };
  const onChangeHidePassword = useCallback(
    () => {
      setIsHidePassword(!isHidePassword)
    },
    [isHidePassword],
  )
  useEffect(() => {
    dispatch(setIsLogging(true))
    const getUserInfo = async () => {
      const userName = await AsyncStorage.getItem('userName')
      const password = await AsyncStorage.getItem('password')

      if (!isNullOrUndefined(userName) && !isNullOrUndefined(password)) {
        onChangeUserName(userName)
        onChangePassword(password)
        loginRequest(userName,password)
      }
    };

    getUserInfo()
  }, [])

  // useEffect(() => {
  //   if (isAuth) {
  //     const saveUserInfo = async () => {
  //       await AsyncStorage.setItem('userName', userName)
  //       await AsyncStorage.setItem('password', password)
  //     };
  //     saveUserInfo()
  //   }
  // }, [ isAuth,userName,password]);
  return (
    <KeyboardAwareScrollView> 
      <View style={styles.bg_login}>
        {isLogging ? (
          <View style={styles.bg_login}>
                 {/* <FastImage
                    style={styles.vnaBackgroundImage}
                    source={require('../assets/images/img_vnaPlane.png')}
                  />
                  <FastImage
                    style={styles.vnaImage}
                    
                    source={require('../assets/images/vietname_airline.png')}
                  />  
                */}
          </View>
        ) : (
          <>
                  <View style={styles.bg_login}>
          
                   {/* <FastImage
                    style={styles.vnaBackgroundImage}
                    source={require('../assets/images/img_vnaPlane.png')}
                  />
                  <FastImage
                    style={styles.vnaImage}
                    
                    source={require('../assets/images/vietname_airline.png')}
                  />   */}
               

              <View style={{flexDirection: 'column', height:300, position: 'absolute',
                zIndex:1 ,marginTop: 320, alignContent:'center',alignItems:'center',backgroundColor:'transparent'}}>
            
            <Text style={{ textAlign: 'center',fontSize: 18,marginTop: 20, color:'white', fontWeight:'700'}}>Enter your business Email</Text>
             <View style={styles.containerTextInput}>
              <UserGreyIcon />
              <TextInputCustom
                placeholder={languages.placeHolderUseName}
                placeholderTextColor={colors.text_grey_bc}
                numberOfLines={1}
                onChangeText={text => {
                  dispatch(setHideWarning(null))
                  onChangeUserName(text)
                }}
                value={userName}
                style={styles.userNameInput}
              />
              {
                !checkIsEmpty(userName) && <TouchableOpacity onPress={()=> onChangeUserName("")}>
                <ClearTextRedIcon />
              </TouchableOpacity>
              }


<View style={styles.containerTextInputPassword}>
              <PasswordGreyIcon />
              <TextInputCustom
                placeholder={languages.placeHolderPassword}
                placeholderTextColor={colors.text_grey_bc}
                numberOfLines={1}
                onChangeText={text => {
                  dispatch(setHideWarning(null))
                  onChangePassword(text)
                }}
                value={password}
                style={styles.userNameInput}
                secureTextEntry={!isHidePassword}
              />
       <TouchableOpacity onPress={onChangeHidePassword}>
       <HideGreyIcon color={isHidePassword ? colors.black :colors.DarkCyan}/>
       </TouchableOpacity>
       
            </View>
            </View>
           
            {
              isShowWarning && <TextCusTom i18nKey={languages.incorrect_login} style={styles.textWarning}/>
            }
         
              </View>
         
            <ButtonCusTom  onPress={onLoginPress} i18nKey={languages.UseName} disabled={isEnableLogin} activeOpacity={isEnableLogin ? 1: 0.8}/>
                  </View>

            {/* <TextCusTom i18nKey={languages.HaveNoAccount} style={styles.textHaveNoAccount}/> */}
            {/* <ButtonCusTom i18nKey={languages.Register} bgColorCustom={colors.white} borderColorCustom={colors.orange} colorCustom={colors.DarkCyan}/> */}

{/*  
            <TextCusTom i18nKey={languages.welcome}/>
            <TextCusTom i18nKey={languages.welcome}/>
            <TextCusTom i18nKey={"Languages: " + languagesText}/> */}
          </>
        )}
      </View>
      <LoadingView isLoading={isLoading}/>

    </KeyboardAwareScrollView>
  );
};

export default React.memo(LoginScreen);
