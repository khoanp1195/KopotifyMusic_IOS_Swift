import LoginScreen from "../screen/login/LoginScreen";
import { TabsScreen } from "../screen/tab/TabScreen";
import { AppNavigationContainer } from "./AppNavigationContainer";
import { useSelector } from "react-redux";
import { View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
export const AuthNavigation = () => {
    const isAuth = useSelector((state: any) => state.auth.isAuth);
    return (
        <View style={{ flex: 1, backgroundColor: '#006885' }}>
        {!isAuth ? <LoginScreen /> : <AppNavigationContainer />}
    </View>

        // <View style={{ flex: 1, backgroundColor: '#006885' }}>
        //     {(isAuth) ? (
        //         <SafeAreaView style={{
        //             flex: 1,
        //             backgroundColor: '#006885',
        //             width: '100%',
        //             height: '100%',
        //             marginBottom: 0,
        //             marginTop: 35
        //         }}>
        //             <View style={{ flex: 1, backgroundColor: '#006885' }}>
        //                 {!isAuth ? <LoginScreen /> : <AppNavigationContainer />}
        //             </View>
        //         </SafeAreaView>

        //     ) :
        //         (<View style={{ flex: 1, backgroundColor: '#006885' }}>
        //             {!isAuth ? <LoginScreen /> : <AppNavigationContainer />}
        //         </View>
        //         )
        //     }

        // </View>
    );

};
