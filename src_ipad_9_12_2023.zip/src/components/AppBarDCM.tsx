import React, {FC, useEffect, useState} from 'react';
import {StyleSheet, Text, TouchableHighlight, TouchableOpacity, View} from 'react-native';
import {FastImageCustom} from './FastImageCustom';
import TextCusTom from './TextCusTom';
import {FontSize} from "../config/font";
import colors from "../config/colors";
import {NotificationIcon} from "assets/svg";
import {currentUserStore} from "../config/constants";
import {useNavigation} from "@react-navigation/native";
import {useSelector} from "react-redux";

const AppBarDCM: any = ({ children,  notificationCount = '0', title,onPress, ...props }: any) => {
    const navigation=useNavigation();
    const {isHomePage} = useSelector((state: any) => state.appbar);

    return (
        <View style={styles.container}>
                <TextCusTom allowFontScaling={false} {...props} i18nKey={title} style={styles.textTitle} />
                <TouchableOpacity  style={{marginLeft: '75%', marginBottom:'-2%'}} onPress={()=>{
                    // @ts-ignore
                    navigation.navigate('notification');
                }}>
                    <NotificationIcon />
                    {
                        notificationCount!=0&&
                        <View style={styles.viewNotification}>
                            <TextCusTom i18nKey={notificationCount} style={styles.textNotification} />
                        </View>
                    }
                </TouchableOpacity>         
       <View style={styles.viewRight} >
          
              
                <TouchableOpacity onPress={onPress} style={{ width: 20,height:20,zIndex:1}}>
                <FastImageCustom urlOnline={currentUserStore.getCurrentUser().ImagePath} defaultImage={require('assets/images/img_avatar_grey.png')}/>
            </TouchableOpacity>
       </View>
         
        
            {/* {
                isHomePage &&
                // <View style={styles.viewRight}>

                // </View>
        
            } */}
            
   
        </View>
    );
};
const styles = StyleSheet.create({
    container: { height:110, flexDirection: 'row', alignItems: 'center', padding: 20, backgroundColor: '#006885'},
    textTitle: { fontSize: 17, fontWeight: '700', color: 'white',marginBottom:'-3%' ,fontSize: 20,width:150},

    viewRight: { marginLeft:'4%',
    backgroundColor:'transparent',marginBottom:'2%',flexDirection:'row',
    width:20 },

    viewNotification: { backgroundColor: colors.red, height: 20, width: 20, borderRadius: 10, position: 'absolute', right: -7, top: -5, justifyContent: 'center', alignItems: 'center' },
    textNotification: { color: colors.white, fontSize: 12, }
});
export default React.memo(AppBarDCM);
