import {StyleSheet, Text, TouchableOpacity, View} from "react-native";
import {goToDocumentDetail} from "navigation/goToDetailNavigation";
import {FastImageCustom} from "components/FastImageCustom";
import {dimensWidth, windowWidth} from "../../config/font";
import FastImage from "react-native-fast-image";
import {format_dd_mm_yy, isNullOrEmpty} from "../../utils/function";
import {getListDocumentCategory} from "services/api/apiProvider";
import React, {useCallback, useEffect, useState} from "react";
import {useNavigation} from "@react-navigation/native";
import {useDispatch, useSelector} from "react-redux";
import {ListLoadMore} from "components/ListLoadMore";
import {DocumentCategory} from "services/database/models/DocumentCategory";
import { Col, Row } from 'react-native-flex-grid';
export const ListDetailCategoryScreen = () => {
    const navigation = useNavigation();
    const currentLanguage = useSelector((state: any) => state.languages.currentLanguage);
    const langId = currentLanguage === 'en' ? 1033 : 1066;
    const [change, setChange] = useState(false);
    // @ts-ignore
    const {positionStayCategory} = useSelector((state: RootState) => state.category);
    // @ts-ignore
    const {isConnected} = useSelector((state) => state.netInfo);
    // @ts-ignore
    const itemRender = ({item, index}) => {
        // @ts-ignore
        return   <View style={{ flexDirection: 'row',
        width: windowWidth - 80,
        marginLeft: 40,
        padding : -20,
        marginVertical: -25,
        paddingTop: 15,height:  130,
        justifyContent: 'center', backgroundColor: index % 2 == 0 ? '#F1FAFF' : 'white'}} >
        <View key={index} style={{ marginVertical: 5 }} >
          <TouchableOpacity  onPress={() => goToDocumentDetail(navigation, item.StorageCode,isConnected,false)}>
            <Row style={styles.cellContent}>
              <Col style={{ padding: 10, width: 210, flexDirection: 'row' }}>
                <FastImage style={{
                  height: dimensWidth(15),
                  width: dimensWidth(15),
                  marginLeft: dimensWidth(10),
                }}
                source={{ uri: item.Thumbnail }}
                defaultSource={require('assets/images/icon_document_default.png')}
                />
                <Text numberOfLines={1}  style={{ width: 700, marginLeft: 20, marginTop: 10, color: '#2376E0', width: 200 }}>{item.Code}</Text>
              </Col>
              <Col style={{ marginLeft: 10, justifyContent: 'center' }}>
                <Text numberOfLines={1} style={{ textAlign: 'center' }}>{item.Title}</Text>
              </Col>
              <Col style={{ justifyContent: 'center' }}>
                <Text style={{ marginLeft: '20%', width: 80 }}>{format_dd_mm_yy(item.IssueDate)}</Text>
              </Col>
              <Col style={{ justifyContent: 'center' }}>
                <Text style={{ marginLeft: '10%', width: 80 }}>{format_dd_mm_yy(item.IssueDate)}</Text>
              </Col>
            </Row>
          </TouchableOpacity>

        </View>
      </View>
        // <TouchableOpacity onPress={() => goToDocumentDetail(navigation, item.StorageCode,isConnected,false)}>
        //     <View
        //         style={{
        //             backgroundColor: index % 2 == 0 ? '#F1FAFF' : 'white',
        //             flexDirection: 'row',
        //             width: '100%',
        //             paddingHorizontal: 20,
        //             paddingVertical: 10
        //         }}>
        //         <FastImageCustom urlOnline={item.Thumbnail}
        //                          defaultImage={require('assets/images/icon_document_default.png')}
        //                          styleImg={{height: 45, wight: 30, borderRadius: dimensWidth(0)}}
        //                          resizeMode={FastImage.resizeMode.stretch}/>
        //         <View style={{flex: 1}}>
        //             <Text style={{color: 'black'}} numberOfLines={1}>{item.Title}</Text>
        //             <Text style={{color:'#2376E0',marginTop: '5%',width:'90%'}} numberOfLines={1}>{item.Code}</Text>
        //             </View>
        //         {
        //             !isNullOrEmpty(item.IssueDate) && (<View>
        //                 <Text style={{color:'#7B7B7B',marginTop: '40%'}}>{format_dd_mm_yy(item.IssueDate)}</Text>
        //             </View>)
        //         }
           
        //     </View>
        // </TouchableOpacity>
    }
    const List = useCallback(() => {
        return <ListLoadMore numColumn={1} callData={getData} ItemRenderFlatlist={itemRender} enableMoreData={true}
                             limit={15}/>;
    }, [positionStayCategory])
    const getData = async (limit: number, offet: number, isOnline: any) => {
        if (isOnline) {
            const data = await getListDocumentCategory(langId, offet, limit, {
                "Parameters": {
                    "AreaCategoryId": positionStayCategory[positionStayCategory.length - 1].PrimaryKey,
                    "DocumentGroupId": "1",
                    "Title": "",
                    "Code": "",
                    "StorageCode": "",
                    "Int2": ""
                }
            });
            if (data != null) {
                DocumentCategory.insertOrUpdateAll(data);
            }
            return data;
        } else {
            return DocumentCategory.getAll(positionStayCategory[positionStayCategory.length - 1].PrimaryKey, limit, offet);
        }
    }
    return <View style={{
        flex: 1,
        marginBottom: 50
    }}>
        <List/>
    </View>
}

const styles = StyleSheet.create({
    cellContent: {
        width: windowWidth,
        height: 70,
      },
  
  })