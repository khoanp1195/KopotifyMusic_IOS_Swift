import { DefaultTheme } from 'react-native-paper';

export const theme = {
  ...DefaultTheme,
  colors: {
    ...DefaultTheme.colors,
    primary: "#DBA410",

    error: '#f13a59',
    loggin: '#DBA410',
    borderColor: '#FFFFFF'
  },
};
