import * as React from "react"
import Svg, { Path } from "react-native-svg"

function SvgComponent(props) {
  return (
    <Svg
      width={20}
      height={20}
      viewBox="0 0 20 20"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <Path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M10 0C4.477 0 0 4.477 0 10s4.477 10 10 10c5.52-.006 9.994-4.48 10-10 0-5.523-4.477-10-10-10zm0 19.333A9.333 9.333 0 1110 .667 9.344 9.344 0 0119.333 10 9.333 9.333 0 0110 19.333zM10 8a2 2 0 100 4 2 2 0 000-4zm0 3.333a1.333 1.333 0 110-2.666 1.333 1.333 0 010 2.666zM13.667 10a2 2 0 114 0 2 2 0 01-4 0zm.666 0A1.333 1.333 0 1017 10a1.333 1.333 0 00-2.667 0zm-10-2a2 2 0 100 4 2 2 0 000-4zm0 3.333a1.333 1.333 0 110-2.666 1.333 1.333 0 010 2.666z"
        fill="#fff"
      />
    </Svg>
  )
}

export default SvgComponent
