import * as React from "react";
import Svg, { Rect } from "react-native-svg";

function SvgComponent(props) {
  const { color = "#77E075" } = props;
  return (
    <Svg
      width={16}
      height={16}
      viewBox="0 0 16 16"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <Rect
        x={0.5}
        y={0.5}
        width={15}
        height={15}
        rx={7.5}
        fill="#fff"
        stroke={color}
      />
      <Rect x={3} y={3} width={10} height={10} rx={5} fill={color} />
    </Svg>
  );
}

export default SvgComponent;
