import * as React from "react"
import Svg, { Path } from "react-native-svg"

function SvgComponent(props) {
  return (
    <Svg
      width={18}
      height={18}
      viewBox="0 0 18 18"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <Path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M17.902.921a.595.595 0 00-.917-.747L9 8.16 1.015.174.92.098a.595.595 0 00-.747.917L8.16 9 .174 16.985l-.076.094a.595.595 0 00.917.747L9 9.84l7.985 7.985.094.076a.595.595 0 00.747-.917L9.84 9l7.985-7.985.076-.094z"
        fill="#000"
      />
    </Svg>
  )
}

export default SvgComponent
