import * as React from "react"
import Svg, { Path } from "react-native-svg"

function SvgComponent(props) {
  const { color = "#fff" } = props;
  return (
    <Svg
      width={24}
      height={18}
      viewBox="0 0 24 18"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <Path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M0 17.526c0 .262.216.474.482.474a.478.478 0 00.482-.466v-.028c.054-1.272 5.123-6.76 10.607-7.071v4.249c0 .095.03.189.084.267.15.216.45.272.67.124L22.932 7.97a.469.469 0 000-.783L12.325.081a.496.496 0 00-.496-.027.473.473 0 00-.258.418v4.274C4.156 5.046.096 12.256 0 17.503v.023zM12.536 5.21V1.369l9.268 6.21-9.268 6.209V9.947a.478.478 0 00-.483-.474c-4.472 0-8.75 3.236-10.8 5.723 1.035-4.541 4.757-9.513 10.8-9.513a.478.478 0 00.483-.473z"
        fill={color}
      />
    </Svg>
  )
}

export default SvgComponent
