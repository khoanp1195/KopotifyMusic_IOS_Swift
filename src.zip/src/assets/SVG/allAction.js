import * as React from 'react';
import Svg, {Path} from 'react-native-svg';

function SvgComponent(props) {
  return (
    <Svg
      width={19}
      height={18}
      viewBox="0 0 19 18"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      {...props}>
      <Path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M9.875 18h6.75c1.034 0 1.875-.84 1.875-1.875V1.875A1.877 1.877 0 0016.625 0H2.375C1.341 0 .5.84.5 1.875v14.25C.5 17.159 1.341 18 2.375 18h7.5zm.375-.75h6.375c.62 0 1.125-.505 1.125-1.125V9.75h-7.5v7.5zm-.75-7.5v7.5H2.375c-.62 0-1.125-.505-1.125-1.125V9.75H9.5zm.75-.75h7.5V1.875c0-.62-.505-1.125-1.125-1.125H10.25V9zM9.5.75V9H1.25V1.875c0-.62.505-1.125 1.125-1.125H9.5z"
        fill="#5E5E5E"
      />
    </Svg>
  );
}

export default SvgComponent;
