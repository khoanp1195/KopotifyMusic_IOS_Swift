import * as React from 'react';
import Svg, {Path} from 'react-native-svg';

function SvgComponent(props) {
  return (
    <Svg
      width={21}
      height={18}
      viewBox="0 0 21 18"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      {...props}>
      <Path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M.5 9c0 4.962 4.038 9 9 9s9-4.038 9-9c0-.296-.015-.59-.043-.878a.408.408 0 10-.814.08c.026.262.039.528.039.798 0 4.511-3.67 8.182-8.182 8.182-4.511 0-8.182-3.67-8.182-8.182C1.318 4.489 4.988.818 9.5.818c1.569 0 3.094.447 4.413 1.294a.41.41 0 00.442-.69A8.97 8.97 0 009.5 0c-4.962 0-9 4.038-9 9zm9.938 1.722a.411.411 0 00.578-.001l9-9a.41.41 0 00-.578-.579l-8.711 8.711-3.393-3.392a.41.41 0 00-.578.579l3.682 3.682z"
        fill="#5E5E5E"
      />
    </Svg>
  );
}

export default SvgComponent;
