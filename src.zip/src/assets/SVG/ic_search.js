import * as React from "react";
import Svg, { Path } from "react-native-svg";

function SvgComponent(props) {
  const { color = "#fff" } = props;
  return (
    <Svg
      width={18}
      height={18}
      viewBox="0 0 18 18"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <Path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M13.47 12.708l4.374 4.374a.54.54 0 01-.379.918.543.543 0 01-.38-.16l-4.374-4.374a7.647 7.647 0 01-5.034 1.884C3.445 15.35 0 11.906 0 7.675 0 3.445 3.441 0 7.677 0c4.231 0 7.676 3.44 7.676 7.675 0 1.924-.71 3.684-1.884 5.033zM7.672 1.078a6.605 6.605 0 00-6.6 6.597c0 3.64 2.963 6.601 6.6 6.601 3.64 0 6.598-2.965 6.598-6.601a6.605 6.605 0 00-6.598-6.597z"
        fill={color}
      />
    </Svg>
  );
}

export default SvgComponent;
