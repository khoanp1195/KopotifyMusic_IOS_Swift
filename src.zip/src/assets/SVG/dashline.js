import React from "react";
import * as Svg from "react-native-svg";

function SvgComponent(props) {
    const {height, width, color = Svg.Color} = props
  return (
    <Svg.Svg height={height} width={width} style={{ alignSelf: "center" }}>
    <Svg.Line
      stroke={color}
      strokeWidth={width}
      strokeDasharray="3, 2"
      x1="0"
      y1="0"
      x2="0"
      y2={height}
    />
  </Svg.Svg>
  )
}

export default SvgComponent