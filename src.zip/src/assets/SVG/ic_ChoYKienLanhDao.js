import * as React from "react";
import Svg, { Path } from "react-native-svg";

function SvgComponent(props) {
  const { color = "#5E5E5E" } = props;
  return (
    <Svg
      width={18}
      height={18}
      viewBox="0 0 18 18"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <Path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M0 9c0-4.967 4.033-9 9-9s9 4.033 9 9-4.033 9-9 9-9-4.033-9-9zm17.217 0A8.221 8.221 0 009 .783 8.221 8.221 0 00.783 9 8.221 8.221 0 009 17.217 8.221 8.221 0 0017.217 9zM6.652 11.74a2.74 2.74 0 00-2.625 1.954.391.391 0 01-.75-.224 3.523 3.523 0 013.375-2.514h4.696a3.523 3.523 0 013.375 2.514.391.391 0 11-.75.224 2.74 2.74 0 00-2.625-1.955H6.652z"
        fill={color}
      />
    </Svg>
  );
}

export default SvgComponent;
