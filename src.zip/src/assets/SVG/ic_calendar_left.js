import * as React from "react"
import Svg, { Path } from "react-native-svg"

function SvgComponent(props) {
  return (
    <Svg
      width={10}
      height={18}
      viewBox="0 0 10 18"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <Path
        d="M.211 9.494l8.564 8.302a.733.733 0 001.015-.001.684.684 0 00-.001-.987L1.734 9 9.79 1.192a.684.684 0 00.002-.987A.727.727 0 009.282 0a.726.726 0 00-.507.204L.211 8.506a.687.687 0 000 .988z"
        fill="'rgba(11, 94, 92,1)"
      />
    </Svg>
  )
}

export default SvgComponent
