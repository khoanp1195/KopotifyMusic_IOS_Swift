import * as React from "react";
import Svg, { Path } from "react-native-svg";

function SvgComponent(props) {
  const { color = "red" } = props;
  return (
    <Svg
      width={20}
      height={20}
      viewBox="0 0 20 20"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <Path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M10 0c5.523 0 10 4.477 10 10s-4.477 10-10 10S0 15.523 0 10 4.477 0 10 0zm0 .941a9.059 9.059 0 100 18.118A9.059 9.059 0 0010 .94zm4.4 12.72c.184.184.175.491-.02.686-.171.171-.428.2-.612.081l-.075-.06-3.81-3.811L6.15 14.29c-.184.184-.491.174-.687-.021a.494.494 0 01-.08-.612l.06-.074L9.175 9.85l-3.8-3.8c-.184-.185-.175-.492.02-.687.171-.171.428-.2.612-.08l.075.06 3.8 3.8 3.796-3.796c.184-.184.491-.175.686.02.171.172.2.428.081.613l-.06.074L10.59 9.85l3.812 3.811z"
        fill={color}
      />
    </Svg>
  );
}

export default SvgComponent;
