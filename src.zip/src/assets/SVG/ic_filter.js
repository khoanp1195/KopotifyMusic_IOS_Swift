import * as React from "react"
import Svg, { Path } from "react-native-svg"

function SvgComponent(props) {
  const {color = '#fff'} = props
  return (
    <Svg
      width={21}
      height={18}
      viewBox="0 0 21 18"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <Path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M20.157.473A.879.879 0 0019.365 0H.885a.92.92 0 00-.792.473.84.84 0 00.088.903l7.766 9.549v6.215c0 .322.176.602.462.752a.927.927 0 00.418.108.87.87 0 00.506-.15l2.442-1.657c.352-.258.55-.645.55-1.053v-4.237l7.744-9.527a.84.84 0 00.088-.903zm-8.624 10.022a.455.455 0 00-.088.258v4.365c0 .15-.066.28-.176.366L8.827 17.14v-6.387c0-.15-.066-.28-.176-.344L3.679 4.3h7.986c.242 0 .44-.193.44-.43a.436.436 0 00-.44-.43H2.997L.885.86h18.48l-7.832 9.634zM14.305 4.3h-.66a.436.436 0 01-.44-.43c0-.237.198-.43.44-.43h.66c.242 0 .44.193.44.43s-.198.43-.44.43z"
        fill='#0b5e5c'
      />
    </Svg>
  )
}

export default SvgComponent
