import * as React from "react";
import Svg, { Path } from "react-native-svg";

function SvgComponent(props) {
  return (
    <Svg
      width={20}
      height={25}
      viewBox="0 0 10 16"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <Path
        d="M.197 8.44l7.993 7.38a.709.709 0 00.947-.002.588.588 0 000-.877L1.618 8l7.517-6.94a.588.588 0 00.002-.878A.697.697 0 008.663 0a.696.696 0 00-.473.181L.197 7.561A.597.597 0 000 8c0 .165.07.323.197.44z"
        fill="gray"
      />
    </Svg>
  );
}

export default SvgComponent;
