import * as React from "react"
import { View } from "react-native";
import Svg, { Path } from "react-native-svg"

function SvgComponent(props) {
  const { color = "#005FD4", opacity = 1 } = props;
  return (
    <View style={{opacity}}>
      <Svg
      width={9}
      height={14}
      viewBox="0 0 9 14"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <Path
        d="M7.994 6.616L1 .158A.62.62 0 00.171.16a.515.515 0 00.001.768L6.75 7 .172 13.073a.514.514 0 000 .767.61.61 0 00.414.16c.15 0 .3-.053.414-.159l6.994-6.457A.522.522 0 008.167 7a.524.524 0 00-.173-.384z"
        fill={color}
      />
    </Svg>
    </View>
  )
}

export default SvgComponent
