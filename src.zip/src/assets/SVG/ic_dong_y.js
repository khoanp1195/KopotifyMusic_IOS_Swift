import * as React from "react"
import Svg, { Path } from "react-native-svg"

function SvgComponent(props) {
    const { color = "#fff" } = props

    return (
    <Svg
      width={20}
      height={18}
      viewBox="0 0 20 18"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <Path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M2.292 17.5h12.916a2.294 2.294 0 002.292-2.292V8.125a.625.625 0 00-1.25 0v7.083c0 .574-.468 1.042-1.042 1.042H2.292a1.043 1.043 0 01-1.042-1.042V2.292c0-.575.467-1.042 1.042-1.042h10.416a.625.625 0 000-1.25H2.292A2.294 2.294 0 000 2.292v12.916A2.294 2.294 0 002.292 17.5zm7.474-7.267a.626.626 0 00.884 0l9.167-9.166a.625.625 0 00-.884-.884l-8.724 8.724L6.9 5.6a.625.625 0 10-.884.884l3.75 3.75z"
        fill={color}
      />
    </Svg>
  )
}

export default SvgComponent
