import {FlatList, Text, View} from 'react-native';
import React, { useCallback, useEffect, useState } from 'react';
import styles from './Dashboard.Style';
import { useDispatch, useSelector } from 'react-redux';
import { ThunkDispatch } from 'redux-thunk';
import { fetchGetNewDocument } from 'stories/dashboard/reducer';
import { arrayIsEmpty } from 'helpers/Functions';
import FastImage from 'react-native-fast-image';
import { UserGreyIcon } from 'assets/svg';
const DATA = [
  {
    id: 'bd7acbea-c1b1-46c2-aed5-3ad53abb28ba',
    title: 'First Item',
  },
  {
    id: '3ac68afc-c605-48d3-a4f8-fbd91aa97f63',
    title: 'Second Item',
  },
  {
    id: '58694a0f-3da1-471f-bd96-145571e29d72',
    title: 'Third Item',
  },
  {
    id: '3ac68afc-c605-48d3-a4f8-fbd91aa97f63',
    title: 'Second Item',
  },
  {
    id: '58694a0f-3da1-471f-bd96-145571e29d72',
    title: 'Third Item',
  },
  {
    id: '3ac68afc-c605-48d3-a4f8-fbd91aa97f63',
    title: 'Second Item',
  },
  {
    id: '58694a0f-3da1-471f-bd96-145571e29d72',
    title: 'Third Item',
  },
  {
    id: '3ac68afc-c605-48d3-a4f8-fbd91aa97f63',
    title: 'Second Item',
  },
  {
    id: '58694a0f-3da1-471f-bd96-145571e29d72',
    title: 'Third Item',
  },
  {
    id: '3ac68afc-c605-48d3-a4f8-fbd91aa97f63',
    title: 'Second Item',
  },
  {
    id: '58694a0f-3da1-471f-bd96-145571e29d72',
    title: 'Third Item',
  },
  {
    id: '3ac68afc-c605-48d3-a4f8-fbd91aa97f63',
    title: 'Second Item',
  },
  {
    id: '58694a0f-3da1-471f-bd96-145571e29d72',
    title: 'Third Item',
  },
];

type ItemProps = {title: string};

const Item = ({title}: ItemProps) => (
  <View style={styles.item}>
    <Text style={styles.title}>{title}</Text>
  </View>
);
const DashboardScreen = () => {
  const dispatch = useDispatch<ThunkDispatch<any, any, any>>();
  const [Offset,setOffset] = useState(0);

  const dataNewDocument = useSelector(
    (state: any) => state.dashboard
  )
  const fetchGetDataNewDoucumentRequest = useCallback((payload: any) => {
      dispatch(fetchGetNewDocument(payload))
  },[dispatch])

  useEffect(() => {
    fetchGetDataNewDoucumentRequest({limit: 10,Offset})
  },[dataNewDocument])

  console.log('dataNewDocument = >>>> ' + dataNewDocument)


  return (
      <View style={{backgroundColor:'white',flex: 1}}>
    
                    <FastImage
              style={styles.vnaBackgroundImage}
              resizeMode='contain'
        source={require('../assets/images/img_background_home.png')}
      />
       <View style={styles.header}>
        <Text style={{color:'white', fontStyle:'normal',fontWeight:'bold',
      position:'absolute',top: 30, left: 15, fontSize: 18}}>Trang chủ</Text>
      <View  style={{
    position: 'absolute',
    right: 15,
    backgroundColor:'white',
    top: 20,
    width: 40,
    height: 40,
    display: 'flex',
    justifyContent: 'center', // Center horizontally
    alignItems: 'center', // Center vertically
  }}>
      <UserGreyIcon/>
      </View>

      <View  style={{
    position: 'absolute',
    right: 75,
    backgroundColor:'white',
    top: 20,
    width: 40,
    height: 40,
    display: 'flex',
    justifyContent: 'center', // Center horizontally
    alignItems: 'center', // Center vertically
  }}>
      <UserGreyIcon/>
      </View>
      
       </View>
       

       
        <Text style={{position:'absolute',zIndex:1,top:90,fontSize : 20, color:'#DBA410', left : 15, fontWeight: "bold"}}>Vừa xem</Text>
        {!arrayIsEmpty(dataNewDocument) ? (
          <FlatList
          contentContainerStyle = {{height: 170,width:130,position:'absolute', top: 60}}
            data={dataNewDocument}
            horizontal
            renderItem={({item}) => <Item title={item.title} />}
            keyExtractor={item => item.id}
          />
        ): null}
     
      </View>
    );
};

export default React.memo(DashboardScreen);








