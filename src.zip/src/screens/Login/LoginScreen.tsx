import React, { useState, useCallback, useEffect } from 'react';
import {
  ImageBackground, Image, KeyboardAvoidingView,
  Platform,
  TouchableWithoutFeedback,
  Keyboard, View, Alert,Text
} from 'react-native';


import TextInputCustom from '../../components/TextInputCustom';
import { UserIcon, PasswordIcon } from '../../assets/SVG/index';
import LinearGradientButton from '../../components/LinearGradientButton';
import Colors from '../../themes/Color';
import { fetchRealSite, loginRequestApi, setIsLogging } from '../../store/login/reducer'
import { RootState } from '../../store';
import { dimensWidth, dimnensHeight } from '../../themes/const';
import { ThunkDispatch } from "@reduxjs/toolkit";
import { useDispatch, useSelector } from 'react-redux';
// import { Text } from 'react-native-svg';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { isNullOrUndefined } from '../../helpers/formater';
import styles from './Login.Style';

const LoginScreen = () => {
  const dispatch = useDispatch<ThunkDispatch<any, any, any>>();
  const { isLogging, isAuth } = useSelector((state: RootState) => state.login);
  const [userName, onChangeUserName] = useState('');
  const [password, onChangePassword] = useState('');

  const loginRequest = useCallback(async (userName: any, password: any) => {
    dispatch(setIsLogging(true))
    dispatch(
      loginRequestApi({
        userName,
        password,
      }),
    );
  }, [dispatch]);

  useEffect(() => {
    dispatch(setIsLogging(true))
    const getUserInfo = async () => {
      const username = await AsyncStorage.getItem('username')
      const pass = await AsyncStorage.getItem('password')

      if (!isNullOrUndefined(username) && !isNullOrUndefined(pass)) {
        onChangeUserName(username)
        onChangePassword(pass)
        loginRequest(username, pass)
      }
    };

    getUserInfo()
  }, [])

  useEffect(() => {
    if (isAuth) {
      const saveUserInfo = async () => {
        await AsyncStorage.setItem('username', userName)
        await AsyncStorage.setItem('password', password)
      };

      saveUserInfo()
     // dispatch(fetchRealSite(userName))
    }
  }, [userName, isAuth]);

  const loginPress = useCallback(() => {
    loginRequest(userName, password)
  }, [userName, password])

  return (
    <TouchableWithoutFeedback
      onPress={Keyboard.dismiss}
      accessible={false}
      style={{ flex: 1, }}
    >
      <KeyboardAvoidingView
        style={{ flex: 1, }}
        behavior={Platform.OS === "ios" ? "padding" : "height"}
      >
          {
            isLogging ? 
            <View   style={styles.bg_login}>
          <Image
            style={{  flex: 1, // Use flex: 1 to make the image fullscreen
            width: '100%',
            resizeMode: 'cover',
            height: 1000,
          }}
            resizeMode="contain"
            source={require('../../assets/splashScreen.jpg')}
          /> 
            </View>: (
              
            <View
            // source={require('../assets/images/background_login.png')}
             style={styles.bg_login}>
   
             <View style={{
               width: dimensWidth(250),
               height: dimnensHeight(150),
               aspectRatio: 1 * 1.7,
               marginTop: 80,
               marginBottom: 80
             }}>
               <View style={styles.container_logoBidv}>
               <Image
                 style={styles.imageBIDV}
                 resizeMode="contain"
                 source={require('../../assets/BIDV_Image.png')}
               />
               </View>
             </View>
             <Text style={styles.lbl_title}>Ngân HÀNG TMCP ĐẦU TƯ VÀ PHÁT TRIỂN VIỆT NAM</Text>
           
          
             <View style={styles.containerTextInput}>
                     <UserIcon />
                     <TextInputCustom
                       placeholder="Tên đăng nhập"
                       
                       placeholderTextColor={Colors.grey999}
                       numberOfLines={1}
                       onChangeText={text => onChangeUserName(text)}
                       value={userName}
                       style={styles.userNameInput}
                     />
                   </View>
                   <View style={styles.containerTextInput}>
                     <PasswordIcon />
                     <TextInputCustom
                       placeholder="Mật khẩu"
                       placeholderTextColor={'#999999'}
                       numberOfLines={1}
                       onChangeText={text => onChangePassword(text)}
                       value={password}
                       style={styles.userNameInput}
                       secureTextEntry
                     />
                   </View>
                   <LinearGradientButton
                     onPress={loginPress}
                     title={'Đăng nhập'.toUpperCase()}
                     colorList={['#2596be', '#00c0ae']}
                   
                   />
   
           <View style={styles.container_logoHoamai}>
               <Image
                 style={styles.imageHoaMai}
                 resizeMode="contain"
                 source={require('../../assets/icon_hoamai.png')}
               />
               </View>
           </View>
          )
          }
      </KeyboardAvoidingView>
    </TouchableWithoutFeedback>
  );
};

export default LoginScreen;
