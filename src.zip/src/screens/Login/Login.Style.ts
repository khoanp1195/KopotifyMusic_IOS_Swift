import {StyleSheet} from 'react-native';
import { dimensWidth, dimnensHeight } from '../../themes/const';

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  text: {
    fontSize: 18,
  },
  bg_login: {
    alignItems: 'center',
    width: '100%',
    height: '100%',
    ...StyleSheet.absoluteFillObject,
  },

  tabBarLabelActive: {
    color: "rgba(255, 255, 255, 1)",
    fontWeight: "700",
    fontSize: 12,
  },
  logoPetrolimex: {
    resizeMode: 'cover',
    height: 100,
    width: 100
  },
  container_logoBidv: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingTop: 200
  },
  imageBIDV: {
    width: 200, 
    height: 200, 
  },

  container_logoHoamai: {
    flex: 1,
    justifyContent: 'flex-end',
    alignItems: 'flex-end',
    paddingTop: 10,
    left: 100,
    resizeMode: 'cover',

  },
  imageHoaMai: {
    width: 400, 
    height: 374, 
  },

  containerTextInput: {
    flexDirection: 'row',
    alignItems: 'center',
    height: 50,
    width: 350,
    backgroundColor: '#fff',
    paddingLeft: 18,
    borderRadius: 8,
    marginBottom: 20,
  },
  userNameInput: {
    paddingHorizontal: 10,
    flex: 1,
  },
  lbl_title: {
    color: "black",
    fontSize: 13,
    paddingVertical: 40,
    fontWeight: 'bold',
    alignItems:'center',
    alignContent: 'center'
  }
});
export default styles;
