import React, { memo, useState } from 'react';
import { TouchableOpacity, StyleSheet, Text, View, Image, ImageBackground } from 'react-native';
import Background from '../../components/Background';
import Logo from '../../components/Logo';
import Header from '../../components/Header';
import Button from '../../components/Button';
import TextInput from '../../components/TextInput';
import BackButton from '../../components/BackButton';
import { theme } from '../../core/theme';
import { emailValidator, passwordValidator } from '../../core/util';
import { useNavigation } from '@react-navigation/native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Alert } from 'react-native';

const RegisterScreen = () => {
  const [email, setEmail] = useState({ value: '', error: '' });
  const [password, setPassword] = useState({ value: '', error: '' });
  const navigation = useNavigation();
  const [visible, setVisible] = useState(false);

  const gotoLogin = () => {
    navigation.navigate('Login');
  }
  const [isFocused, setIsFocused] = useState(false);
  const inputStyle = {
    color: isFocused ? 'green' : 'black',
    borderColor: isFocused ? 'green' : 'gray',
    borderWidth: 1,
    borderRadius: 5,
    padding: 5,
  };

  const handleLogin = () => {
    const emailError = emailValidator(email.value);
    if (emailError) {
      // Correct password logic
      setEmail({ ...email, error: emailError });
      return
    }
  };


  return (
    <Background>
      <View style={styles.container}>
        <Image resizeMode="contain" source={require('../../assets/icon_vna.png')} style={styles.image} />
        <View style={styles.overlay}>

        </View>
      </View>
      <Logo />

      <View style={styles.row}>
        <Text style={styles.label}>Enter your business email </Text>
      </View>
      
      <TextInput
        label="Email"
        returnKeyType="next"
        value={email.value}
        onChangeText={text => setEmail({ value: text, error: '' })}
        error={!!email.error}
        errorText={email.error}
        autoCapitalize="none"
        autoComplete="email"
        textContentType="emailAddress"
        keyboardType="email-address"
      />
      <View style={styles.row}>
        <Text style={styles.lbl_title1}>You will only be able to sign up to an existing business account via this app </Text>
      </View>

      <View style={styles.row}>
        <TouchableOpacity style={styles.button} onPress={handleLogin}>
          <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
            <Text style={{ textAlign: 'center', textAlignVertical: 'center', color: '#ffff' }}>Register</Text>
          </View>
        </TouchableOpacity>
      </View>

      <View style={styles.row}>
        <Text style={styles.label}>Alreay have account? </Text>
      </View>

      <View style={styles.row}>
        <TouchableOpacity style={styles.registerButton} onPress={gotoLogin}>
          <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
            <Text style={{ textAlign: 'center', textAlignVertical: 'center', color: '#006885' }}>Login</Text>
          </View>
        </TouchableOpacity>

      </View>
    </Background>
  );
};

const styles = StyleSheet.create({
  forgotPassword: {
    width: '100%',
    flex: 1,
    justifyContent: 'center',

    alignItems: 'center',
    marginBottom: 24,
    color: theme.colors.loggin
  },
  row: {
    flexDirection: 'row',
    marginBottom: 20,
  },
  label: {
    color: '#262626',
  },

  lbl_title1: {
    color: '#606060',
    alignItems: 'center',
    textAlign: 'center',
    fontStyle: 'italic'
  },

  lblLogin: {
    textAlign: 'center',
    fontSize: 13,
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center'
  },
  link: {
    fontWeight: 'bold',
    color: theme.colors.primary,
  },

  loginButton: {
    color: "#DBA410",
    paddingVertical: 10,
    paddingHorizontal: 20,
  },
  registerButton: {
    width: 300,
    height: 42,
    borderColor: "#DBA410",
    backgroundColor: "#fff",
    borderWidth: 0.5,
    borderRadius: 2,
    marginBottom: 220

  },
  image: {
    width: 300,
    height: 100,
    marginTop: 110,
    paddingVertical: 10,
    paddingHorizontal: 20,
  },
  button: {
    width: 300,
    height: 40,
    backgroundColor: "#DBA410",
    borderRadius: 2,
  },
  overlay: {
    position: 'absolute',
    width: 200,
    height: 200,
    zIndex: 1,
  },
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',

  },

});

export default RegisterScreen;
