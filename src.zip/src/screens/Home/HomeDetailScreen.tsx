import { FlatList, Platform, StyleSheet, Text, TextInput, Touchable, TouchableOpacity, View } from 'react-native'
import React, { Component, useCallback, useEffect, useLayoutEffect, useState } from 'react'
import { ScrollView } from 'react-native-gesture-handler';
import { BackIcon, BoSungThongTInIcon, ClockWhiteIcon, DeNghiHieuChinhIcon, DongYIcon, DropDownIcon, SaveIcon, ShareBlueIcon, ThreeDotIcon } from '../../assets/SVG';
import { FontSize, dimensWidth } from '../../themes/const';
import { useDispatch, useSelector } from 'react-redux';
import { AnyAction, AsyncThunkAction, ThunkDispatch } from "@reduxjs/toolkit";
import { fetchGetWorkflowItem } from '../../store/home/reducer';
import { fetchGetWorkflowbuttons } from '../../store/home/reducer';
import { arrayIsEmpty, byteConverter, checkTypeFiles, format_dd_mm_yy, removeSpecialCharacters } from '../../helpers/formater';
import colors from '../../themes/Color';
import { Container, Row, Col } from 'react-native-flex-grid';
import { v4 as uuidv4 } from 'uuid';
import { ActivityIndicator } from 'react-native-paper';
import LoadingView from '../../components/LoadingView';
import { ActionJsonType } from './components/HomeDetailType';
import ActionOptionalModal from './components/ActionOptionalModal';
import ThongTinLuanChuyenScreen from './ThongTinLuanChuyenScreen';

type Props = {
  navigation: any;
  route: any;
};
const HomeDetailScreen = ({ route, navigation }: Props) => {
  const dispatch = useDispatch<ThunkDispatch<any, any, any>>();
  const { workflowItemIDD, ListName, Title } = route.params;
  const [ItemID, setItemID] = useState("");
  // const [ListName, setListName] = useState("");
  const [dataDetailState, setdataDetaiState] = useState([]);
  const [dataAttachmentState, setdataAttachmentState] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isExpand, setisExpand] = useState(false);
 
  //ACTION
  const [modalActionOptional, setModalActionOptional] = useState(false)
  const [modalChuyenXuLy, setChuyenXuLyModal] = useState(false);
  const [modalDongY, setDongYModal] = useState(false);
  const [modalPheDuyet, setPheDuyetModal] = useState(false);
  const [modalThuHoi, setThuHoiModal] = useState(false);
  const [modalYeuCauHieuChinh, setYeuCauHieuChinhModal] = useState(false);
  const [modalChiaSe, setModalChiaSe] = useState(false);
  const [modalBoSungThongTin, setModalBoSungThongTin] = useState(false);


 

  const dataDetail = useSelector(
    (state: any) => state.home
  )
  const dataAttachment = useSelector(
    (state: any) => state.home
  )
  const dataGrid = useSelector(
    (state: any) => state.home
  )

  const dataAction = useSelector(
    (state:any) => state.home
  )

  console.log("dataAction =>>> " + dataAction)

  const {
    TenDuAn,
    LinhVuc,
    DonViDauMoi,
    Author,
    YearCategory,
    TMDTDuKien,
    GoiThau,
    GiaGoiThau,
    PhuongThucDauThau,
    NgayNghiemThu,
    GiaTriQuyetToan
  } = dataDetail

  const [isExpanded, setIsExpanded] = useState(false);
  
  const ItemAttach = ({ item, index }: any) => {
    const { Author, Created, Category, Size, FileRef, Title,DocumentType } = item
    const createdFormated = Created ? format_dd_mm_yy(Created) : null;
    const sizeFormated = Size ? byteConverter(Size, 0) : null;


    console.log("Item Attachment => " + item.item)
    const FileIcon = () => {
      return checkTypeFiles(FileRef);
    };
    const isOdd = index % 2 === 0;
    return (
      <View>
        <TouchableOpacity onPress={ExpandAttachMent}>
        <Row style={styles.cellHeaderAttachmentChild}>
            <Col style={styles.cellHeader}><Text style={{ fontWeight: 'bold',width: 200}}>{DocumentType}</Text></Col>
            <Col>
            <Text style={{ fontWeight: 'bold', color:'red', textAlign:'center',marginTop:10,backgroundColor:"white", marginLeft: Title.length,width: 30, borderRadius: 8,}}>2</Text>
            </Col>
            <Col>
            <DropDownIcon style={{right: 10,marginTop:5,colors:colors.alice_blue}}/>
            </Col> 
          </Row>
          {isExpanded ? (
      <TouchableOpacity
      style={[styles.documentFileView,
      isOdd && { backgroundColor: colors.alice_blue },
      ]}
      onPress={() => gotoFileViewScreen(item)}
    >

      
      <View style={[styles.flexDirectionRowBetween]}>
        
        <View style={{ marginTop: 5 }}>
          <FileIcon />
        </View>
        <Text style={styles.titleDocumentFile} numberOfLines={1}>
          {Title}
        </Text>

        <Text style={styles.contentAttach} numberOfLines={1}>
          {removeSpecialCharacters(Author)}
        </Text>

      </View>
      <View style={[styles.flexDirectionRowBetween, {
        alignItems: "flex-start", marginLeft: 20
      }]}>
        <Text style={styles.sizeDocumentFile} numberOfLines={1}>
          {sizeFormated}
        </Text>
        <Text style={{
          fontSize: FontSize.MEDIUM,
          color: 'black',
          fontWeight: "400",
          fontFamily: "arial",
          marginLeft: 15,
          marginTop: 5
        }} numberOfLines={1}
        > {removeSpecialCharacters(Category)}</Text>
        <Text style={{
          fontSize: FontSize.MEDIUM,
          color: colors.lightBlack,
          fontWeight: "400",
          fontFamily: "arial",
          marginLeft: 15,
          marginTop: 5
        }} numberOfLines={1}>
          {createdFormated}
        </Text>
      </View>
    </TouchableOpacity>
          ): null}
      
        </TouchableOpacity>
    
      </View>
  
    )
  }

  const ItemGrid = ({ item, index }: any) => {
    const {
      ProjectStep,
      TotalDays,
      FromDate,
      ToDate
    } = item;
    const idOdd = index % 2 === 0;
    return (
      <ScrollView horizontal style={[styles.viewScrollViewGrid, idOdd && {backgroundColor: 'white'}]} >
        <View>
          <Row style={styles.cellHeader}>
            <Col style={styles.cellHeader}><Text style={{fontWeight:'bold'}}>Bước kế hoạch</Text></Col>
            <Col style={[{
              padding: 7,
              marginLeft: -105,
              backgroundColor: '#f0f0f0',
              borderColor: '#ccc',
            }]}><Text style={{fontWeight:'bold'}}>Tổng số ngày</Text></Col>
            <Col style={[{
              padding: 7,
              marginLeft: -120,
              backgroundColor: '#f0f0f0',
              borderColor: '#ccc',
            }]}><Text style={{fontWeight:'bold'}}>Số ngày</Text></Col>
            <Col style={styles.cellHeader}><Text style={{fontWeight:'bold'}}>Từ ngày</Text></Col>
          </Row>

          {dataGrid.dataGrid[0].map((item: any, index: any) => (
            
    <View key={index} >
      <Row style={styles.cellContent}>
        <Col style={{ padding: 10, width: 210 }}>
          <Text style={{width:170,marginLeft: 10}}>{item.ProjectStep}</Text>
        </Col>
        <Col style={{ marginLeft: -120, padding: 10 }}>
          <Text style={{textAlign: 'center'}}>{item.TotalDays}</Text>
        </Col>
        <Col style={{ padding: 10 }}>
          <Text>{formatDate(item.FromDate)}</Text>
        </Col>
        <Col style={{ padding: 10 }}>
          <Text>{formatDate(item.ToDate)}</Text>
        </Col>
      </Row>
    </View>
  ))}
        <View>
</View>
        </View>
      </ScrollView>
    );

    
  }
  const formatDate = (dateString: any) => {
    const parsedDate = new Date(dateString);
    const formattedDate =
      parsedDate.toLocaleTimeString().slice(0, 5) + " " +
      parsedDate.toLocaleDateString('en-GB', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric'
      });
    return formattedDate;
  };
  

  const onGoBack = useCallback(() => {
    navigation.goBack();
  }, []);
  const gotoThongTInLuanChuyen = useCallback((item: any) => {
    navigation.navigate({
      name: "ThongTinLuanChuyenScreen",
      parans: {workflowItemIDD,ListName}
    })
  }, [dataDetail]);

  const gotoShareView = useCallback((item: any) => {
    navigation.navigate({
      name: "ShareViewScreen",
      params: {item}
    })
  }, [dataDetail]);

  //GotoView Attachment
  const dataAttach = dataAttachment.dataAttachment;
  const gotoFileViewScreen = useCallback((item: any) => {
    // fileRef = dataAttach[0].FileRef
    navigation.navigate({
      name: "FileViewScreen",
      params: {item}
    })
  }, [dataAttach])

  //Detail Content
  const fetchContentDetailRequest = useCallback(({ workflowItemIDD, ListName }: any) => {
    dispatch(
      fetchGetWorkflowItem({ workflowItemIDD, ListName }))
  }, [dispatch]);
  useEffect(() => {
    fetchContentDetailRequest({ workflowItemIDD, ListName })
  }, [fetchContentDetailRequest]);

  //Get Button Action
  const fetchGetWorkflowItemActionRequest = useCallback(({workflowItemIDD, ListName}: any) =>
  {
    dispatch(
      fetchGetWorkflowbuttons({workflowItemIDD,ListName})
    )
  },[dispatch])
  useEffect(() =>{
    fetchGetWorkflowItemActionRequest({workflowItemIDD,ListName})
  },[fetchGetWorkflowItemActionRequest])

  console.log("dataAction =>> " + dataAction.dataAction)

  useEffect(() => {
    setdataDetaiState(dataDetail.retdata)
  }, [dataDetail])

  useEffect(() => {
    // Simulate an asynchronous operation (e.g., fetching data)
    setTimeout(() => {
      setIsLoading(false); // Set isLoading to false when data is loaded
    }, 1000); // Simulating a 2-second delay
  }, []);

  //Close actionmodal
  const onCloseActionOptionalModel = useCallback(() =>{
    setModalActionOptional(false);
  },[modalActionOptional])

  const onCloseChuyenXuLyModal = useCallback(() => {
    setChuyenXuLyModal(false);
  }, [modalChuyenXuLy]);
  const onCloseDongYModal = useCallback(() => {
    setDongYModal(false);
  }, []);
  const onClosePheDuyetModal = useCallback(() => {
    setPheDuyetModal(false);
  }, []);
  // const onCloseYeuCauHieuChinhModal = useCallback(() => {
  //   setYeuCauHieuChinhModal(false);
  // }, [YeuCauHieuChinhModal]);
  const onCloseBoSungThongTinModal = useCallback(() => {
    setModalBoSungThongTin(false);
  }, []);

  const onCloseActionOptionalModal = useCallback(() => {
    setModalActionOptional(false);
  }, [modalActionOptional]);

  //Open actionmodal
  const openModalActionOtionnal = useCallback (() =>{
    setModalActionOptional(true);
  },[modalActionOptional])


  
 //Expand Attachment
 const ExpandAttachMent = useCallback (() => {
  setIsExpanded(true);
 },[])


  //Action Press
  const onActionpress = useCallback(
    (ID: number) => {
      if(modalActionOptional) setModalActionOptional(false);
    },[modalActionOptional]
   )

const dataBottomAction =  dataAction?.dataAction?.filter((item: { Visible: boolean; }) => item.Visible === true);
const dataBottomActionMore = dataBottomAction?.slice(2);
console.log("dataBottomAction =>> " + dataBottomAction)

  const { tabBarVisible } = route.params || {}; 

  return (
    <View style={styles.container}>
      {isLoading ? (
           <LoadingView/>
      ) : (
        // Your content when loading is complete
        <ScrollView>
        <View style={styles.headerDetail}>
          <TouchableOpacity
            style={styles.backPress}
            activeOpacity={1}
            onPress={onGoBack}
          >
            <BackIcon />
          </TouchableOpacity>
  
          <TouchableOpacity
            style={styles.thongTinLuanChuyen} onPress={gotoShareView}
          >
            <ShareBlueIcon />
          </TouchableOpacity>
          <TouchableOpacity style={styles.shareIcon} onPress={gotoThongTInLuanChuyen}>
            <ClockWhiteIcon />
          </TouchableOpacity>
        </View>
   
        {ListName === 'Kế hoạch Chuẩn bị đầu tư' ? (  
            <View style={styles.container}>
          <View style={styles.headerDetail1}><Text style={styles.labelHeader}>{Title}</Text></View>
          <View style={styles.syleContent}>
  
            <View style={styles.fieldContainer}>
              <Text style={styles.label}>NGƯỜI KHỞI TẠO DỰ ÁN</Text>
              <Text style={styles.input}>{dataDetail?.retdata?.Author}</Text>
            </View>
  
            <View style={styles.fieldContainer}>
              <Text style={styles.label}>TÊN DỰ ÁN</Text>
              <Text style={styles.input}>{dataDetail?.retdata?.TenDuAn}</Text>
            </View>
  
            <View style={styles.fieldContainer}>
              <Text style={styles.label}>LOẠI DỰ ÁN</Text>
              <Text style={styles.input}>{dataDetail?.retdata?.YearCategory}</Text>
            </View>
  
            <View style={styles.fieldContainer}>
              <Text style={styles.label}>LĨNH VỰC ĐẦU TƯ</Text>
              <Text style={styles.input}>{dataDetail?.retdata?.LinhVuc.split(';#')[1]}</Text>
            </View>
  
            <View style={styles.fieldContainer}>
              <Text style={styles.label}>ĐƠN VỊ ĐẦU MỐI</Text>
              <Text style={styles.input}>{dataDetail?.retdata?.DonViDauMoi.split(';#')[1]}</Text>
            </View>
  
            <View style={styles.fieldContainer}>
              <Text style={styles.label}>TỔNG MỨC ĐẦU TƯ ĐỀ XUẤT</Text>
              <Text style={styles.input}>{dataDetail?.retdata?.TMDTDuKien}</Text>
            </View>
          </View>
        </View >):
        ListName === 'Quy trình lựa chọn nhà thầu' ?(
        <View style={styles.container}>
        <View style={styles.headerDetail1}><Text style={styles.labelHeader}>{Title}</Text></View>
        <View style={styles.syleContent}>
  
          <View style={styles.fieldContainer}>
            <Text style={styles.label}>NGƯỜI KHỞI TẠO DỰ ÁN</Text>
            <Text style={styles.input}>{dataDetail?.retdata?.Author}</Text>
          </View>
  
          <View style={styles.fieldContainer}>
            <Text style={styles.label}>TÊN DỰ ÁN</Text>
            <Text style={styles.input}>{dataDetail?.retdata?.TenDuAn}</Text>
          </View>
  
          <View style={styles.fieldContainer}>
            <Text style={styles.label}>TÊN GÓI THẦU</Text>
            <Text style={styles.input}>{dataDetail?.retdata?.GoiThau}</Text>
          </View>
  
          <View style={styles.fieldContainer}>
            <Text style={styles.label}>GIÁ GÓI THẦU</Text>
            <Text style={styles.input}>{dataDetail?.retdata?.GiaGoiThau}</Text>
          </View>
  
          <View style={styles.fieldContainer}>
            <Text style={styles.label}>PHƯƠNG THỨC ĐẤU THẦU</Text>
            <Text style={styles.input}>{dataDetail?.retdata?.PhuongThucDauThau}</Text>
          </View>
        </View>
      </View >):  
        ListName === 'Quyết toán' ?(
          <View style={styles.container}>
          <View style={styles.headerDetail1}><Text style={styles.labelHeader}>{Title}</Text></View>
          <View style={styles.syleContent}>
          <View style={styles.fieldContainer}>
              <Text style={styles.label}>NGƯỜI KHỞI TẠO DỰ ÁN</Text>
              <Text style={styles.input}>{dataDetail?.retdata?.Author}</Text>
            </View>
            <View style={styles.fieldContainer}>
              <Text style={styles.label}>TÊN DỰ ÁN</Text>
              <Text style={styles.input}>{dataDetail?.retdata?.TenDuAn}</Text>
            </View>
    
            <View style={styles.fieldContainer}>
              <Text style={styles.label}>NGÀY NGHIỆM THU</Text>
              <Text style={styles.input}>{dataDetail?.retdata?.NgayNghiemThu}</Text>
            </View>
    
            <View style={styles.fieldContainer}>
              <Text style={styles.label}>GIÁ TRỊ QUYẾT TOÁN</Text>
              <Text style={styles.input}>{dataDetail?.retdata?.GiaTriQuyetToan}</Text>
            </View>
          </View>
        </View >): 
      null}
      
        {!arrayIsEmpty(dataGrid.dataGrid) ? (
          <View style={styles.viewTitleGrid}>
            <Text style={styles.txtAttachment}>Chi tiết dự án</Text>
          </View>
        ) : null}
  
        {!arrayIsEmpty(dataGrid.dataGrid) ? (
          <ScrollView
            horizontal
          >
            <FlatList
              style={styles.containerFlatList}
              horizontal
              extraData={dataGrid.dataGrid[0]}
              disableVirtualization
              keyExtractor={(item, index) => item + index.toString()}
              data={dataGrid.dataGrid[0]}
              renderItem={({ item, index }) => (
                <ItemGrid item={item} index={index} />
              )}
            />
          </ScrollView>
  
        ) : null}
  
        <View style={styles.viewTitleAttachment}>
          <Text style={styles.txtAttachment}>Tài liệu đính kèm</Text>
        </View>
        <View>
        <Row style={styles.cellHeaderAttachment}>
            <Col style={styles.cellHeader}><Text style={{ fontWeight: 'bold', width: 200}}>Loại tài liệu</Text></Col>
            <Col style={[{
              padding: 7,
              position: 'absolute',
              right: 10,
              top: 10,
              backgroundColor: '#f0f0f0',
              borderColor: '#ccc',
           
            }]}><Text style={{ fontWeight: 'bold'}}>Người tạo</Text></Col>
          </Row>
          {!arrayIsEmpty(dataAttachment.dataAttachment) && (
          <FlatList
            style={styles.containerAttach}
            nestedScrollEnabled
            extraData={dataAttachment.dataAttachment}
            disableVirtualization
            keyExtractor={(item, index) => item?.ID + index.toString()}
            data={dataAttachment.dataAttachment}
            renderItem={({ item, index }) => (
              <ItemAttach item={item} index={index} />
            )}
          />
        )}
        </View>
   
        </ScrollView>
      )}
   {!arrayIsEmpty(dataBottomAction) && (dataBottomAction?.length == 2 ) ? (
           <View style={styles.bottomBot}>
           <View style={styles.rowContainer}>
             <DongYIcon style={styles.lblAction1} />
             <Text style={styles.lblAction1}>{dataBottomAction[0]?.Text}</Text>
           </View>
           <View style={styles.rowContainer}>
             <DeNghiHieuChinhIcon style={styles.Action2} />
             <Text style={styles.lblAction2}>{dataBottomAction[1]?.Text}</Text>
           </View>
                        </View>
        ) : (dataBottomAction?.length >= 3 ) ?
        (
          <View style={styles.bottomBot}>
          <TouchableOpacity style={styles.rowContainer}>
            <DongYIcon style={styles.lblAction1} />
            <Text style={styles.lblAction1}>{dataAction.dataAction[0]?.Text}</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.rowContainer}>
            <DeNghiHieuChinhIcon style={styles.Action2} />
            <Text style={styles.lblAction2}>{dataAction.dataAction[1]?.Text}</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.rowContainer}>
            <ThreeDotIcon style={styles.Action3} onPress={openModalActionOtionnal}/>
          </TouchableOpacity>
           </View>
        ): (dataBottomAction?.length == 1) ? (
          <View style={styles.bottomBot}>
          <View style={styles.rowContainer}>
            <DongYIcon style={styles.lblAction1} />
            <Text style={styles.lblAction1}>{dataBottomAction[0]?.Text}</Text>
          </View>
                       </View>
        ): null }

      <ActionOptionalModal
        ActionJson={dataBottomActionMore}
        modalVisible={modalActionOptional}
        onCloseModal={onCloseActionOptionalModal}
        onChooseonActionMorePress={onActionpress}
      />
    </View>

  )
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 0,
    backgroundColor: 'white'
  },
  syleContent: {
    flex: 1,
    padding: 20,
    backgroundColor: 'white'
  },
  headerDetail: {
    height: 50,
    backgroundColor: 'white',
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",

  },
  rowContainer: {
    flexDirection: 'row', // To arrange items horizontally within each rowContainer
    alignItems: 'center', // To vertically align items within each rowContainer
    marginRight: 10, // Add margin between rowContainers as needed
  },
  headerDetail1: {
    height: 65,
    backgroundColor: 'lightgray'
  },

  bottomBot:{
    marginTop: 20,
    height: 65,
    backgroundColor: 'white',
    borderWidth: 0.5,
    borderColor: 'lightgray',
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },

  fieldContainer: {
    marginBottom: 20,
    marginTop: 15
  },
  label: {
    fontSize: 12,
    color: 'gray', // Set the color property
    marginBottom: 8,
  },
  thongTinLuanChuyen: {
    marginLeft: 255,
  },

  labelHeader: {
    padding: 15,
    color: '#0b5e5c',
    fontWeight: '500',
    fontSize: FontSize.SMALL,
    fontFamily: 'arial',
  },

  lblAction1: {
    padding: 15,
    color: '#0b5e5c',
    fontWeight: '500',
    fontSize: FontSize.SMALL,
    fontFamily: 'arial',
    marginLeft: 15
  },
  lblAction2: {
    color: '#0b5e5c',
    fontWeight: '500',
    fontSize: FontSize.SMALL,
    fontFamily: 'arial',
    marginRight:  30,
  },

  Action2:{
    padding: 15,
    color: '#0b5e5c',
    marginRight: 15
  },

  Action3: {
    color: '#0b5e5c',
    marginRight:10,
  },



  img_action2: {
    color: '#0b5e5c',
    fontWeight: '500',
    fontSize: FontSize.SMALL,
    fontFamily: 'arial',
    width: 250,
    marginRight: 50
  },

  input: {
    fontSize: 14,
    padding: 0,
    color: '#0b5e5c',
    fontWeight: '400',
  },
  backPress: {
    padding: 8,
  },

  shareIcon: {
    marginRight: 20,
  },

  headerItem: {
    flex: 1,
    margin: 8,
    padding: 8,
    borderWidth: 1,
    borderColor: 'lightgray',
    backgroundColor: 'gray', // Header row background color
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  documentFileView: {
    padding: 15,
  },
  flexDirectionRowBetween: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  titleDocumentFile: {
    fontSize: FontSize.MEDIUM,
    color: 'black',
    fontWeight: "400",
    fontFamily: "arial",
    marginLeft: 15,
    marginTop: 5,
    borderRadius: 4,
  },
  contentAttach: {
    fontSize: FontSize.MEDIUM,
    color: colors.black,
    fontWeight: "400",
    fontFamily: "arial",
    marginLeft: 15,
    marginTop: 5
  },
  sizeDocumentFile: {
    fontSize: FontSize.MEDIUM,
    color: colors.lightBlack,
    fontWeight: "400",
    fontFamily: "arial",
    marginLeft: 15,
    marginTop: 5,
    borderRadius: 4,
  },
  containerAttach: {
    borderColor: colors.greyDDD,
    borderRadius: 8,
    marginTop: 0,
    marginHorizontal: 15,
    overflow: "hidden"
  },
  viewTitleAttachment: {
    marginTop: 10,
    padding: 10
  },
  viewTitleGrid:{
    marginTop: -10,
    padding: 10
  },
  txtAttachment: {
    fontSize: FontSize.MEDIUM,
    color: '#0b5e5c',
    fontWeight: "600",
    fontFamily: "arial",
  },
  header: {
    backgroundColor: '#f0f0f0',
    borderBottomWidth: 1,
    borderColor: '#ccc',
  },
  cellHeader: {
    padding: 10,
    width: '210%',
    backgroundColor: '#f0f0f0',
    borderColor: '#ccc',

  },
  cellHeaderAttachment: {
    width: '93%',
    padding: 5,
    backgroundColor: '#f0f0f0',
    borderColor: '#ccc',
    marginLeft: 15,
    borderRadius: 8,
    borderWidth:0.2
  },
  cellHeaderAttachmentChild: {
    padding: 5,
    width: '120%',
    backgroundColor: '#f0f0f0',
    borderColor: '#ccc',
    borderRadius: 8,
    marginTop: 5
  },
  cellContent: {
    width: '200%',
  },
  viewGrid: {
    padding: 10,
    marginLeft: 20,
    marginTop: -10,
    width: '120%',
  },
  viewScrollViewGrid: {
    flexDirection: 'row',
    width: '400%',   
  },
  containerFlatList: {
    marginTop: dimensWidth(15),
    marginLeft: 10,

  },

});
export default HomeDetailScreen

function dispatch(arg0: AsyncThunkAction<any, any, { state?: unknown; dispatch?: Dispatch<AnyAction> | undefined; extra?: unknown; rejectValue?: unknown; serializedErrorType?: unknown; pendingMeta?: unknown; fulfilledMeta?: unknown; rejectedMeta?: unknown; }>) {
  throw new Error('Function not implemented.');
}
