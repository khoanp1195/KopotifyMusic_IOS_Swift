import { Text, Touchable, TouchableOpacity, View } from 'react-native'
import React, { Component } from 'react'

type Props = {
    navigation: any;
    route: any;
  };
const HomeDetailScreen = ({route, navigation}: Props) => {
    return (
        <View>
          <TouchableOpacity><Text>Back</Text></TouchableOpacity>
        </View>
    )
  }
export default HomeDetailScreen