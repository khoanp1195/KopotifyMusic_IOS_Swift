import { StyleSheet, Text, TextInput, Touchable, TouchableOpacity, View } from 'react-native'
import React, { Component, useCallback, useEffect, useState } from 'react'
import { ScrollView } from 'react-native-gesture-handler';
import { BackIcon, ClockWhiteIcon, ShareBlueIcon } from '../../assets/SVG';
import { FontSize } from '../../themes/const';
import { useDispatch, useSelector } from 'react-redux';
import { AnyAction, AsyncThunkAction, ThunkDispatch } from "@reduxjs/toolkit";
import { fetchGetWorkflowItem } from '../../store/home/reducer';

type Props = {
    navigation: any;
    route: any;
  };
const HomeDetailScreen = ({route, navigation}: Props) => {
  const dispatch = useDispatch<ThunkDispatch<any, any, any>>();
  const [ItemID, setItemID] = useState("");
  const [ListName, setListName] = useState("");
  const[dataDetailState,setdataDetaiState] = useState([]);
  const dataDetail = useSelector(
    (state: any) => state.home
  )

  const onGoBack = useCallback(() => {
    navigation.goBack();
  }, []);
  const gotoThongTInLuanChuyen = useCallback(() =>
  {
    navigation.navigate({
      name: "ThongTinLuanChuyenScreen"
    })
  }, []);

  const gotoShareView = useCallback(() =>
  {
    navigation.navigate({
      name:"ShareViewScreen"
    })
  }, []);
  
  //Detail Content
  const fetchContentDetailRequest = useCallback(({ItemID, ListName}: any) =>{
    dispatch(
      fetchGetWorkflowItem({ItemID: 1820, ListName:"Kế hoạch Chuẩn bị đầu tư"}))
  },[dispatch]);

  useEffect(() => {
    fetchContentDetailRequest({ItemID, ListName})
  }, [fetchContentDetailRequest]);

  useEffect(() =>
  {
    setdataDetaiState(dataDetail.retdata)
    console.log(dataDetail.retdata.data)
  },[dataDetail])

    return (
        <ScrollView>
       <View style={styles.headerDetail}>
      <TouchableOpacity
        style={styles.backPress}
        activeOpacity={1}
        onPress={onGoBack}
      >
        <BackIcon />
      </TouchableOpacity>
      
      <TouchableOpacity
        style={styles.thongTinLuanChuyen} onPress={gotoShareView}
      >
            <ShareBlueIcon/>
      </TouchableOpacity>
      <TouchableOpacity style={styles.shareIcon} onPress={gotoThongTInLuanChuyen}>
      <ClockWhiteIcon />
      </TouchableOpacity>
    </View>
      
      <View style={styles.headerDetail1}><Text style={styles.labelHeader}>NGƯỜI KHỞI TẠO DỰ ÁN</Text></View>
       <View style={styles.container}>
      <View style={styles.fieldContainer}>
        <Text style={styles.label}>NGƯỜI KHỞI TẠO DỰ ÁN</Text>
        <TextInput style={styles.input} placeholder="BIDV" />
      </View>

      <View style={styles.fieldContainer}>
        <Text style={styles.label}>TÊN DỰ ÁN</Text>
        <TextInput style={styles.input} placeholder="Du an moi" />
      </View>

      <View style={styles.fieldContainer}>
        <Text style={styles.label}>LOẠI DỰ ÁN</Text>
        <TextInput style={styles.input} placeholder="Enter Project Type" />
      </View>

      <View style={styles.fieldContainer}>
        <Text style={styles.label}>LĨNH VỰC ĐẦU TƯ</Text>
        <TextInput style={styles.input} placeholder="Enter Investment Field" />
      </View>

      <View style={styles.fieldContainer}>
        <Text style={styles.label}>ĐƠN VỊ ĐẦU MỐI</Text>
        <TextInput style={styles.input} placeholder="Enter Lead Agency" />
      </View>

      <View style={styles.fieldContainer}>
        <Text style={styles.label}>TỔNG MỨC ĐẦU TƯ ĐỀ XUẤT</Text>
        <TextInput style={styles.input} placeholder="Enter Proposed Investment Amount" />
      </View>
    </View>
        </ScrollView>
   
    )
  }
  const styles = StyleSheet.create({
    container: {
      flex: 1,
      padding: 16,
      backgroundColor: 'white'
    },
    headerDetail: {
      height: 50,
      backgroundColor:'white',
      flexDirection: "row",
      alignItems: "center",
      justifyContent: "space-between",
      
    },
    headerDetail1: {
      height: 65,
      backgroundColor:'lightgray'
    },
    fieldContainer: {
      marginBottom: 20,
      marginTop: 15
    },
    label: {
      fontSize: 14,
      fontWeight: 'thin',
      marginBottom: 8,
    },
    thongTinLuanChuyen: { 
      marginLeft: 255,},
    
    labelHeader:{
      padding: 15,
      color: '#0b5e5c',
      fontWeight: '500',
      fontSize: FontSize.SMALL,
      fontFamily: 'arial',
    },
    input: {
      padding: 8,
    },
    backPress: {
      padding: 8,
    },

    shareIcon: { 
      marginRight: 20,
    },
  });



export default HomeDetailScreen

function dispatch(arg0: AsyncThunkAction<any, any, { state?: unknown; dispatch?: Dispatch<AnyAction> | undefined; extra?: unknown; rejectValue?: unknown; serializedErrorType?: unknown; pendingMeta?: unknown; fulfilledMeta?: unknown; rejectedMeta?: unknown; }>) {
  throw new Error('Function not implemented.');
}
