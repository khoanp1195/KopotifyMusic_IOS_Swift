import { StyleSheet, Text, TextInput, Touchable, TouchableOpacity, View } from 'react-native'
import React, { Component, useCallback, useEffect, useState } from 'react'
import { ScrollView } from 'react-native-gesture-handler';
import { BackIcon, ClockWhiteIcon, ShareBlueIcon } from '../../assets/SVG';
import { FontSize } from '../../themes/const';
import { useDispatch, useSelector } from 'react-redux';
import { AnyAction, AsyncThunkAction, ThunkDispatch } from "@reduxjs/toolkit";
import { fetchGetWorkflowItem } from '../../store/home/reducer';
import { arrayIsEmpty } from '../../helpers/formater';

type Props = {
    navigation: any;
    route: any;
  };
const HomeDetailScreen = ({route, navigation}: Props) => {
  const dispatch = useDispatch<ThunkDispatch<any, any, any>>();
  const {workflowItemIDD, ListName,Title} = route.params;
  const [ItemID, setItemID] = useState("");
  // const [ListName, setListName] = useState("");
  const[dataDetailState,setdataDetaiState] = useState([]);
  const dataDetail = useSelector(
    (state: any) => state.home
  )
  const {
    TenDuAn,
    LinhVuc,
    DonViDauMoi,
    Author,
    YearCategory,
    TMDTDuKien,
    GoiThau,
    GiaGoiThau,
    PhuongThucDauThau,
    NgayNghiemThu,
    GiaTriQuyetToan
  } = dataDetail

  const onGoBack = useCallback(() => {
    navigation.goBack();
  }, []);
  const gotoThongTInLuanChuyen = useCallback(() =>
  {
    navigation.navigate({
      name: "ThongTinLuanChuyenScreen"
    })
  }, []);

  const gotoShareView = useCallback(() =>
  {
    navigation.navigate({
      name:"ShareViewScreen"
    })
  }, []);
  
  //Detail Content
  const fetchContentDetailRequest = useCallback(({workflowItemIDD, ListName}: any) =>{
    dispatch(     
      fetchGetWorkflowItem({workflowItemIDD, ListName}))
  },[dispatch]);

  useEffect(() => {
    fetchContentDetailRequest({workflowItemIDD, ListName})
  }, [fetchContentDetailRequest]);

  useEffect(() =>
  {
    setdataDetaiState(dataDetail.retdata)
  },[dataDetail])

  console.log(Title)


    return (
        <ScrollView style={styles.container}>
       <View style={styles.headerDetail}>
      <TouchableOpacity
        style={styles.backPress}
        activeOpacity={1}
        onPress={onGoBack}
      >
        <BackIcon />
      </TouchableOpacity>
      
      <TouchableOpacity
        style={styles.thongTinLuanChuyen} onPress={gotoShareView}
      >
            <ShareBlueIcon/>
      </TouchableOpacity>
      <TouchableOpacity style={styles.shareIcon} onPress={gotoThongTInLuanChuyen}>
      <ClockWhiteIcon />
      </TouchableOpacity>
    </View>
      
        <View style={styles.container}>
        <View style={styles.headerDetail1}><Text style={styles.labelHeader}>{Title}</Text></View>
       <View style={styles.syleContent}>
     
      <View style={styles.fieldContainer}>
        <Text style={styles.label}>NGƯỜI KHỞI TẠO DỰ ÁN</Text>
        <Text style={styles.input}>{dataDetail.retdata.Author}</Text>
      </View>

      <View style={styles.fieldContainer}>
        <Text style={styles.label}>TÊN DỰ ÁN</Text>
        <Text style={styles.input}>{dataDetail.retdata.TenDuAn}</Text>
      </View>

      <View style={styles.fieldContainer}>
        <Text style={styles.label}>LOẠI DỰ ÁN</Text>
        <Text style={styles.input}>{dataDetail.retdata.YearCategory}</Text>
      </View>

      <View style={styles.fieldContainer}>
        <Text style={styles.label}>LĨNH VỰC ĐẦU TƯ</Text>
        <Text style={styles.input}>{dataDetail.retdata.LinhVuc}</Text>
      </View>

      <View style={styles.fieldContainer}>
        <Text style={styles.label}>ĐƠN VỊ ĐẦU MỐI</Text>
        <Text style={styles.input}>{dataDetail.retdata.DonViDauMoi}</Text>
      </View>

      <View style={styles.fieldContainer}>
        <Text style={styles.label}>TỔNG MỨC ĐẦU TƯ ĐỀ XUẤT</Text>
        <Text style={styles.input}>{dataDetail.retdata.TMDTDuKien}</Text>
      </View>
    </View>
        </View>
        </ScrollView>
   
    )
  }
  const styles = StyleSheet.create({
    container: {
      flex: 1,
      padding: 0,
      backgroundColor: 'white'
    },
    syleContent: {
      flex: 1,
      padding: 20,
      backgroundColor: 'white'
    },
    headerDetail: {
      height: 50,
      backgroundColor:'white',
      flexDirection: "row",
      alignItems: "center",
      justifyContent: "space-between",
      
    },
    headerDetail1: {
      height: 65,
      backgroundColor:'lightgray'
    },
    fieldContainer: {
      marginBottom: 20,
      marginTop: 15
    },
    label: {
      fontSize: 12,
      color: 'gray', // Set the color property
      marginBottom: 8,
    },
    thongTinLuanChuyen: { 
      marginLeft: 255,},
    
    labelHeader:{
      padding: 15,
      color: '#0b5e5c',
      fontWeight: '500',
      fontSize: FontSize.SMALL,
      fontFamily: 'arial',
    },
    input: {
      fontSize: 14,
      padding: 0,
      color: '#0b5e5c',
      fontWeight: '400',
    },
    backPress: {
      padding: 8,
    },

    shareIcon: { 
      marginRight: 20,
    },
  });



export default HomeDetailScreen

function dispatch(arg0: AsyncThunkAction<any, any, { state?: unknown; dispatch?: Dispatch<AnyAction> | undefined; extra?: unknown; rejectValue?: unknown; serializedErrorType?: unknown; pendingMeta?: unknown; fulfilledMeta?: unknown; rejectedMeta?: unknown; }>) {
  throw new Error('Function not implemented.');
}
