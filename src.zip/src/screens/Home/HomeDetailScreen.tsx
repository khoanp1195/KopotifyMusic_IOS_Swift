import { FlatList, StyleSheet, Text, TextInput, Touchable, TouchableOpacity, View } from 'react-native'
import React, { Component, useCallback, useEffect, useState } from 'react'
import { ScrollView } from 'react-native-gesture-handler';
import { BackIcon, ClockWhiteIcon, ShareBlueIcon } from '../../assets/SVG';
import { FontSize } from '../../themes/const';
import { useDispatch, useSelector } from 'react-redux';
import { AnyAction, AsyncThunkAction, ThunkDispatch } from "@reduxjs/toolkit";
import { fetchGetWorkflowItem } from '../../store/home/reducer';
import { arrayIsEmpty, byteConverter, checkTypeFiles, format_dd_mm_yy, removeSpecialCharacters } from '../../helpers/formater';
import colors from '../../themes/Color';
import ReactDataGrid from '@inovua/reactdatagrid-community';
// import '@inovua/reactdatagrid-community/index.css';


type Props = {
    navigation: any;
    route: any;
  };
const HomeDetailScreen = ({route, navigation}: Props) => {
  const dispatch = useDispatch<ThunkDispatch<any, any, any>>();
  const {workflowItemIDD, ListName,Title} = route.params;
  const [ItemID, setItemID] = useState("");
  // const [ListName, setListName] = useState("");
  const[dataDetailState,setdataDetaiState] = useState([]);
  const[dataAttachmentState,setdataAttachmentState] = useState([]);
  const dataDetail = useSelector(
    (state: any) => state.home
  )
  const dataAttachment = useSelector(
    (state: any) => state.home
  )

  const {
    TenDuAn,
    LinhVuc,
    DonViDauMoi,
    Author,
    YearCategory,
    TMDTDuKien,
    GoiThau,
    GiaGoiThau,
    PhuongThucDauThau,
    NgayNghiemThu,
    GiaTriQuyetToan
  } = dataDetail

 const ItemAttach = ({item, index}: any) =>{
  const {Author, Created, Category, Size, FileRef, Tittle} = item
  const createdFormated =  Created ? format_dd_mm_yy(Created) : null;
  const sizeFormated = Size ? byteConverter(Size,0) : null;
  const FileIcon = () => {
      return checkTypeFiles(FileRef);
  };
  const isOdd = index % 2 === 0;
  return (
    <TouchableOpacity
    style={[styles.documentFileView,
    isOdd && {backgroundColor: colors.alice_blue},
  ]}
    onPress={() => gotoFileViewScreen(item)}
    >
      <View style={[styles.flexDirectionRowBetween]}>
      <View style={{marginTop: 5}}>
        <FileIcon/>
      </View>
      <Text style={styles.titleDocumentFile} numberOfLines={1}>
        {Title}
      </Text>

      <Text style={styles.contentAttach} numberOfLines={1}>
        {removeSpecialCharacters(Author)}
      </Text>

      </View>
      <View style={[styles.flexDirectionRowBetween,{
        alignItems: "flex-start", marginLeft: 20
      }]}>
        <Text style={styles.sizeDocumentFile} numberOfLines={1}>
          {sizeFormated}
        </Text>
        <Text style={{
          fontSize: FontSize.MEDIUM,
          color: colors.lightBlack,
          fontWeight: "400",
          fontFamily: "arial",
          marginLeft: 15,
          marginTop: 5
        }} numberOfLines={1}
        > {removeSpecialCharacters(Category)}</Text>
      <Text style={{
        fontSize: FontSize.MEDIUM,
        color: colors.lightBlack,
        fontWeight: "400",
        fontFamily: "arial",
        marginLeft: 15,
        marginTop: 5
      }} numberOfLines={1}>
        {createdFormated}
      </Text>
      </View>
    </TouchableOpacity>
  )
 }

  const onGoBack = useCallback(() => {
    navigation.goBack();
  }, []);
  const gotoThongTInLuanChuyen = useCallback(() =>
  {
    navigation.navigate({
      name: "ThongTinLuanChuyenScreen"
    })
  }, []);

  const gotoShareView = useCallback(() =>
  {
    navigation.navigate({
      name:"ShareViewScreen"
    })
  }, []);

  const gotoFileViewScreen = useCallback((item: any) => {

  },[])
  
  //Detail Content
  const fetchContentDetailRequest = useCallback(({workflowItemIDD, ListName}: any) =>{
    dispatch(     
      fetchGetWorkflowItem({workflowItemIDD, ListName}))
  },[dispatch]);

  useEffect(() => {
    fetchContentDetailRequest({workflowItemIDD, ListName})
  }, [fetchContentDetailRequest]);

  useEffect(() =>
  {
    setdataDetaiState(dataDetail.retdata)
  },[dataDetail])

  console.log("FileRef =>> " + dataAttachment.dataAttachment)

  console.log(Title)
// define columns
const columns = [
  { name: 'name', header: 'Name', minWidth: 50, defaultFlex: 2 },
  { name: 'age', header: 'Age', maxWidth: 1000, defaultFlex: 1 },
];
// define grid styles here
const gridStyle = { minHeight: 550 };
// define tabular data here
const dataSource = [
  { id: 1, name: 'John McQueen', age: 35 },
  { id: 2, name: 'Mary Stones', age: 25 },
  { id: 3, name: 'Robert Fil', age: 27 },
  { id: 4, name: 'Roger Robson', age: 81 },
  { id: 5, name: 'Billary Konwik', age: 18 },
  { id: 6, name: 'Bob Martin', age: 18 },
  { id: 7, name: 'Matthew Richardson', age: 54 },
  { id: 8, name: 'Ritchie Peterson', age: 54 },
  { id: 9, name: 'Bryan Martin', age: 40 },
  { id: 10, name: 'Mark Martin', age: 44 },
  { id: 11, name: 'Michelle Sebastian', age: 24 },
  { id: 12, name: 'Michelle Sullivan', age: 61 },
  { id: 13, name: 'Jordan Bike', age: 16 },
  { id: 14, name: 'Nelson Ford', age: 34 },
  { id: 15, name: 'Tim Cheap', age: 3 },
  { id: 16, name: 'Robert Carlson', age: 31 },
  { id: 17, name: 'Johny Perterson', age: 40 },
];
    return (
        <ScrollView style={styles.container}>
       <View style={styles.headerDetail}>
      <TouchableOpacity
        style={styles.backPress}
        activeOpacity={1}
        onPress={onGoBack}
      >
        <BackIcon />
      </TouchableOpacity>
      
      <TouchableOpacity
        style={styles.thongTinLuanChuyen} onPress={gotoShareView}
      >
            <ShareBlueIcon/>
      </TouchableOpacity>
      <TouchableOpacity style={styles.shareIcon} onPress={gotoThongTInLuanChuyen}>
      <ClockWhiteIcon />
      </TouchableOpacity>
    </View>
      
        <View style={styles.container}>
        <View style={styles.headerDetail1}><Text style={styles.labelHeader}>{Title}</Text></View>
       <View style={styles.syleContent}>
     
      <View style={styles.fieldContainer}>
        <Text style={styles.label}>NGƯỜI KHỞI TẠO DỰ ÁN</Text>
        <Text style={styles.input}>{dataDetail.retdata.Author}</Text>
      </View>

      <View style={styles.fieldContainer}>
        <Text style={styles.label}>TÊN DỰ ÁN</Text>
        <Text style={styles.input}>{dataDetail.retdata.TenDuAn}</Text>
      </View>

      <View style={styles.fieldContainer}>
        <Text style={styles.label}>LOẠI DỰ ÁN</Text>
        <Text style={styles.input}>{dataDetail.retdata.YearCategory}</Text>
      </View>

      <View style={styles.fieldContainer}>
        <Text style={styles.label}>LĨNH VỰC ĐẦU TƯ</Text>
        <Text style={styles.input}>{dataDetail.retdata.LinhVuc}</Text>
      </View>

      <View style={styles.fieldContainer}>
        <Text style={styles.label}>ĐƠN VỊ ĐẦU MỐI</Text>
        <Text style={styles.input}>{dataDetail.retdata.DonViDauMoi}</Text>
      </View>

      <View style={styles.fieldContainer}>
        <Text style={styles.label}>TỔNG MỨC ĐẦU TƯ ĐỀ XUẤT</Text>
        <Text style={styles.input}>{dataDetail.retdata.TMDTDuKien}</Text>
      </View>
    </View>
        </View>
        <View style={styles.viewTitleAttachment}>
        <Text style={styles.txtAttachment}>Chi tiết dự án</Text>
      </View>
     
      <View>
      <ReactDataGrid
    idProperty="id"
    columns={columns}
    dataSource={dataSource}
    style={gridStyle}
  />
      </View>
    
      <View style={styles.viewTitleAttachment}>
        <Text style={styles.txtAttachment}>Tài liệu đính kèm</Text>
      </View>
    {!arrayIsEmpty(dataAttachment.dataAttachment) && (
        <FlatList
          style={styles.containerAttach}
          nestedScrollEnabled
          extraData={dataAttachment.dataAttachment}
          disableVirtualization
          keyExtractor={(item, index) => item?.ID + index.toString()}
          data={dataAttachment.dataAttachment}
          renderItem={({ item, index }) => (
            <ItemAttach item={item} index={index} />
          )}
        />
      )}  
    
        
        </ScrollView>
   
    )
  }
  const styles = StyleSheet.create({
    container: {
      flex: 1,
      padding: 0,
      backgroundColor: 'white'
    },
    syleContent: {
      flex: 1,
      padding: 20,
      backgroundColor: 'white'
    },
    headerDetail: {
      height: 50,
      backgroundColor:'white',
      flexDirection: "row",
      alignItems: "center",
      justifyContent: "space-between",
      
    },
    headerDetail1: {
      height: 65,
      backgroundColor:'lightgray'
    },
    fieldContainer: {
      marginBottom: 20,
      marginTop: 15
    },
    label: {
      fontSize: 12,
      color: 'gray', // Set the color property
      marginBottom: 8,
    },
    thongTinLuanChuyen: { 
      marginLeft: 255,},
    
    labelHeader:{
      padding: 15,
      color: '#0b5e5c',
      fontWeight: '500',
      fontSize: FontSize.SMALL,
      fontFamily: 'arial',
    },
    input: {
      fontSize: 14,
      padding: 0,
      color: '#0b5e5c',
      fontWeight: '400',
    },
    backPress: {
      padding: 8,
    },

    shareIcon: { 
      marginRight: 20,
    },

    headerItem: {
      flex: 1,
      margin: 8,
      padding: 8,
      borderWidth: 1,
      borderColor: 'lightgray',
      backgroundColor: 'gray', // Header row background color
      flexDirection: 'row',
      justifyContent: 'space-between',
    },
    documentFileView: {
      padding: 15,
    },
    flexDirectionRowBetween: {
      flexDirection: "row",
      alignItems: "center",
      justifyContent: "space-between",
    },
    titleDocumentFile: {
      fontSize: FontSize.MEDIUM,
      color: colors.scienceBlue,
      fontWeight: "400",
      fontFamily:"arial",
      marginLeft: 15,
      marginTop: 5,
      borderRadius: 4,
    },
    contentAttach:{
      fontSize: FontSize.MEDIUM,
      color: colors.black,
      fontWeight: "400",
      fontFamily: "arial",
      marginLeft: 15,
      marginTop: 5
    },
    sizeDocumentFile:{
      fontSize: FontSize.MEDIUM,
      color: colors.lightBlack,
      fontWeight: "400",
      fontFamily: "arial",
      marginLeft: 15,
      marginTop: 5,
      borderRadius: 4,
    },
    containerAttach: {
      borderColor: colors.greyDDD,
      borderWidth: 1,
      borderRadius: 8,
      marginHorizontal: 15,
      overflow: "hidden"
    },
    viewTitleAttachment: {
      padding: 15
    },
    txtAttachment: {
      fontSize: FontSize.MEDIUM,
      color: '#0b5e5c',
      fontWeight: "600",
      fontFamily: "arial",
    }

  });



export default HomeDetailScreen

function dispatch(arg0: AsyncThunkAction<any, any, { state?: unknown; dispatch?: Dispatch<AnyAction> | undefined; extra?: unknown; rejectValue?: unknown; serializedErrorType?: unknown; pendingMeta?: unknown; fulfilledMeta?: unknown; rejectedMeta?: unknown; }>) {
  throw new Error('Function not implemented.');
}
