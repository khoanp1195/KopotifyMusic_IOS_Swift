import React, { useState, useCallback, useEffect, useMemo } from "react";
import {
  Text,
  View,
  processColor,
  ImageBackground,
  FlatList,
  TouchableOpacity,
  Platform,
  Dimensions,
  RefreshControl,
  Alert,
} from "react-native";
import { fetchDANGXLAPI, fetchDAXULYLAPI } from "../../store/home/reducer";
import { useDispatch, useSelector } from "react-redux";
import styles from "./HomeScreen.Style";
import { RootState } from "../../store";
import LinearGradient from "react-native-linear-gradient";
import { ThunkDispatch } from "@reduxjs/toolkit";
import { arrayIsEmpty, checkIsEmpty, formatCreatedDate,formatDueDate, isNullOrUndefined, removeSpecialCharacters } from "../../helpers/formater";
import { FilterIcon, LaCoIcon, MenuIcon } from "../../assets/SVG";
import { FontSize, dimensWidth, dimnensHeight } from "../../themes/const";
import {
  useSafeAreaInsets,
} from "react-native-safe-area-context";
import stylesItem from "./WaitProcessDocx.Style";
import { setCurrentUser, setSubSite } from "../../store/login/reducer";
import colors from "../../themes/Color";
import AsyncStorage from '@react-native-async-storage/async-storage';
import { TABNAME } from "./HomeType";
import messaging from '@react-native-firebase/messaging';
import DeviceInfo from 'react-native-device-info';
import * as RootNavigation from '../../navigation/RootNavigation';
import FilterModal from "./components/FilterModal";
import ImageLoad from "../../components/ImageLoad";
import { BaseUrl } from "../../services/api";
import FastImage from "react-native-fast-image";
import NoDataView from "../../components/NoDataView";
import { ActivityIndicator } from "react-native-paper";
import moment from "moment";
import CalendarPickerModal from "./components/CalendarPickerModal";

// const { subSite, token } = useSelector(
//   (state: any) => state.login
// );

type Props = {
  navigation: any;
  route: any;
};

//Item dang xu ly
const Item = ({ item, token, subSite, gotoDetail, index }: any) => {
  const {
    ID,
    ImagePath,
    Title,
    Created,
    TrangThai,
    Category,
    ListName,
    Status,
    DueDate
  } = item;
  const isOdd  = index % 2 === 0;
  const gotoDetailPress = () => {
    gotoDetail(ID);
  };
  const formatCreated = formatCreatedDate(Created);
  const formatDueDate1 = formatDueDate(DueDate)
  const isPastDue = formatDueDate1?.includes('Quá hạn');
  const textColor = isPastDue ? 'red' : 'black';

  return (
    <TouchableOpacity style={[stylesItem.item, isOdd && {backgroundColor: colors.alice_blue} ]} onPress={gotoDetailPress}>
      <View style={{ flex: 1 }}>
        <View style={stylesItem.flexDirectionBetween}>
          <Text style={stylesItem.title} numberOfLines={2}>
            {Title}
          </Text>
          <Text style={stylesItem.date}>{formatCreated}</Text>
        </View>
        <View style={stylesItem.flexDirectionBetween}>
          <Text style={stylesItem.category}>{Category}</Text>
        </View>
        <View style={stylesItem.chuyenDonViRow}>
          <View style={stylesItem.touchSendUnit}>
          {Status === 1 ? (
        <Text>Đã xử lý</Text>
      ) : (
        <Text>Đang xử lý</Text>
      )}
          </View>
          <View style={stylesItem.touchHanXl}>
          <Text style={{  fontSize: dimensWidth(13),
                          color: textColor,
                          fontWeight: '400',
                          fontFamily: 'arial',
                          marginBottom: 6,}}>{formatDueDate1}</Text>
          </View>
        </View>
      </View>
    </TouchableOpacity>
  );
};


//Item Da Xu Ly
const ItemDaXuLy = ({ item, token, subSite, gotoDetail, index }: any) => {
  const {
    ID,
    ImagePath,
    Title,
    Created,
    TrangThai,
    Category,
    ListName,
    Status,
    AssignedBy,
    PriorityName,
    SendUnit,
    DocumentID,
    DueDate
  } = item;
  const isOdd  = index % 2 === 0;
  const gotoDetailPress = () => {
    gotoDetail(ID);
  };
  const formatDueDate1 = formatCreatedDate(DueDate)
  const textColor = 'red';
  const formatCreated = formatCreatedDate(Created);
  return (
    <TouchableOpacity style={[stylesItem.item, isOdd && {backgroundColor: colors.alice_blue} ]} onPress={gotoDetailPress}>
      <View style={{ flex: 1 }}>
        <View style={stylesItem.flexDirectionBetween}>
          <Text style={stylesItem.title} numberOfLines={2}>
            {Title}
          </Text>
          <Text style={stylesItem.date}>{formatCreated}</Text>
        </View>
        <View style={stylesItem.flexDirectionBetween}>
          <Text style={stylesItem.category}>{Category}</Text>
        </View>
        <View style={stylesItem.chuyenDonViRow}>
          <View style={stylesItem.touchSendUnit}>
          {Status === 1 ? (
        <Text>Đã xử lý</Text>
      ) : (
        <Text>Đang xử lý</Text>
      )}
          </View>
          <View style={stylesItem.touchHanDaXl}>
          <Text style={{  fontSize: dimensWidth(13),
                          color: textColor,
                          fontWeight: '400',
                          fontFamily: 'arial',
                          marginBottom: 6,}}>{formatDueDate1}</Text>
          </View>
        </View>
      </View>
    </TouchableOpacity>
  );
};


const renderFooter = (isLoadingDangXuLy: boolean, refreshing: boolean, isLoadMoreDangXuly: boolean, Offset:any) => {
console.log("isLoadingDangXL: " + isLoadingDangXuLy)
console.log("refreshing: " + refreshing)
console.log("isLoadMoreDangXL + " + isLoadMoreDangXuly)
console.log("Offset" + Offset)
return (
    <View style={styles.footer}>
      {isLoadingDangXuLy && !refreshing && isLoadMoreDangXuly && Offset !== 0  ?(
        <ActivityIndicator color="#0b5e5c" style={{ marginLeft: 8}}/> ): null}
    </View>
  );
};


const HomeScreen = ({ route,navigation }: Props) => {
  const dispatch = useDispatch<ThunkDispatch<any, any, any>>();
  const [Offset, setOffset] = useState(0);
  let initialPayloadDANGXL = { limit:1000,offset: Offset}
  const isLoadMoreDangXuly  = useSelector(
    (state: any) => state.home
  );
  const isLoadingDangXuLy = useSelector((state: any) => state.home)
  
  const dataDXL = useSelector (
    (state: any) => state.home
  )
  const dataDaXL = useSelector (
    (state: any) => state.home
  )
  const totalRecord = useSelector(
    (state: any) => state.home
  )
  const { subSite, remoteMessage } = useSelector(
    (state: any) => state.login
  );
  const { token } = useSelector((state: RootState) => state.login);
  const [payloadDANGXL, setPayloadDANGXL] = useState<any>(initialPayloadDANGXL);
  const [payloadDAXL, setpayloadDAXL] = useState<any>(initialPayloadDANGXL);
  const [isFinish, setIsFinish] = useState(false)
  const [tabName, setTabName] = useState(TABNAME.DangXL);
  const [isFilter, setIsFilter] = useState(false)
  const [visbleModalFilter, setVisbleModalFiltert] = useState(false);
  const [dataDXLState, setDataDXLState] = useState([]);
  const [dataDaXLState, setDataDaXLState] = useState([]);
  const [dataDXLCountState, setdataDXLCountState] = useState([]);
  const [refreshing, setRefreshing] = useState(false);
  const [functionDangXL, setfunctionDangXL] = useState(funtionDangXuLy.DangXuLyTitle);
  const [functionDaXL, setfunctionDaXL] = useState(funtionDaXuLy.DaXuLyTitle);
  const [visibleModalFilter, setvisibleModalFilter] = useState(false)
  const [typeModal, settypeModal] = useState("startDate")
  const [isOpenCalendarPicker, setisOpenCalendarPicker] = useState(false);

  const todayFormated = moment().format("YYYY-MM-DD");
  const prevMonth = moment(todayFormated).add(-1,"M").format("YYYY-MM-DD");
  const [startDate, setstartDate] = useState(prevMonth)
  const[endDate, setEndDate] =  useState(todayFormated);

  useEffect(() => {
    if (route.params?.funtionDangXuLy) {
      setfunctionDangXL(route.params?.funtionDangXuLy)
      setOffset(0)
    }
  }, [route.params])

  const fetchDANGXLRequest = useCallback((payload: any) => {
    dispatch(fetchDANGXLAPI(payload));
  }, [dispatch]);

  useEffect(() => {
    const status = tabName === TABNAME.DangXL ? 'GetInprocessNotify' : 'GetCompletedNotify'
    fetchDANGXLRequest({...payloadDANGXL,status, Offset});
  }, [payloadDANGXL,Offset]);

  const onPressFilter = useCallback(() => {
    setVisbleModalFiltert(true);
  }, [visbleModalFilter]);


  const onReFilterModalPress = useCallback(() => {
    setVisbleModalFiltert(false);
  }, [visbleModalFilter]);

  const onRefresh = useCallback(() =>{
    setRefreshing(true);
    setOffset(0);
    setPayloadDANGXL(initialPayloadDANGXL)
    dispatch(fetchDANGXLAPI(initialPayloadDANGXL));

    // setpayloadDAXL(initialPayloadDANGXL)
    // dispatch(fetchDAXULYLAPI(initialPayloadDANGXL));
  },[refreshing]);

  useEffect(() => {
    setDataDXLState(dataDXL.data);
    setRefreshing(false)
  },[dataDXL])

 const countDangXuLy = totalRecord.totalRecord >=  99 ? '99+' : totalRecord.totalRecord;

  useEffect(() => {
    setDataDaXLState(dataDaXL.data)
    setRefreshing(false)
}, [dataDaXL])

const totalValue = totalRecord.totalRecord;
console.log(totalValue)
  const safeAreaParams = useSafeAreaInsets()

  const handleLoadmore = (() => {
    if(totalRecord.totalRecord  > dataDXL.data.length)
    {
      const newOffset = dataDXL.data.length;
      setOffset(newOffset);
      console.log("New Offset: => " + newOffset)
      setPayloadDANGXL({ ...payloadDANGXL,limit:100,offset:newOffset})
    }
  });

  const gotoDetailPress = useCallback((itemId: Number, listName: String) => {
    navigation.navigate({
      name: "HomeDetailScreen",
      params: { itemId, listName },
      
    })
  
  }, [dataDXL]);

  //changeTabDangXuly
  const changeTabDangXuly = useCallback(() => {
    setIsFilter(false)
    setOffset(0)
    setVisbleModalFiltert(false)
    let initialPayloadDANGXL = { status:'GetInprocessNotify',limit: 20, offset:0 }
    setPayloadDANGXL(initialPayloadDANGXL)
    setTabName(TABNAME.DangXL)
  }, [dataDXL, functionDangXL]);

 //changeTabDaXuLy
  const changeTabDaXuLy = useCallback(() => {
    setIsFilter(false)
    setVisbleModalFiltert(false)
    setOffset(0)
    let initialPayloadDAXL = {status:'GetCompletedNotify', limit: 120, offset:0 }
    setPayloadDANGXL(initialPayloadDAXL)
    setTabName(TABNAME.DaXL);
  }, [dataDXL, funtionDaXuLy]);

  //Press Open Calendar Picker
  const onPressOpenCalendarPicker = useCallback(
    (typeModal: string) => {
      setVisbleModalFiltert(false);
      settypeModal(typeModal);
      setisOpenCalendarPicker(true);
    },
  [isOpenCalendarPicker, typeModal]);

  //onDateChangeModal
  const onDateChangeModal = useCallback(
    (date: any) =>{
      if(typeModal == "startDate"){
        setstartDate(date);
      }
      else{
        setEndDate(date)
      }
      setisOpenCalendarPicker(false);
      setVisbleModalFiltert(true);
    },[typeModal, startDate, endDate]
  )

  const onCloseModal = useCallback(() => {
    setisOpenCalendarPicker(false);
  }, []);

  const removeSelectedDate = useCallback(() => {
    if(typeModal == "startDate"){
      setstartDate("");
    }else{
      setEndDate("");
    }
  },[typeModal, startDate, endDate])

  const resetToday = useCallback(() => {
    (today: any) => {
      if(typeModal == "startDate")
      {
        setstartDate(today);
      }else
      {
        setEndDate(today);
      }
    }
  },[typeModal, startDate,endDate])

  return (
    <View style = {styles.background_view}>
      <View style={styles.viewAvatar}>
      <Text style={styles.lbl_title}>Trang chủ</Text>
      <View style={styles.flexDirectionRow}>
            <TouchableOpacity style={styles.filterIcon} onPress={onPressFilter}>
              <FilterIcon color={isFilter ? 'red' : '#fff'} />
            </TouchableOpacity>
          </View>
      <View style={styles.flexDirectionRowTab}>
            <TouchableOpacity
              activeOpacity={1}
              onPress={changeTabDangXuly}
              style={
                tabName === TABNAME.DangXL
                  ? styles.onPressActiveTab
                  : styles.onPressInActiveTab
              }
            >
              <Text
                style={
                  tabName === TABNAME.DangXL
                    ? styles.titleActiveTab
                    : styles.titleInActiveTab
                }
              >   
                {TABNAME.DangXL}
                <Text style={styles.titleNotifyCount}>{` (${countDangXuLy})`}</Text>
                {/* <Text style={styles.titleNotifyCount}>{` (${totalRecordVBPhoiHop}) `}</Text> */}
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              activeOpacity={1}
             onPress={changeTabDaXuLy}
              style={
                tabName === TABNAME.DaXL
                  ? styles.onPressActiveTab
                  : styles.onPressInActiveTab
              }
            >
              <Text
                style={
                  tabName === TABNAME.DaXL
                    ? styles.titleActiveTab
                    : styles.titleInActiveTab
                }
              >
                {TABNAME.DaXL}
              </Text>
            </TouchableOpacity>
          </View>
        
          <View>

          </View>
           
      </View>
      
      {!arrayIsEmpty(dataDXLState) ? (
        <FlatList
        contentContainerStyle={styles.containerFlatList}
        data={dataDXLState}
        extraData={dataDXLState}
        refreshControl={
          <RefreshControl refreshing={isLoadingDangXuLy} onRefresh={onRefresh} tintColor='#0b5e5c' />
        }
        renderItem={({ item, index }) => (
          tabName === TABNAME.DangXL ? 
              <Item item={item} token={token} subSite={subSite} index={index} gotoDetail={gotoDetailPress}/>
              :  <ItemDaXuLy item={item} token={token} subSite={subSite} index={index} gotoDetail={gotoDetailPress}/>
        )}
        keyExtractor={(item,index) => String(index)}
        showsVerticalScrollIndicator={false}
        onEndReachedThreshold={0.5}
        onEndReached={handleLoadmore}
        ListFooterComponent={renderFooter(isLoadingDangXuLy,refreshing,isLoadMoreDangXuly,Offset)}
      
      />
      ) : (
        <NoDataView onRetryPress={function () {
            throw new Error("Function not implemented.");
          } } />
      )}
      <FilterModal
      onPressFilter={onPressFilter}
      confirmText={"Áp dụng"}
      refilterText={"Thiết lập lại"}
      modalVisible={visbleModalFilter}
      onReFilterModal={onReFilterModalPress}
      onPressOpenCalendarPicker={onPressOpenCalendarPicker}
      startDate={startDate}
      endDate={endDate}
      />

      <CalendarPickerModal
        modalCalendarVisible={isOpenCalendarPicker}
        onDateChangeModal={onDateChangeModal}
        onCloseModal={onCloseModal}
        startDate={startDate}
        endDate={endDate}
        typeModal={typeModal}
        removeSelectedDate={removeSelectedDate}
        resetToday={resetToday}
      />
      </View>     
  );
};

export default HomeScreen;

export const funtionDangXuLy = {
  DangXuLyTitle: {
    key: "DangXuLyTitle",
    title: "Đang xử lý",
  },
}
export const funtionDaXuLy = {
  DaXuLyTitle: {
    key: "DaXuLyTitle",
    title: "Đã xử lý",
  },
}