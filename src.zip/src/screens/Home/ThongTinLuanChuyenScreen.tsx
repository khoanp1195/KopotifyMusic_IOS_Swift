import React, { useCallback, useState, useEffect, useMemo } from "react";
import {
  View,
  FlatList,
  StyleSheet,
  Text,
  SectionList,
  TouchableOpacity,
  Alert,
  Image,
} from "react-native";
import { BackIcon, DashedLine, RetangleGreenIcon } from "../../assets/SVG/index";
import colors from "../../themes/Color";
import { dimensWidth, dimnensHeight, FontSize } from "../../themes/const";
import { useDispatch, useSelector } from "react-redux";
import {
  format_yy_mm_mm_dd_hh,
  arrayIsEmpty,
  removeSpecialCharacters,
  isNullOrUndefined,
  stripHtml,
} from "../../helpers/formater";
// import {
//   fetchThongTinLuanChuyenVbDi,
// } from "stores/VBDi/reducer";
import { ThunkDispatch } from "@reduxjs/toolkit";
import { create } from "react-test-renderer";
import FastImage from "react-native-fast-image";
import { BaseUrl } from "../../services/api";
import { RootState } from "../../store";
import NoDataView from "../../components/NoDataView";
import { fetchGetThongTinLuanChuyen } from "../../store/home/reducer";

type ItemProps = {
  index: number;
  item: any;
  subSite: any;
  token: any;
  isEnd: any
};
type Props = {
  navigation: any;
  route: any;
};

const Item = ({ item, index, subSite, token, isEnd }: ItemProps) => {
  const { SubmitAction, ImagePath, Position, FullName, Created, isLast, Action, Note,Email } = item;
  const formatSubmitActionText = useMemo(() => {
    const formatText = stripHtml(SubmitAction)
    return formatText
  }, [SubmitAction]);

  return (
    <View style={{ flex: 1, flexDirection: 'row' }}>
      <View style={{ marginLeft: 22 }}>
        <DashedLine color={isLast ? "#fff" : "#B3B3B3"} height="100%" width={2} />
      </View>
      <View
        style={styles.item}
      >
        <View style={[styles.flexDirectionRow, { marginTop: 10 }]}>
          <FastImage
            style={styles.itemAvatar}
            source={{
              uri: `${BaseUrl}/${subSite}${ImagePath}`,
              headers: { Authorization: `${token}` },
              priority: FastImage.priority.normal,
            }}
          />
          <View style={{ flex: 1 }}>
            <View style={styles.flexDirectionRow}>
              <Text style={styles.titleContent} numberOfLines={1}>
                {Email}
              </Text>
              <Text style={styles.date} numberOfLines={1}>
                {format_yy_mm_mm_dd_hh(Created)}
              </Text>
            </View>
            <View style={styles.flexDirectionRow}>
              <Text style={styles.titleContent} numberOfLines={1}>
                {removeSpecialCharacters(Position)}
              </Text>
              {
                SubmitAction && <View style={styles.viewSubmitAction}>
                  <Text style={styles.textSubmitAction}>
                    {formatSubmitActionText}
                  </Text>
                </View>
              }
            </View>
          </View>
        </View>
        {
          Note && <Text style={styles.textNoted} numberOfLines={1}>
            {Note}
          </Text>
        }
      </View>
    </View>

  );
};

const ThongTinLuanChuyen = ({ navigation, route }: Props) => {
  const dataThongtinLuanChuyen = useSelector((state: RootState) => state.home);
  const { subSite, token } = useSelector(
    (state: any) => state.login
  );
  const dispatch = useDispatch<ThunkDispatch<any, any, any>>();
  const workflowItemId = route?.params?.workflowItemIDD;
  const ListName = route?.params?.ListName;


  console.log("workflowItemIDD =>>> " + workflowItemId)
  const fetchGetThongTinLuanChuyenRequest = useCallback (
    ({workflowItemId,ListName}: any) =>{
      dispatch(
        fetchGetThongTinLuanChuyen({
          workflowItemId,
          ListName
        })
      );
    },[dispatch])

  useEffect(() => {
    fetchGetThongTinLuanChuyenRequest({workflowItemId,ListName});
  },[workflowItemId,fetchGetThongTinLuanChuyenRequest])

  console.log("dataThongtinLuanChuyen =>>>> " + dataThongtinLuanChuyen)

  const onGoBack = useCallback(() => {
    navigation.goBack();
  }, [navigation]);

  return (
    <View style={styles.container}>
      <View style={styles.viewHeader}>
        <View style={styles.flexDirectionRow}>
          <TouchableOpacity style={styles.backPress} onPress={onGoBack}>
            <BackIcon />
          </TouchableOpacity>
          <Text style={styles.titleHeader}>Thông tin luân chuyển</Text>
        </View>
      </View>
      {arrayIsEmpty(dataThongtinLuanChuyen.dataProcessHistory) ? (
        <NoDataView />
      ) : (
        <FlatList
            style={styles.containerAttach}
            nestedScrollEnabled
            extraData={dataThongtinLuanChuyen.dataProcessHistory}
            disableVirtualization
            keyExtractor={(item, index) => item?.ID + index.toString()}
            data={dataThongtinLuanChuyen.dataProcessHistory}
            renderItem={({ item, index }) => (
              <Item item={item} index={index} />
            )}
          />
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#F2F2F2",
  },
  containerAttach: {
    borderColor: colors.greyDDD,
    borderRadius: 8,
    marginTop: 0,
    marginHorizontal: 15,
    overflow: "hidden"
  },
  viewDSNguoiXem: {
    borderRadius: 8,
    overflow: "hidden",
    backgroundColor: colors.white,
  },
  viewUserName: { marginRight: 20, marginLeft: -8 },
  viewUserImage: {
    height: 40,
    width: 40,
    borderRadius: 20,
    marginLeft: 40,
  },
  flatlist: {
    borderRadius: 8,
    backgroundColor: colors.white,
    overflow: "hidden",
  },
  containerFlatlist: {
    margin: 15,
  },
  item: {
    flex: 1,
    paddingBottom: 20,
    paddingTop: 10
  },
  title: {
    fontSize: FontSize.MEDIUM,
    color: colors.textBlack19,
    fontWeight: "700",
    fontFamily: "arial",
  },
  titleContent: {
    fontSize: FontSize.MEDIUM,
    color: colors.textBlack19,
    fontWeight: "400",
    fontFamily: "arial",
    // marginLeft: 15,
    right:15,
    position:'absolute',
  },
  textNoted: {
    fontSize: FontSize.MEDIUM,
    color: colors.lightBlack,
    fontWeight: "400",
    fontFamily: "arial",
    marginLeft: 30,
    alignSelf: 'flex-start',
    marginTop: 10
  },
  content: {
    flex: 1,
    fontSize: dimensWidth(12),
    color: colors.textBlack19,
    fontWeight: "400",
    fontFamily: "arial",
    marginHorizontal: 10,
    backgroundColor: colors.lightBlue,
    paddingHorizontal: 15,
    paddingVertical: 4,
    borderRadius: 5,
    overflow: 'hidden',
  },
  viewSubmitAction: {
    backgroundColor: colors.lightBlue,
    marginHorizontal: 10,
    paddingHorizontal: 15,
    paddingVertical: 4,
    borderRadius: 5,
    overflow: 'hidden',
  },
  textSubmitAction: {
    fontSize: dimensWidth(12),
    color: colors.textBlack19,
    fontWeight: "400",
    fontFamily: "arial",
    flex: 1,
  },
  date: {
    fontSize: dimensWidth(13),
    color: colors.lightBlack,
    fontWeight: "400",
    fontFamily: "arial",
    marginLeft: 15,
    paddingHorizontal: 6,
    paddingVertical: 4,
  },
  viewHeader: {
    backgroundColor:  '#0b5e5c',
    height: 55,
    justifyContent: "center",
    width: "100%",
    paddingHorizontal: 10,
  },
  titleHeader: {
    fontSize: FontSize.MEDIUM,
    lineHeight: dimensWidth(20),
    color: colors.white,
    fontWeight: "400",
    fontFamily: "arial",
    marginLeft: 15,
  },
  flexDirectionRow: {
    flexDirection: "row",
    alignItems: "center",
  },
  itemAvatar: {
    height: dimensWidth(40),
    width: dimensWidth(40),
    borderRadius: dimensWidth(20),
    marginLeft: 30,
    marginTop: 5,
    alignSelf: 'flex-start'
  },
  flexDirectionRowBetween: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  backPress: {
    padding: 8,
  },
  onPressActiveTab: {
    height: 60,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: colors.white,
    borderBottomColor: colors.primary,
    borderBottomWidth: 1,
    paddingLeft: 20,
  },
  onPressInActiveTab: {
    height: 60,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: colors.white,
    paddingLeft: 20,
  },
  titleActiveTab: {
    fontSize: FontSize.MEDIUM,
    lineHeight: dimensWidth(20),
    color: colors.primary,
    fontWeight: "700",
    fontFamily: "arial",
  },
  titleInActiveTab: {
    fontSize: FontSize.MEDIUM,
    lineHeight: dimensWidth(20),
    color: colors.grey999,
    fontWeight: "400",
    fontFamily: "arial",
  },
  titleContentVBdenDSNguoiXem: {
    fontSize: FontSize.MEDIUM,
    color: colors.textBlack19,
    fontWeight: "400",
    fontFamily: "arial",
    marginBottom: 4
  },
  contentVBDenDSNguoiXem: {
    fontSize: dimensWidth(13),
    color: colors.lightBlack,
    fontWeight: "400",
    fontFamily: "arial",
  },
  positionVBDenDSNguoiXem: {
    fontSize: dimensWidth(13),
    color: colors.lightBlack,
    fontWeight: "400",
    fontFamily: "arial",
  },
});

export default ThongTinLuanChuyen;
