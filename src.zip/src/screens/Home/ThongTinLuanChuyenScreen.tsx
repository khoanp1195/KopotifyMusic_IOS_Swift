import { Text, View } from 'react-native'
import React, { Component } from 'react'

export class ThongTinLuanChuyenScreen extends Component {
  render() {
    return (
      <View>
        <Text>ThongTinLuanChuyenScreen</Text>
      </View>
    )
  }
}

export default ThongTinLuanChuyenScreen