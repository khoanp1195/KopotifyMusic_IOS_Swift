import { StyleSheet, Text, TextInput, Touchable, TouchableOpacity, View } from 'react-native'
import React, { Component, useCallback, useEffect, useMemo, useState } from 'react'
import { ScrollView } from 'react-native-gesture-handler';
import { BackIcon, ClockWhiteIcon, ShareBlueIcon, UserIcon } from '../../assets/SVG';
import { FontSize } from '../../themes/const';
import { useDispatch, useSelector } from 'react-redux';
import { AnyAction, AsyncThunkAction, ThunkDispatch } from "@reduxjs/toolkit";
import { fetchGetWorkflowItem } from '../../store/home/reducer';
import TextInputCustom from '../../components/TextInputCustom';

type Props = {
  navigation: any;
  route: any;
};
const ShareViewScreen = ({route, navigation}: Props) => {
const dispatch = useDispatch<ThunkDispatch<any, any, any>>();
const [ItemID, setItemID] = useState("");
const [ListName, setListName] = useState("");

const dataDetail = useMemo( () =>{
  const shareItem = route?.params?.item;
},[route?.params])

const onGoBack = useCallback(() => {
  navigation.goBack();
}, []);
const gotoThongTInLuanChuyen = useCallback(() =>
{
  navigation.navigate({
    name: "ThongTinLuanChuyenScreen"
  })
}, []);

const gotoShareView = useCallback(() =>
{
  navigation.navigate({
    name:"ShareViewScreen"
  })
}, []);

  return (
      <ScrollView style={styles.container}>
     <View style={styles.headerDetail}>
    <TouchableOpacity
      style={styles.backPress}
      activeOpacity={1}
      onPress={onGoBack}
    >
      <BackIcon />
      
    </TouchableOpacity>
    <TouchableOpacity
      style={styles.iconShare} onPress={gotoShareView}
    >
          <ShareBlueIcon/>
    </TouchableOpacity>
      <Text style={styles.lblShare}>Chia sẻ</Text>

  </View>
  <View>
    <Text>Chọn người hoặc nhóm người muốn chia sẻ</Text>
<TouchableOpacity>   
   <View style={styles.textInput}>
                    
                    <TextInputCustom
                      placeholder="Enter user"
                      
                    /> 
                    <View style={styles.iconUser}>
                    <UserIcon />
                    </View>
                  
                  </View>
</TouchableOpacity>

                   <Text style={styles.txtYkien}>Ý kiến</Text>
                   <TextInput placeholder="Nhập ý kiến..." style={styles.textInputYKien}></TextInput>
                   <Text style={styles.txtYkien}>Lịch sử chia sẻ: </Text>         
  </View>
      </ScrollView>
 
  )
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    backgroundColor: 'white'
  },

  headerDetail1: {
    height: 65,
    backgroundColor:'lightgray'
  },
  fieldContainer: {
    marginBottom: 20,
    marginTop: 15
  },
  label: {
    fontSize: 14,
    fontWeight: 'thin',
    marginBottom: 8,
  },
  labelHeader:{
    padding: 15,
    color: '#0b5e5c',
    fontWeight: '500',
    fontSize: FontSize.SMALL,
    fontFamily: 'arial',
  },
  input: {
    padding: 8,
  },
  backPress: {
    paddingStart:   8,

  },

  shareIcon: { 
    marginRight: 20,
  },
  headerDetail: {
    height: 80,
    backgroundColor: 'white',
    flexDirection: "row",
  },
  iconShare: {
    marginRight: 8, 
    color: 'rgba(128, 128, 128, 0.5)',
    marginTop:5,
    paddingStart: 120
  },
  iconUser: {
    right: 10,
    top: 25,
    color: 'rgba(128, 128, 128, 0.5)',
    position: 'absolute',
    marginTop: -20
  },
  lblShare: {
    color: '#0b5e5c', // Set text color to white (since backgroundColor is '#0b5e5c')
    fontWeight: '500',
    fontSize: FontSize.LARGE,
    fontFamily: 'arial',
    textAlign: 'center',
    marginTop:10,
    paddingHorizontal: 8, // Add horizontal padding to the label
  },

  textInput: {
    backgroundColor: 'white',
    borderWidth: 1,
    borderColor: 'lightgray',
    borderRadius: 5,
    padding: 10,
    marginTop: 10,
    color: 'black',
  },
  containerTextInput: {
    flexDirection: 'row',
    alignItems: 'center',
    height: 50,
    width: 550,
    backgroundColor: '#fff',
    borderRadius: 8,

  },
  txtYkien: {
    marginTop: 20,
    color: '#0b5e5c'
  },
  textInputYKien: {
    backgroundColor: 'white',
    borderWidth: 1,
    borderColor: 'lightgray',
    borderRadius: 5,
    padding: 10,
    marginTop: 10,
    color: 'black',
    height: 150,


  },
  
});



export default ShareViewScreen