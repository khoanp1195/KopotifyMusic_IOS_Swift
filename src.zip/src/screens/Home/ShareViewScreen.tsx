import { Text, View } from 'react-native'
import React, { Component } from 'react'

export class ShareViewScreen extends Component {
  render() {
    return (
      <View>
        <Text>ShareViewScreen</Text>
      </View>
    )
  }
}

export default ShareViewScreen