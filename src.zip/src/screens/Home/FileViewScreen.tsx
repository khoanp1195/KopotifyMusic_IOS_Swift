import React, { useCallback, useState, useEffect, useMemo } from "react";
import {
  SafeAreaView,
  View,
  FlatList,
  StyleSheet,
  Text,
  StatusBar,
  ActivityIndicator,
  PermissionsAndroid,
  Platform
} from "react-native";
import { BackIcon, DownloadIcon } from "../../assets/SVG/index";
import colors from "../../themes/Color";
import { dimensWidth, FontSize } from "../../themes/const";
import { TouchableOpacity } from "react-native-gesture-handler";
import { WebView } from "react-native-webview";
import { format_dd_mm_yy, removeSpecialCharacters } from "../../helpers/formater";
import { BaseUrl } from "../../services/api";
import RNFetchBlob from 'react-native-fetch-blob';
import { getExtension, checkMimeTypeFiles } from '../../helpers/formater'
import { useDispatch, useSelector } from "react-redux";
import moment from "moment";

type Props = {
  navigation: any;
  route: any;
};

const App = ({ navigation, route }: Props) => {
  const { token } = useSelector(
    (state: any) => state.login
  );

  const onGoBack = useCallback(() => {
    navigation.goBack();
  }, []);

  const dataAttach = useMemo(() => {
    const attachItem = route?.params?.item;
    if (!attachItem) return {};
    return {
      Author: attachItem?.Author,
      Created: format_dd_mm_yy(attachItem?.Created),
      Size: attachItem?.Size + "KB",
      Url: BaseUrl + attachItem.FileRef,
      Title: attachItem?.Title,
    };
 
  }, [route?.params]);
 
  const requestWritePermission = async () => {
    try {
      const granted = await PermissionsAndroid.request(
        PermissionsAndroid.PERMISSIONS.WRITE_EXTERNAL_STORAGE,
        {
          title: 'Storage Permission',
          message: 'Your app needs access to storage to download files.',
          buttonPositive: 'OK',
          buttonNegative: 'Cancel',
        },
      );
      return granted === PermissionsAndroid.RESULTS.GRANTED;
    } catch (err) {
      console.warn(err);
      return false;
    }
  };

  const downloadFile = async () => {
    const { fs, config } = RNFetchBlob;
    const { dirs } = RNFetchBlob.fs;
    const downloadDir = Platform.OS == 'ios' ? dirs.DocumentDir : dirs.DownloadDir
    const typeFile = getExtension(dataAttach?.Url)
    const mimeType = checkMimeTypeFiles(dataAttach?.Url);
    const milisecond = moment().valueOf()
    const filename = dataAttach?.Url.substring(dataAttach?.Url.lastIndexOf('/') + 1, dataAttach?.Url.length)
    const localPath = `${downloadDir}/${milisecond}_${filename}`
    const options = {
      fileCache: true,
      useDownloadManager: true,
      notification: true,
      mediaScannable: true,
      mime: mimeType,
      title: `${filename}`,
      path: `${localPath}`,
      description: 'Downloading file...',
    };
    const configOptions = Platform.select({
      ios: {
        fileCache: options.fileCache,
        title: options.title,
        path: options.path,
        appendExt: typeFile,
      },
    });
    config(configOptions)
      .fetch('GET', encodeURI(dataAttach?.Url), {
        Authorization: `${token}`,
        "Content-Type": "multipart/form-data",
      })
      .then((res) => {
        RNFetchBlob.fs.writeFile(options.path, res.data, 'base64');
        RNFetchBlob.ios.previewDocument(options.path);
      })
      .catch((error) => {
        alert("Tải tệp thất bại!")
      });
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.viewHeader}>
        <View style={styles.flexDirectionRow}>
          <TouchableOpacity
            style={styles.backPress}
            activeOpacity={1}
            onPress={onGoBack}
          >
            <BackIcon />
          </TouchableOpacity>
          <Text style={styles.titleHeader} numberOfLines={1}>
            {dataAttach?.Title}
          </Text>
          <TouchableOpacity onPress={downloadFile}>
            <DownloadIcon />
          </TouchableOpacity>

        </View>
      </View>

      <View style={styles.flatlist}>
        <WebView
          source={{ uri: dataAttach?.Url }}
          style={{ flex: 1 }}
          sharedCookiesEnabled
          thirdPartyCookiesEnabled
          allowFileAccess
          cacheEnabled
        />
      </View>
    </SafeAreaView>
  );
};
const renderLoading = () => (
  <View
    style={{ height: "100%", justifyContent: "center", alignItems: "center" }}
  >
    <ActivityIndicator color={"#025ED8"} />
  </View>
);
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#F2F2F2",
  },
  flatlist: {
    flex: 1,
    backgroundColor: "#FFFFFF",
    borderRadius: 8,
    overflow: "hidden",
  },
  item: {
    flexDirection: "row",
    justifyContent: "space-between",
    padding: 20,
    borderStyle: "dashed",
    borderTopWidth: 1,
    borderTopColor: "#E5E5E5",
  },
  title: {
    fontSize: FontSize.LARGE,
    lineHeight: dimensWidth(20),
    color: colors.black,
    fontWeight: "400",
    fontFamily: "arial",
    marginHorizontal: 15,
  },
  viewHeader: {
    backgroundColor: 'white',
    height: 55,
    justifyContent: "center",
    width: "100%",
    paddingHorizontal: 10,
  },
  titleHeader: {
    fontSize: FontSize.MEDIUM,
    lineHeight: dimensWidth(20),
    color: colors.white,
    fontWeight: "400",
    fontFamily: "arial",
    marginLeft: 15,
    marginRight: 15,
    flex: 1,
  },
  flexDirectionRow: {
    flexDirection: "row",
    alignItems: "center",
  },
  backPress: {
    padding: 8,
  },
});

export default App;
