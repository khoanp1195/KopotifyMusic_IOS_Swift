import { StyleSheet, Platform } from 'react-native';
import colors from '../../themes/Color';
import { dimensWidth, dimnensHeight, FontSize } from '../../themes/const';
import { Positions } from 'react-native-calendars/src/expandableCalendar';

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0000',
  },
  avatar: {
    marginRight: dimensWidth(12),
    marginLeft: dimensWidth(15),
  },
  processingDocx: {
    padding: 20,
    marginLeft: dimensWidth(10),
    borderRadius: dimensWidth(10),
    height: 190,
    margin: 5
  },
  coordinationDocx: {
    padding: 20,
    marginRight: dimensWidth(8),
    justifyContent: 'center',
    borderRadius: dimensWidth(10),
    height: 90,
    margin: 5
  },
  imgNotification: {
    padding: 20,
    // position: 'absolute',
    // bottom: dimensWidth(5),
    // height: dimensWidth(120),
    width: dimensWidth(200),
    marginRight: dimensWidth(8),
    borderRadius: dimensWidth(10),
  },
  viewAvatar: {
    backgroundColor: '#ffff',
    height: 100,
    justifyContent: 'center',
    width: '100%',
  },
  titleAvatar: {
    fontSize: FontSize.LARGE_XXX,
    lineHeight: dimensWidth(30),
    color: colors.white,
    fontWeight: '400',
    fontFamily: 'arial',
  },
  dashboard: {
    fontSize: FontSize.LARGE_XX,
    lineHeight: dimensWidth(26),
    color: colors.white,
    fontWeight: '700',
    fontFamily: 'arial',
    marginLeft: dimensWidth(15),
    marginBottom: dimensWidth(6),
  },
  titleDashboard: {
    fontSize: 70,
    color: colors.white,
    fontWeight: '700',
    fontFamily: 'arial',
    marginBottom: dimensWidth(6),
  },
  flexDirectionRow: {
    flexDirection: 'row',
    backgroundColor: colors.white,
    justifyContent: 'space-between',

  },
  contentDashboard: {
    fontSize: FontSize.LARGE,
    color: colors.white,
    fontWeight: '700',
    fontFamily: 'arial',
  },
  titleVanban: {
    fontSize: 38,
    color: colors.white,
    fontWeight: '700',
    fontFamily: 'arial',
    marginBottom: dimensWidth(6),
  },
  contentVanban: {
    fontSize: FontSize.SMALL,
    color: colors.white,
    fontWeight: '700',
    fontFamily: 'arial',

  },
  contentDescription: {
    fontSize: FontSize.MEDIUM,
    color: colors.black,
    fontWeight: '400',
    fontFamily: 'arial',
  },
  squareDescription: { height: 18, width: 18, marginRight: 5, borderRadius: 5 },
  viewDescription: {
    position: 'absolute',
    bottom: 30,
    flexDirection: 'row',
    marginHorizontal: 15,
    justifyContent: 'center',
    alignItems: 'center',
    width: '100%',
  },
  viewTitleChart: {
    position: 'absolute',
    top: 0,
    marginTop: 30,
    width: '100%',
    alignItems: 'center',
    zIndex: 99,
  },
  titleChart: {
    fontSize: FontSize.LARGE_X,
    color: colors.black,
    fontWeight: '700',
    fontFamily: 'arial',
  },
  viewContainerChart: {
    flex: 1,
    borderTopLeftRadius: 37,
    borderTopRightRadius: 37,
    overflow: 'hidden',
    marginTop: 14,
    backgroundColor: 'white',
    // height: dimnensHeight(350)
  },
  viewChart: {
    // width: '135%',
    // height: '135%',
    // marginLeft: -dimensWidth(70),
    // marginTop: -15,
  },
  viewChartIos: {
    width: '115%',
    height: '115%',
    marginLeft: -30,
    // marginTop: -15,
  },
  flexOne: {
    flex: 1,
    flexDirection: 'row',
  },

  background_view: {
    flex: 1,
    backgroundColor: 'white',
  },

  lbl_title: {
    color: "#00524E",
    fontSize: 16,
    fontWeight: 'bold',
    marginHorizontal: 10
  },


  flexDirectionRowTab: {
    flexDirection: 'row',
    alignItems: 'center',
    alignSelf: 'baseline',
    marginLeft: 8,
    marginTop: 5,
    backgroundColor: '#0b5e5c',//colors.tab_bg_blue,
    borderColor: colors.white,
    borderWidth: 1,
    padding: 0,
    height: dimensWidth(37),
    borderRadius: dimensWidth(18),
  },

  onPressActiveTab: {
    paddingVertical: 6,
    paddingHorizontal: 12,
    backgroundColor: colors.white,
    borderRadius: dimensWidth(18),
    marginHorizontal: 1
  },
  onPressInActiveTab: {
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: dimensWidth(18),
  },
  titleActiveTab: {
    fontSize: FontSize.MEDIUM,
    lineHeight: dimensWidth(20),
    color: '#0b5e5c',//colors.primary
    fontWeight: '700',
    fontFamily: 'arial',
  },
  titleInActiveTab: {
    fontSize: FontSize.MEDIUM,
    lineHeight: dimensWidth(20),
    color: colors.white,
    fontWeight: '400',
    fontFamily: 'arial',
  },
  filterIcon: {
    width: 20,      
    height: 20,     
    position: 'absolute',
    top: 10,    
    right: 10,      
  },

  titleNotifyCount: {
    fontSize: FontSize.MEDIUM,
    lineHeight: dimensWidth(20),
    color: colors.orange,
    fontWeight: '700',
    fontFamily: 'arial',
  },

  containerFlatList: {
    marginTop: dimensWidth(15),

  },

  footer: {
    padding: 10,
    justifyContent: 'center',
    alignItems: 'center',
    flexDirection: 'row',
  },

  listItem: {
    padding: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#CCCCCC',
  },
});
export default styles;
