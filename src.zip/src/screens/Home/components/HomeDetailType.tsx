export enum ActionJsonType {
    null,
    DongY = "btnNext",
    PheDuyet = "btnApproved",
    ChuyenXuLy = "btnForward",
    YeuCauHieuChinh = "btnReturn",
    TuChoi = "btnReject",
    ThuHoi = "btnRecall",
    YeuCauBoSung = "btnRequestInfo",
    ChiaSe = 256,
    
}