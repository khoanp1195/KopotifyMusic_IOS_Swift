export enum TABNAME {
    DangXL = "Đang xử lý",
    DaXL = "Đã xử lý",
  }