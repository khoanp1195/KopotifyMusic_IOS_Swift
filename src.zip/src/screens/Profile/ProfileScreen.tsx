import React, { useCallback, useEffect } from 'react';
import { View, Text, StyleSheet, Image,  TouchableOpacity, Alert } from 'react-native';
import { UserGreyIcon } from '../../assets/SVG';
import { ThunkDispatch } from "@reduxjs/toolkit";
import { useDispatch, useSelector } from 'react-redux';
import { fetchCurrentUsers, logout, setCurrentUser } from '../../store/profile/reducer';
import { arrayIsEmpty } from '../../helpers/formater';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { logoutAction } from '../../store/login/reducer';

const UserProfileScreen = () => {
  const dispatch = useDispatch<ThunkDispatch<any,any,any>>();
  const dataCurrentUser = useSelector(
    (state: any) => state.profileReducer
  )

    const fetchUserProfileRequest = useCallback((payload: any) => {
        dispatch(fetchCurrentUsers(payload));
    },[dispatch])

    useEffect(() => {
      fetchUserProfileRequest({});
    }, [fetchUserProfileRequest]);
    
    useEffect(() => {
      if(!arrayIsEmpty(dataCurrentUser))
      {
        dispatch(setCurrentUser(dataCurrentUser))
      }
    },[dataCurrentUser])

    const onLogout = useCallback(() =>
    {
      Alert.alert('Thông báo', 'Bạn có chắc chắn muốn đăng xuất không ?', [
        {
          text: 'Hủy',
          style: 'cancel'
        },
        {text: 'Đăng xuất', onPress:() => signOut()},
      ])
    }, []);
    const signOut = async () => {
      const deviceId = await AsyncStorage.getItem('deviceId')
      dispatch(logout({deviceId}))
      dispatch(logoutAction())
    }
    // console.log(dataCurrentUser.dataCurrentUsers)

  // Mock user data
  const userData = {
    fullName: dataCurrentUser.dataCurrentUser?.AccountName,
    department: dataCurrentUser.dataCurrentUsers?.Department,
    position: dataCurrentUser.dataCurrentUsers?.Position.split(';#')[1],
    email: dataCurrentUser.dataCurrentUsers?.Email,
    employeeID: dataCurrentUser.dataCurrentUsers?.StaffID,
  };

  return (
    <View style={styles.container}>
      <View style={styles.viewTitle1}>
      <UserGreyIcon/>
      <Text style={styles.fieldTitle1}>Thông tin cá nhân</Text>
      </View>

      <View style={styles.viewTitle2}>
      <Image
        source={require('../../assets/images/avatar80.png')} // Replace with your image path
        style={styles.image}
      />
      <Text style={styles.fullName}>{userData.email}</Text>
      </View>


      <View style={styles.viewTitleInfo}>
        <Text style={styles.fieldLabel}>Đơn vị:</Text>
        <Text style={styles.fieldValue}>{userData.department}</Text>
      </View>
      <View style={styles.grayLine} />
      <View style={styles.viewTitleInfo}>
        <Text style={styles.fieldLabel}>Chức Vụ:</Text>
        <Text style={styles.fieldValue}>{userData.position}</Text>
      </View>
      <View style={styles.grayLine} />
      <View style={styles.viewTitleInfo}>
        <Text style={styles.fieldLabel}>Email:</Text>
        <Text style={styles.fieldValue}>{userData.email}</Text>
      </View>
      <View style={styles.grayLine} />
      <View style={styles.viewTitleInfo}>
        <Text style={styles.fieldLabel}>Mã nhân viên:</Text>
        <Text style={styles.fieldValue}>{userData.employeeID}</Text>
      </View>
      <View style={styles.grayLine} />
      <View style={styles.buttunSignout}>
      <TouchableOpacity style={styles.signInButton} onPress={onLogout}>
        <Text style={styles.buttonText}>Đăng xuất</Text>
      </TouchableOpacity>
      </View>
   


    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ffff'
  },
  avatar: {
    width: 100,
    height: 100,
    borderRadius: 50,
    marginBottom: 16,
  },
  fullName: {
    fontSize: 20,
    fontWeight: 'bold',
    marginTop: 100,
    textAlign: 'center',
    color:'#0b5e5c'

  },
  fieldContainer: {
    flex: 1,
  },
  fieldLabel: {
    marginRight: 8,
    fontSize: 18,   
     color: 'rgba(128, 128, 128, 0.5)',
  },
fieldTitle:{
  marginStart: 10
},
 

  fieldValue: {
    marginLeft: 20,
    fontSize: 18,   
    color: '#0b5e5c',
  },
  icon: {
    marginRight: 10,
  },
  viewTitle1: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 10,
    paddingHorizontal: 116,
    backgroundColor: '#FFFF',
  },

  viewTitleInfo: {
    flexDirection: 'row',
    paddingVertical: 10,
    paddingHorizontal: 20,
    height: 50,
    backgroundColor: '#FFFF',
  },


  fieldTitle1: {
    fontSize: 18,
    fontWeight: 'bold',
    marginLeft: 20,
    color: '#0b5e5c',
  },

  viewTitle2: {
    height: 220,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(128, 128, 128, 0.2)',
 
  },
  image: {
    width: 100,
    height: 100,
    borderRadius: 50, // Make the image round for an avatar effect
    marginBottom: -65, 
  },

  grayLine: {
    width: '90%', // Set the desired width of the line
    height: 1, 
    marginLeft: 10,   // Set the height of the line
    backgroundColor: 'rgba(128, 128, 128, 0.3)', // Gray color
  },


  buttunSignout:{
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 40,
    backgroundColor: '#ffff',
    borderColor: '#0b5e5c'
  },

  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  signInButton: {
    backgroundColor: '#ffff', // Blue color
    paddingVertical: 10,
    paddingHorizontal: 20,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 8,
    width: 200,
    height: 50,
    borderColor: '#0b5e5c',
    borderWidth: 1

  },
  buttonText: {
    color: '#0b5e5c',
    fontWeight: 'bold',
    fontSize: 18,
  },
});

export default UserProfileScreen;
