import React, { useEffect } from 'react';
import { View, StyleSheet } from 'react-native';
import { WebView } from 'react-native-webview';
import { RootState } from '../../store';
import { ThunkDispatch } from "@reduxjs/toolkit";
import { useDispatch, useSelector } from 'react-redux';
// import CookieManager from 'react-native-cookies';


const ReportScreen = () => {
  const dispatch = useDispatch<ThunkDispatch<any, any, any>>();
  const { token } = useSelector((state: RootState) => state.login);
  const url = 'https://bidvdpm.vuthao.com';
  const domain = url.split('https://')[1];
  // useEffect(() => {
  //   // Get cookies
  //   CookieManager.get('https://bidvdpm.vuthao.com').then((cookies: any) => {
  //     console.log('Cookies:', cookies);
  //   });
  // }, []);
  const setCookies = `
    document.cookie = "${token}; path=/; domain=${url}";
  `;
  console.log(setCookies)
  const onLoadEnd = () => {
    // Do something after the WebView finishes loading
  };

  return (
    <View style={styles.container}>
      <WebView
        injectedJavaScript={setCookies}
        source={{ uri: 'https://bidvdpm.vuthao.com/report/default.aspx?' }} 
        onLoadEnd={onLoadEnd}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
});

export default ReportScreen;
