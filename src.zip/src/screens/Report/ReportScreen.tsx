import React, { useEffect } from 'react';
import { View, StyleSheet } from 'react-native';
import { WebView } from 'react-native-webview';
import { RootState } from '../../store';
import { ThunkDispatch } from "@reduxjs/toolkit";
import { useDispatch, useSelector } from 'react-redux';
// import CookieManager from 'react-native-cookies';


const ReportScreen = () => {
  const dispatch = useDispatch<ThunkDispatch<any, any, any>>();
  const { token } = useSelector((state: RootState) => state.login);
  const url = 'https://bidvdpm.vuthao.com';
  const domain = url.split('https://')[1];
  const setCookies = `
    document.cookie = "${token}; path=/; domain=${url}";
  `;
  console.log(setCookies)
  return (
    <View style={styles.container}>
        <WebView
          source={{ uri: 'https://bidvdpm.vuthao.com/report/default.aspx?' }}
          style={{ flex: 1 }}
          sharedCookiesEnabled
          thirdPartyCookiesEnabled
          allowFileAccess
          cacheEnabled
        />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
});

export default ReportScreen;
