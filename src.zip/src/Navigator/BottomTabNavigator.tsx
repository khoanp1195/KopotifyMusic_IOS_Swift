import React from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import HomeScreen from '../screens/Home/HomeScreen'; // Import your screens
import LoginScreen from '../screens/Login/LoginScreen';
import RegisterScreen from '../screens/Login/RegisterScreen';
import { UserIcon } from '../assets/SVG';
import { UserGreyIcon } from '../assets/SVG';
import {TabHomeIcon} from '../assets/SVG';
import {TabReportIcon} from '../assets/SVG';
// import ReportScreen from '../screens/Report/ReportScreen';
import {
  ImageBackground, Image, KeyboardAvoidingView,
  Platform,
  TouchableWithoutFeedback,
  Keyboard, View, Alert,Text
} from 'react-native';
import styles from '../screens/Login/Login.Style';
import ReportScreen from '../screens/Report/ReportScreen';
import ProfileScreen from '../screens/Profile/ProfileScreen';
import { createStackNavigator } from '@react-navigation/stack';
import HomeDetailScreen from '../screens/Home/HomeDetailScreen';

const Stack = createStackNavigator();
const Tab = createBottomTabNavigator();

const BottomTabNavigator = () => {
  return (
    <Tab.Navigator>
      <Tab.Screen
        name="Home"
        component={HomeStack}
        options={{
          headerShown: false,
          tabBarIcon: ({ focused, color, size }) => (
            <TabHomeIcon color={focused ? "#FF0000" : color} size={size} />
          ),
        }}
       
      />
      <Tab.Screen
        name="Báo cáo"
        component={ReportScreen}
        options={{
          headerShown: false,
          tabBarIcon: ({ focused, color, size }) => (
            <TabReportIcon/>
          
          ),
        }}
      />
      <Tab.Screen
        name="Cá nhân"
        component={ProfileScreen}
        options={{
          headerShown: false,
          tabBarIcon: ({ focused, color, size }) => (
            <UserGreyIcon/>
          ),
        }}
      />
    </Tab.Navigator>
  );
};
function HomeStack() {
  return (
    <Stack.Navigator
      initialRouteName="HomeScreen"
      screenOptions={{
        headerShown: false,
    
      }}
    >
      <Stack.Screen
        name="HomeScreen"
        component={HomeScreen}
        options={{
          gestureEnabled: true,
          gestureDirection: "horizontal",
          headerShown: false,
          
        }}
      />
      <Stack.Screen
        name="HomeDetailScreen"
        component={HomeDetailScreen}
        options={{
          gestureEnabled: true,
          gestureDirection: "horizontal",
          headerShown: false,
          tabBarVisible: false
        }}

/>
    </Stack.Navigator>
  );
}

export default BottomTabNavigator;

