import React from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import HomeScreen from '../screens/Home/HomeScreen'; // Import your screens
import LoginScreen from '../screens/Login/LoginScreen';
import RegisterScreen from '../screens/Login/RegisterScreen';
import { UserIcon } from '../assets/SVG';
import { UserGreyIcon } from '../assets/SVG';
import { TabHomeIcon } from '../assets/SVG';
import { TabReportIcon } from '../assets/SVG';

// import ReportScreen from '../screens/Report/ReportScreen';
import {
  ImageBackground, Image, KeyboardAvoidingView,
  Platform,
  TouchableWithoutFeedback,
  Keyboard, View, Alert, Text
} from 'react-native';
import styles from '../screens/Login/Login.Style';
import ReportScreen from '../screens/Report/ReportScreen';
import ProfileScreen from '../screens/Profile/ProfileScreen';
import { createStackNavigator } from '@react-navigation/stack';
import HomeDetailScreen from '../screens/Home/HomeDetailScreen';
import ThongTinLuanChuyenScreen from '../screens/Home/ThongTinLuanChuyenScreen';
import ShareViewScreen from '../screens/Home/ShareViewScreen';


const Stack = createStackNavigator();
const Tab = createBottomTabNavigator();

const BottomTabNavigator = () => {
  return (
    <Tab.Navigator
    >
      <Tab.Screen
        name="Trang chủ"
        component={HomeStack}
        options={{
          headerShown: false,
          tabBarIcon: ({ focused, color, size }) => (
            <TabHomeIcon color={focused ? "#FF0000" : color} size={size} />
          ),
          tabBarLabel: ({ focused,color }) => (
            <Text style={{ color: focused ? '#00b4b2' : 'gray' }}>
             Trang chủ
            </Text>
          ),
        }}

      />
      <Tab.Screen
        name="Báo cáo"
        component={ReportScreen}
        options={{
          headerShown: false,
          tabBarIcon: ({ focused, color, size }) => (
            <TabReportIcon />

          ),
          tabBarLabel: ({ focused,color }) => (
            <Text style={{ color: focused ? '#00b4b2' : 'gray' }}>
             Báo cáo
            </Text>
          ),
        }}
      />
     <Tab.Screen
      name="Cá nhân"
      component={ProfileScreen}
      options={({ }) => ({
        headerShown: false,
        tabBarIcon: ({ focused,color, size }) => (
          <UserGreyIcon color={focused ? '#00b4b2' : 'gray'} />
        ),
        tabBarLabel: ({ focused,color }) => (
          <Text style={{ color: focused ? '#00b4b2' : 'gray' }}>
            Cá nhân
          </Text>
        ),
      })}
/>
    </Tab.Navigator>
  );
};
function HomeStack() {
  return (
    <Stack.Navigator
      initialRouteName="HomeScreen"
      screenOptions={{
        headerShown: false, // Hide the header for all screens in the stack
        gestureEnabled: true,
        gestureDirection: "horizontal",
        tabBarStyle: { display: "flex" },
        tabBarVisible: false, // Hide the tab bar
        
        cardStyle: { flex: 1 }, 
      }}
    >
      <Stack.Screen
        name="HomeScreen"
        component={HomeScreen}
        // options={{
        //   gestureEnabled: true,
        //   gestureDirection: "horizontal",
        //   headerShown: false,

        // }}
      />
      <Stack.Screen
        name="HomeDetailScreen"
        component={HomeDetailScreen}

        options={{
          gestureEnabled: true,
          gestureDirection: "horizontal",
          headerShown: false,
          tabBarStyle: { display: "flex" }, // Hides the tab bar
          tabBarVisible: false, // Hides the tab bar
          cardStyle: { flex: 1 }, // Makes the screen content fullscreen
        }}

      />
      <Stack.Screen
        name="ThongTinLuanChuyenScreen"
        component={ThongTinLuanChuyenScreen}
        options={{
          gestureEnabled: true,
          gestureDirection: "horizontal",
          headerShown: false,

        }}
      />

      <Stack.Screen
        name="ShareViewScreen"
        component={ShareViewScreen}
        // options={{
        //   gestureEnabled: true,
        //   gestureDirection: "horizontal",
        //   headerShown: false,

        // }}
      />
    </Stack.Navigator>
  );
}

export default BottomTabNavigator;

