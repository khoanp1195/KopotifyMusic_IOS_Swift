import React, { useState, useEffect } from "react";
import styles from "./RootContainer.Style";
import { View, StatusBar } from "react-native";
import { NavigationContainer } from "@react-navigation/native";
import { createStackNavigator } from "@react-navigation/stack";
import { createNavigationContainerRef } from '@react-navigation/native';
import LoginScreen from "../screens/Login/LoginScreen";
import { RootState } from "../store";
import { useSelector } from "react-redux";
import DrawerNavigatorStack from "./DrawerNavigatorStack";
import colors from "../themes/Color";
export type StackParamList = {
  LoginScreen: undefined;
  DrawerNavigatorStack: undefined;
};
import {
  SafeAreaProvider,
  SafeAreaView
} from "react-native-safe-area-context";
import HomeScreen from "../screens/Home/HomeScreen";
import BottomTabNavigator from "../Navigator/BottomTabNavigator";
import HomeDetailScreen from "../screens/Home/HomeDetailScreen";

const Stack = createStackNavigator<StackParamList>();

const RootContainerScreen = () => {
 const { isLogin } = useSelector((state: RootState) => state.login);
// const {isAuth} = userSelctor((state: RootState) => state.a)
// const isLogin = false;
  console.log(isLogin)

  return (
    <SafeAreaProvider>
    {
      isLogin ? <SafeAreaView style={styles.mainContainer}>
        <StatusBar barStyle='light-content' backgroundColor={colors.primary} />
     
        <BottomTabNavigator />

   
      </SafeAreaView> :
        <>
          <StatusBar barStyle='light-content' backgroundColor='transparent' translucent={true} />
          <Stack.Navigator
            initialRouteName="LoginScreen"
            screenOptions={{
              headerShown: false,
            }}
          >
            <Stack.Screen
              name="LoginScreen"
              component={LoginScreen}
              options={{ gestureEnabled: true, gestureDirection: "horizontal" }}
            />
          </Stack.Navigator>
        </>
    }
  </SafeAreaProvider>
  );
};

export default RootContainerScreen;
