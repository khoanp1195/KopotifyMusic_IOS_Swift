import React, { useCallback, useState, useMemo, useEffect } from "react";
import { View, Text, StyleSheet, TouchableOpacity, ScrollView, Dimensions, Alert } from "react-native";
import { useDispatch, useSelector } from "react-redux";
import {
  ChevronDownIcon,
  ProcessingDocxIcon,
  CoordinationDocxIcon,
  NotificationIcon,
  WaitingCommentIcon,
  VBDenIcon,
  VBDiIcon,
  ProcessedIcon,
  WaitingActionIcon,
  AllActionIcon,
  PublishedIcon,
  WaitForApprovedIcon,
  LogOutPrimaryIcon,
  BackIcon,
  SelectedEnalbleIcon,
  SelectedDisableIcon,
} from "../assets/SVG/index";
import colors from "../themes/Color";
import { dimensWidth, FontSize, funtionVBDenData, funtionVBDiData } from "../themes/const";
import { arrayIsEmpty, isNullOrEmpty, isNullOrUndefined, removeSpecialCharacters } from "../helpers/formater";
import { logOut, logoutAction, setSubSite } from "../store/login/reducer";
import { RootState } from "../store";
// import SelectDropdown from 'react-native-select-dropdown';
import { ThunkDispatch } from "@reduxjs/toolkit";
import FastImage from "react-native-fast-image";
import { BaseUrl } from "../services/api";
import AsyncStorage from "@react-native-async-storage/async-storage";
import DeviceInfo from "react-native-device-info";

const DrawerView = ({ navigation }: any) => {
  const dispatch = useDispatch<ThunkDispatch<any, any, any>>();
  const { dataNotificationUsers } = useSelector(
    (state: RootState) => state.home
  );
  const { dataCurrentUsers, subSite, token, changeSiteNotification } = useSelector(
    (state: RootState) => state.login
  );
  const [isOpenListVBDen, setIsOpenListVBDen] = useState(true)
  const [isOpenListVBDi, setIsOpenListVBDi] = useState(true)
  const [sites, setSites] = useState([])
  const [selectedSite, setSelectedSite] = useState()

  // const onLogout = useCallback(() => {
  //   Alert.alert('Thông báo', 'Vui lòng xác nhận thoát khỏi tài khoản', [
  //     {
  //       text: 'Hủy',
  //       style: 'cancel',
  //     },
  //     { text: 'Đăng xuất', onPress: () => signOut() },
  //   ]);
  // }, []);

  // const signOut = async () => {
  //   const deviceId = await AsyncStorage.getItem('deviceId')
  //   await AsyncStorage.removeItem('username')
  //   await AsyncStorage.removeItem('password')
  //   setSelectedSite("")
  //   setSites([])
  //   dispatch(logOut({ deviceId, subSite }))
  //   dispatch(logoutAction())
  // }

  const onChangeIsOpenListVBDen = useCallback(() => {
    setIsOpenListVBDen(!isOpenListVBDen);
  }, [isOpenListVBDen]);
  const onChangeIsOpenListVBDi = useCallback(() => {
    setIsOpenListVBDi(!isOpenListVBDi);
  }, [isOpenListVBDi]);
  const onGoToWaitProcessDocx = useCallback(() => {
    navigation.navigate("WaitProcessDocxScreen");
  }, [navigation]);
  const onGoToPhoiHopScreen = useCallback(() => {
    navigation.navigate("VBPhoiHopScreen");
  }, [navigation]);
  const onGoToThongBaoScreen = useCallback(() => {
    navigation.navigate("VBThongBaoScreen");
  }, [navigation]);
  const onGoToVBDaBanHanhScreen = useCallback(() => {
    navigation.navigate("Văn bản đi", {
      screen: "VBDaBanHanhScreen",
    });
  }, [navigation]);
  const onGoToVBDicreen = useCallback((funtionVBDi: any) => {
    navigation.navigate("Văn bản đi", {
      screen: "VBDiScreen",
      params: { funtionVBDi }
    });
  }, [navigation]);
  const onGoToVBDenScreen = useCallback((funtionVBDen: any) => {
    navigation.navigate("Văn bản đến", {
      screen: "VBDenScreen",
      params: { funtionVBDen }
    });
  }, [navigation]);
  // const FullName = useMemo(() => {
  //   if (!dataCurrentUsers) return null;
  //   return dataCurrentUsers[0]?.FullName;
  // }, [dataCurrentUsers]);

  // const Position = useMemo(() => {
  //   if (!dataCurrentUsers) return null;
  //   return removeSpecialCharacters(dataCurrentUsers[0]?.Position);
  // }, [dataCurrentUsers]);

  // useEffect(() => {
  //   if (!arrayIsEmpty(dataCurrentUsers)) {
  //     const siteNames = dataCurrentUsers[0].SiteName.split(';')
  //     let tmp = []
  //     for (let index = 0; index < siteNames.length; index++) {
  //       const element = siteNames[index];
  //       tmp.push({
  //         title: element,
  //         checked: !isNullOrUndefined(selectedSite) ? element === selectedSite : index == 0
  //       })
  //     }

  //     setSelectedSite(!isNullOrUndefined(selectedSite) ? selectedSite : tmp[0].title)
  //     setSites(tmp)
  //   }
  // }, [dataCurrentUsers, selectedSite])

  // useEffect(() => {
  //   setSelectedSite(changeSiteNotification)
  // }, [changeSiteNotification])

  const onChange = useCallback((selectedItem: any, index: any) => {
    // Nếu trùng với site đang đứng thì không cần đổi
    if (selectedItem.title !== subSite) {
      dispatch(setSubSite(selectedItem.title))
      setSelectedSite(selectedItem.title.toLowerCase())
    }
    navigation.closeDrawer();
  }, [dispatch, subSite])

  // const ViecCanXuLy = useMemo(() => {
  //   if (!dataNotificationUsers) return 0;
  //   return dataNotificationUsers[0]?.ViecCanXuLy > 99 ? "99+" : dataNotificationUsers[0]?.ViecCanXuLy;
  // }, [dataNotificationUsers]);
  // const ThongBao = useMemo(() => {
  //   if (!dataNotificationUsers) return 0;
  //   return dataNotificationUsers[0]?.ThongBao > 99 ? "99+" : dataNotificationUsers[0]?.ThongBao;
  // }, [dataNotificationUsers]);
  // const VanBanPhoiHop = useMemo(() => {
  //   if (!dataNotificationUsers) return 0;
  //   return dataNotificationUsers[0]?.VanBanPhoiHop > 99 ? "99+" : dataNotificationUsers[0]?.VanBanPhoiHop;;
  // }, [dataNotificationUsers]);

  return (
    // <ScrollView contentContainerStyle={styles.container}>
    //   <View style={styles.viewAvatar}>
    //     <FastImage
    //       style={styles.avatar}
    //       source={{
    //         uri: BaseUrl + "/" + subSite + dataCurrentUsers[0]?.ImagePath,
    //         headers: { Authorization: `${token}` },
    //         priority: FastImage.priority.normal,
    //       }}
    //       defaultSource={require('../assets/images/avatar80.png')}
    //     />

    //     <View>
    //       <Text style={styles.titleAvatar}>{FullName}</Text>
    //       <Text style={styles.position}>{Position}</Text>
    //     </View>
    //   </View>
    //   <SelectDropdown
    //     data={sites}
    //     onSelect={(selectedItem, index) => { onChange(selectedItem, index) }}
    //     buttonTextAfterSelection={(selectedItem, index) => {
    //       return selectedSite.toUpperCase();
    //     }}
    //     rowTextForSelection={(item, index) => {
    //       return item.title.toUpperCase();
    //     }}
    //     renderDropdownIcon={isOpened => {
    //       return <ChevronDownIcon />;
    //     }}
    //     defaultButtonText={subSite.toUpperCase()}
    //     buttonStyle={styles.dropdown1BtnStyle}
    //     renderCustomizedRowChild={(item, index) => {
    //       return (
    //         <View style={{
    //           flexDirection: 'row',
    //           marginLeft: 10,
    //         }}>
    //           {item.checked ? <SelectedEnalbleIcon /> : <SelectedDisableIcon />}
    //           <Text style={{
    //             marginLeft: 10,
    //             color: '#000000',
    //             fontWeight: 400,
    //             fontSize: FontSize.MEDIUM
    //           }}>{item.title.toUpperCase()}</Text>
    //         </View>
    //       );
    //     }}
    //     buttonTextStyle={{
    //       fontSize: FontSize.MEDIUM,
    //       color: '#015DD1',
    //       textAlign: 'left',
    //       fontWeight: "700",
    //       fontFamily: "arial"
    //     }}

    //     dropdownIconPosition={'right'}
    //     dropdownStyle={styles.dropdown1DropdownStyle}
    //     rowStyle={styles.dropdown1RowStyle}
    //     rowTextStyle={styles.dropdown1RowTxtStyle}
    //   />


    //   <TouchableOpacity
    //     style={styles.flexDirectionBetween}
    //     onPress={onGoToWaitProcessDocx}
    //   >
    //     <View style={styles.flexDirectionBetween}>
    //       <ProcessingDocxIcon />
    //       <Text style={styles.content}>VB chờ xử lý</Text>
    //     </View>
    //     <Text style={styles.notify}>{ViecCanXuLy}</Text>
    //   </TouchableOpacity>
    //   <TouchableOpacity
    //     style={styles.flexDirectionBetween}
    //     onPress={onGoToPhoiHopScreen}
    //   >
    //     <View style={styles.flexDirectionBetween}>
    //       <CoordinationDocxIcon />
    //       <Text style={styles.content}> VB phối hợp</Text>
    //     </View>
    //     <Text style={styles.notify}>{VanBanPhoiHop}</Text>
    //   </TouchableOpacity>
    //   <TouchableOpacity
    //     style={styles.flexDirectionBetween}
    //     onPress={onGoToThongBaoScreen}
    //   >
    //     <View style={styles.flexDirectionBetween}>
    //       <NotificationIcon />
    //       <Text style={styles.content}>Thông báo</Text>
    //     </View>
    //     <Text style={styles.notify}>{ThongBao}</Text>
    //   </TouchableOpacity>
    //   {/* VĂN BẢN ĐẾN */}
    //   <TouchableOpacity style={styles.flexDirectionDocx} onPress={onChangeIsOpenListVBDen}>
    //     <VBDenIcon />
    //     <Text style={styles.txtDocx}>VĂN BẢN ĐẾN</Text>
    //   </TouchableOpacity>
    //   {isOpenListVBDen &&
    //     <>
    //       <TouchableOpacity style={styles.flexDirection} onPress={() => onGoToVBDenScreen(funtionVBDenData.VBDenChoChoYKien)}>
    //         <WaitingCommentIcon />
    //         <Text style={styles.content}>Chờ cho ý kiến</Text>
    //       </TouchableOpacity>
    //       <TouchableOpacity style={styles.flexDirection} onPress={() => onGoToVBDenScreen(funtionVBDenData.VBDenChoThucHien)}>
    //         <WaitingActionIcon />
    //         <Text style={styles.content}>Chờ thực hiện</Text>
    //       </TouchableOpacity>
    //       <TouchableOpacity style={styles.flexDirection} onPress={() => onGoToVBDenScreen(funtionVBDenData.VBDenDaXuLy)}>
    //         <ProcessedIcon />
    //         <Text style={styles.content}>Đã xử lý</Text>
    //       </TouchableOpacity>
    //       <TouchableOpacity style={styles.flexDirection} onPress={() => onGoToVBDenScreen(funtionVBDenData.VBDenTatCa)}>
    //         <AllActionIcon />
    //         <Text style={styles.content}>Tất cả</Text>
    //       </TouchableOpacity>
    //     </>}
    //   {/* VĂN BẢN ĐI */}
    //   <TouchableOpacity style={styles.flexDirectionDocx} onPress={onChangeIsOpenListVBDi}>
    //     <VBDiIcon />
    //     <Text style={styles.txtDocx}>VĂN BẢN ĐI</Text>
    //   </TouchableOpacity>
    //   {isOpenListVBDi &&
    //     <>
    //       <TouchableOpacity style={styles.flexDirection} onPress={() => onGoToVBDicreen(funtionVBDiData.Chopheduyet)}>
    //         <WaitForApprovedIcon />
    //         <Text style={styles.content}>Chờ phê duyệt</Text>
    //       </TouchableOpacity>
    //       <TouchableOpacity style={styles.flexDirection} onPress={() => onGoToVBDicreen(funtionVBDiData.DaPheDuyet)}>
    //         <ProcessedIcon />
    //         <Text style={styles.content}>Đã phê duyệt</Text>
    //       </TouchableOpacity>
    //       <TouchableOpacity
    //         style={styles.flexDirection}
    //         onPress={onGoToVBDaBanHanhScreen}
    //       >
    //         <PublishedIcon />
    //         <Text style={styles.content}>Đã phát hành</Text>
    //       </TouchableOpacity>
    //       <TouchableOpacity style={styles.flexDirection} onPress={() => onGoToVBDicreen(funtionVBDiData.TatCa)}>
    //         <AllActionIcon />
    //         <Text style={styles.content}>Tất cả</Text>
    //       </TouchableOpacity>
    //     </>}

    //   <TouchableOpacity style={styles.flexDirection} onPress={onLogout}>
    //     <LogOutPrimaryIcon />
    //     <Text style={styles.logOut}>Đăng xuất</Text>
    //   </TouchableOpacity>

    //   <Text style={styles.txtVersion}>Phiên bản {DeviceInfo.getVersion()}</Text>
    // </ScrollView>
    <View></View>
    );
};
const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    paddingHorizontal: 20,
    paddingBottom: 10
  },
  imgVBChoXuLy: {
    with: 18,
    height: 18,
  },
  flexDirectionBetween: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 10,
  },
  flexDirection: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 20,
  },
  viewCoporation: {
    marginBottom: 10,
    height: 34,
    marginHorizontal: -10,
    borderColor: colors.primary,
  },
  linearCoporation: {
    flex: 1,
    paddingLeft: 20,
    justifyContent: "center",
    borderRadius: 5,
    borderWidth: 0.5,
  },
  chevronDown: {
    position: "absolute",
    right: 12,
    top: 12,
  },
  flexDirectionDocx: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 10,
    backgroundColor: colors.greyF5,
    height: 45,
    marginHorizontal: -20,
    paddingLeft: 20,
  },
  title: {
    fontSize: FontSize.MEDIUM,
    color: colors.black,
    fontWeight: "700",
    fontFamily: "arial",
    marginLeft: 15,
  },
  content: {
    fontSize: FontSize.MEDIUM,
    color: colors.black,
    fontWeight: "400",
    fontFamily: "arial",
    marginLeft: 15,
  },
  txtVersion: {
    fontSize: FontSize.MEDIUM,
    color: colors.black,
    fontWeight: "400",
    fontFamily: "arial",
    marginLeft: 30,
  },
  notify: {
    fontSize: FontSize.MEDIUM,
    color: colors.orange,
    fontWeight: "400",
    fontFamily: "arial",
  },
  viewAvatar: {
    flexDirection: "row",
    marginTop: 20,
    marginBottom: dimensWidth(25),
    alignItems: "center",
  },
  titleAvatar: {
    fontSize: FontSize.LARGE,
    color: colors.black,
    fontWeight: "400",
    fontFamily: "arial",
  },
  avatar: {
    height: dimensWidth(36),
    width: dimensWidth(36),
    marginRight: dimensWidth(12),
    borderRadius: dimensWidth(18),
  },
  position: {
    fontSize: FontSize.SMALL,
    color: colors.lightBlack,
    fontWeight: "400",
    fontFamily: "arial",
  },
  txtDocx: {
    fontSize: FontSize.MEDIUM,
    color: colors.black,
    fontWeight: "700",
    fontFamily: "arial",
    marginLeft: 15,
  },
  logOut: {
    fontSize: FontSize.MEDIUM,
    color: colors.primary,
    fontWeight: "400",
    fontFamily: "arial",
    marginLeft: 15,
  },
  dropdown1BtnStyle: {
    height: 34,
    width: '100%',
    backgroundColor: '#EEF6FF',
    marginBottom: 30,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#015DD1',
  },
  dropdown1DropdownStyle: {
    marginBottom: 30,
    borderRadius: 8,
    borderWidth: 1,
    marginTop: 5,
    borderColor: '#015DD1',
  },

  dropdown1RowStyle: {
    backgroundColor: 'white'
  },
  dropdown1RowTxtStyle: { color: '#000', textAlign: 'left' },
});
export default DrawerView;
