import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
} from 'react-native';

import colors from '../helpers/Colors';
import {dimensWidth, FontSize} from 'helpers/Constants';

const DrawerView = ({route, navigation}: any) => {
  return (
    <ScrollView style={styles.container}>
      <View style={styles.flexDirectionDocx}>
        <View>
          <Text style={styles.title}>{'FullName'}</Text>
          <Text style={styles.content}>{'Position'}</Text>
        </View>
      </View>
      <TouchableOpacity style={styles.flexDirectionDocx}>
        <Text style={styles.content}>VĂN BẢN ĐI</Text>
      </TouchableOpacity>
    </ScrollView>
  );
};
const styles = StyleSheet.create({
  container: {
    //paddingHorizontal: 20,
  },
  flexDirectionDocx: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.greyF5,
    height: 45,
    // marginHorizontal: -20,
    paddingHorizontal: dimensWidth(27),
  },
  title: {
    fontSize: FontSize.MEDIUM,
    color: colors.black,
    fontWeight: '700',
    fontFamily: 'arial',
    marginLeft: dimensWidth(15),
  },
  content: {
    fontSize: FontSize.MEDIUM,
    color: colors.black,
    fontWeight: '400',
    fontFamily: 'arial',
    marginLeft: 15,
  },
});
export default DrawerView;
