import React from 'react';
import {View, Text, TouchableOpacity} from 'react-native';
import {createStackNavigator} from '@react-navigation/stack';
import {createDrawerNavigator} from '@react-navigation/drawer';
import {createBottomTabNavigator} from '@react-navigation/bottom-tabs';
import DrawerView from './DrawerView.Screen';
import {DanhMucIcon, UserGreyIcon} from '../assets/svg/index';
import styles from './RootContainer.Style';
import DashboardScreen from '../dashboard/Dashboard.Screen';
import {bottomTabName} from 'helpers/Constants';

const Stack = createStackNavigator();
const DrawerStack = createDrawerNavigator();
const BottomStack = createBottomTabNavigator();

function AppDrawerStack() {
  return (
    <DrawerStack.Navigator drawerContent={props => <DrawerView {...props} />}>
      <DrawerStack.Screen
        options={{headerShown: false}}
        name="AppBottomStack"
        component={AppBottomStack}
      />
    </DrawerStack.Navigator>
  );
}

const renderTabIcon = (isFocused: Boolean, label: String) => {
  switch (label) {
    case bottomTabName.VanBanDen:
      return <UserGreyIcon color={isFocused ? '#FFFFFF' : '#DBA410'} />;
    case bottomTabName.VanBanDi:
      return <UserGreyIcon color={isFocused ? '#FFFFFF' : '#DBA410'} />;
    case bottomTabName.Tracuu:
      return <UserGreyIcon color={isFocused ? '#FFFFFF' : '#DBA410'} />;
    default:
      return <UserGreyIcon color={isFocused ? '#FFFFFF' : '#DBA410'} />;
  }
};
function MyTabBar({state, descriptors, navigation}: any) {
  return (
    <TouchableOpacity style={styles.viewTabBottomBar}>
      {state.routes.map((route: any, index: number) => {
        const {options} = descriptors[route.key];
        const label =
          options.tabBarLabel !== undefined
            ? options.tabBarLabel
            : options.title !== undefined
            ? options.title
            : route.name;

        const isFocused = state.index === index;

        const onPress = () => {
          const event = navigation.emit({
            type: 'tabPress',
            target: route.key,
            canPreventDefault: true,
          });

          if (!isFocused && !event.defaultPrevented) {
            // The `merge: true` option makes sure that the params inside the tab screen are preserved
            navigation.navigate({name: route.name, merge: true});
          }
        };

        const onLongPress = () => {
          navigation.emit({
            type: 'tabLongPress',
            target: route.key,
          });
        };

        return (
          <TouchableOpacity
            key={label}
            activeOpacity={1}
            accessibilityRole="button"
            accessibilityState={
              isFocused ? {selected: true} : {selected: false}
            }
            accessibilityLabel={options.tabBarAccessibilityLabel}
            testID={options.tabBarTestID}
            onPress={onPress}
            onLongPress={onLongPress}
            style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
            <View
              style={[
                styles.tabBarIconView,
                isFocused && {
                  backgroundColor: '#fff',
                  shadowColor: '#006885',
                  shadowOffset: {
                    width: 0,
                    height: 3,
                  },
                  shadowRadius: 5,
                  shadowOpacity: 1.0,
                },
              ]}>
              {renderTabIcon(isFocused, label)}
            </View>
            <Text
              style={
                isFocused
                  ? styles.tabBarLabelActive
                  : styles.tabBarLabelInActive
              }>
              {label}
            </Text>
          </TouchableOpacity>
        );
      })}
    </TouchableOpacity>
  );
}
function AppBottomStack() {
  return (
    <BottomStack.Navigator
      options={{
        headerShown: false,
      }}
      tabBar={props => {
        return <MyTabBar {...props} />;
      }}>
      <BottomStack.Screen
        options={{
          headerShown: false,
          tabBarActiveBackgroundColor: '#006885',
          tabBarInactiveBackgroundColor: '#006885',
          tabBarLabelStyle: styles.tabBarLabelActive,
          tabBarStyle: {display: 'flex'},
          tabBarIcon: ({focused}) => (
            <View
              style={[
                styles.tabBarIconView,
                focused && {backgroundColor: '#fff'},
              
              ]}>
              <UserGreyIcon color={focused ? '#025ED8' : '#fff'} />
            </View>
          ),
        }}
        name={bottomTabName.TrangChu}
        component={HomeStack}
      />
      <BottomStack.Screen
        name={bottomTabName.VanBanDen}
        component={VBDenStack}
        options={{
          headerShown: false,
          tabBarActiveBackgroundColor: '#025ED8',
          tabBarInactiveBackgroundColor: '#025ED8',
          tabBarLabelStyle: styles.tabBarLabelActive,
          tabBarIcon: ({focused}) => (
            <View
              style={[
                styles.tabBarIconView,
                focused && {backgroundColor: '#fff'},
              ]}>
              <DanhMucIcon color={focused ? 'clear' : '#fff'} />
            </View>
          ),
        }}
      />
      <BottomStack.Screen
        name={bottomTabName.VanBanDi}
        component={VBDiStack}
        options={{
          headerShown: false,
          tabBarActiveBackgroundColor: '#025ED8',
          tabBarInactiveBackgroundColor: '#025ED8',
          tabBarLabelStyle: styles.tabBarLabelActive,
          tabBarIcon: ({focused}) => (
            <View
              style={[
                styles.tabBarIconView,
                focused && {backgroundColor: '#fff'},
              ]}>
              <UserGreyIcon color={focused ? '#025ED8' : '#fff'} />
            </View>
          ),
        }}
      />
      <BottomStack.Screen
        name={bottomTabName.Tracuu}
        component={DashboardScreen}
        options={{
          headerShown: false,
          tabBarActiveBackgroundColor: '#025ED8',
          tabBarInactiveBackgroundColor: '#025ED8',
          tabBarLabelStyle: styles.tabBarLabelActive,
          tabBarIcon: ({focused}) => (
            <View
              style={[
                
                styles.tabBarIconView,
                
                focused && {backgroundColor: '#fff'},
              ]}>
              <UserGreyIcon  color={focused ? '#FFFFFF' : '#fff'} />
            </View>
          ),
        }}
      />
    </BottomStack.Navigator>
  );
}

function HomeStack() {
  return (
    <Stack.Navigator>
      <Stack.Screen
        options={{headerShown: false}}
        name="DashboardScreen"
        component={DashboardScreen}
      />
    </Stack.Navigator>
  );
}

function VBDenStack() {
  return (
    <Stack.Navigator>
      <Stack.Screen
        options={{headerShown: false}}
        name="VBDenScreen"
        component={DashboardScreen}
        initialParams={{type: 'Tab'}}
      />
    </Stack.Navigator>
  );
}
function VBDiStack() {
  return (
    <Stack.Navigator>
      <Stack.Screen
        options={{headerShown: false}}
        name="VBDiScreen"
        component={DashboardScreen}
        initialParams={{type: 'Tab'}}
      />
    </Stack.Navigator>
  );
}

export default function DrawerNavigatorStack() {
  return (
    <Stack.Navigator>
      <Stack.Screen
        options={{headerShown: false}}
        name="AppDrawerStack"
        component={AppDrawerStack}
      />
    </Stack.Navigator>
  );
}
