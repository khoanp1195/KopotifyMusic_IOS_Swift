import React, { useCallback } from "react";
import { View, Text, TouchableOpacity, Platform } from "react-native";
import { funtionVBDenData, funtionVBDiData } from "../themes/const";
import { createStackNavigator } from "@react-navigation/stack";
import { createDrawerNavigator } from "@react-navigation/drawer";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import HomeScreen from "../screens/Home/HomeScreen";//screens/home/Home.Screen
// import WaitProcessDocxFilter from "../screens/home/WaitProcessDocx/WaitProcessDocxFilter";
// import VBPhoiHopFilter from "../screens/home/VBPhoiHop/VBPhoiHopFilter";//~/screens/home/VBPhoiHop/VBPhoiHopFilter
// import VBThongBaoFilter from "../screens/home/VBThongBao/VBThongBaoFilter";
import DrawerView from "./DrawerView.Screen";
import {
  TabHomeIcon,
  TabSearchIcon,
  TabInComingDocxIcon,
  TabOutGoingDocxIcon
} from "../assets/SVG/index";
import styles from "./RootContainer.Style";
// import WaitProcessDocxScreen from "../screens/home/WaitProcessDocx/WaitProcessDocx.Screen";
// import VBPhoiHopScreen from "../screens/home/VBPhoiHop/VBPhoiHop.Screen";
// import VBThongBaoScreen from "../screens/home/VBThongBao/VBThongBao.Screen";
// import WaitProcessDocxDetailScreen from "../screens/VBDen/WaitProcessDocxDetail.Screen";
// import ChooseLanhDaoCongTyScreen from "../screens/VBDen/ChooseLanhDaoCongTy";
// import FileViewScreen from "../screens/VBDen/FileView.Screen";
// import ChoosePhongBanPhanCongScreen from "../screens/VBDen/ChoosePhongBanPhanCong";
// import ChooseNhomNguoiDungScreen from "../screens/VBDen/ChooseNhomNguoiDung";
// import ToChucPhanCongThucHienScreen from "../screens/VBDen/ToChucPhanCongThucHien";
// import VBDenScreen from "../screens/VBDen/VBDen.Screen";
// import ThongTinLuanChuyenScreen from "../screens/VBDen/ThongTinLuanChuyen";
// import NhiemVuDaPhanCongScreen from "../screens/VBDen/NhiemVuDaPhanCong";
// import ChooseTrangThaiScreen from "../screens/VBDen/NhiemVuDaPhanCong/ChooseTrangThaiScreen";
// import ChoosePhongBanPhanCongTaskScreen from "../screens/VBDen/NhiemVuDaPhanCong/ChoosePhongBanPhanCongTask";
// import ToChucPhanCongThucHienTaskScreen from "../screens/VBDen/NhiemVuDaPhanCong/ToChucPhanCongThucHienTask";
// import ChooseNhomNguoiDungTaskScreen from "../screens/VBDen/NhiemVuDaPhanCong/ChooseNhomNguoiDungTask";
// import TinhTrangFilterScreen from "../screens/VBDen/TinhTrangFilter";
// import ChooseLanhDaoChoYKienScreen from "../screens/VBDen/ChooseLanhDaoChoYKien";
// import VBDiScreen from "../screens/VBDi/VBDi.Screen";
// import VBDaBanHanhScreen from "../screens/VBBH/VBDaBanHanh";
// import VBDaBanHanhDetailScreen from "../screens/VBBH/VBDaBanHanhDetail.Screen";
// import ChooseNhomNguoiDungVBBHScreen from "../screens/VBBH/ChooseNhomNguoiDungVBBH";
// import ThongTinLuanChuyenVBBHScreen from "../screens/VBBH/ThongTinLuanChuyenVBBH";
// import VBDiDetailScreen from "../screens/VBDi/VBDiDetail.Screen";
// import ChooseNhomNguoiDungVBDiScreen from "../screens/VBDi/ChooseNhomNguoiDungVBDi";
// import ChoosNguoiDuocChuyenXuLyVBDiScreen from "../screens/VBDi/ChoosNguoiDuocChuyenXuLyVBDi";
// import ChooseDSNguoiBoSungThongTinVBDiScreen from "../screens/VBDi/ChooseDSNguoiBoSungThongTinVBDi";
// import ThongTinLuanChuyenVBDicreen from "../screens/VBDi/ThongTinLuanChuyenVBDi";
// import FileViewVBDiScreen from "../screens/VBDi/FileViewVBDi.Screen";
// import TinhTrangVBDiFilterScreen from "../screens/VBDi/TinhTrangVBDiFilter";
// import ChooseLanhDaoChoYKienVBDiScreen from "../screens/VBDi/ChooseLanhDaoChoYKienVBDi";
// import ChooseVbTimKiemCoQuanGuiScreen from "../screens/VbTimKiem/ChooseVbTimKiemCoQuanGui";
// import ChooseVbTimKiemNguoiKyScreen from "../screens/VbTimKiem/ChooseVbTimKiemNguoiKy";
// import ChooseVbTimKiemLoaiVanBanScreen from "../screens/VbTimKiem/ChooseVbTimKiemLoaiVanBan";
// import VbTimKiemScreen from "../screens/VbTimKiem/VbTimKiem.Screen";
import LinearGradient from "react-native-linear-gradient";
import DeviceInfo from 'react-native-device-info';

const Stack = createStackNavigator();
 const DrawerStack = createDrawerNavigator();
const BottomStack = createBottomTabNavigator();

function AppDrawerStack() {
  return (
    <DrawerStack.Navigator drawerContent={(props) => <DrawerView {...props} />}>
      <DrawerStack.Screen
        options={{ headerShown: false }}
        name="AppBottomStack"
        component={AppBottomStack}
      />
    </DrawerStack.Navigator>
  );
}

const renderTabIcon = (isFocused: Boolean, label: String) => {
  switch (label) {
    case "Văn bản đến":
      return <TabInComingDocxIcon color={isFocused ? "#025ED8" : "#fff"} />;
    case "Văn bản đi":
      return <TabOutGoingDocxIcon color={isFocused ? "#025ED8" : "#fff"} />;
    case "Tra cứu":
      return <TabSearchIcon color={isFocused ? "#025ED8" : "#fff"} />;
    default:
      return <TabHomeIcon color={isFocused ? "#025ED8" : "#fff"} />;
  }
};

function MyTabBar({ state, descriptors, navigation }: any) {
  return (
    <LinearGradient
      style={styles.viewTabBottomBar}
      colors={["#0054AE", "#015DD1"]}
    >
      {state.routes.map((route: any, index: number) => {
        const { options } = descriptors[route.key];
        const label =
          options.tabBarLabel !== undefined
            ? options.tabBarLabel
            : options.title !== undefined
              ? options.title
              : route.name;

        const isFocused = state.index === index;

        const onPress = () => {
          const event = navigation.emit({
            type: "tabPress",
            target: route.key,
            canPreventDefault: true,
          });

          if (!isFocused && !event.defaultPrevented) {
            if (route.name === "Văn bản đến") {
              navigation.navigate("Văn bản đến", {
                screen: "VBDenScreen",
                params: { funtionVBDen: funtionVBDenData.VBDenTitle }
              });
            } else if (route.name === "Văn bản đi") {
              navigation.navigate("Văn bản đi", {
                screen: "VBDiScreen",
                params: { funtionVBDi: funtionVBDiData.VBDiTitle }
              });
            }
            else {
              navigation.navigate({ name: route.name, merge: true });
            }
          }
        };

        const onLongPress = () => {
          navigation.emit({
            type: "tabLongPress",
            target: route.key,
          });
        };

        return (
          <TouchableOpacity
            key={label}
            activeOpacity={1}
            accessibilityRole="button"
            accessibilityState={
              isFocused ? { selected: true } : { selected: false }
            }
            accessibilityLabel={options.tabBarAccessibilityLabel}
            testID={options.tabBarTestID}
            onPress={onPress}
            onLongPress={onLongPress}
            style={{ flex: 1, justifyContent: "center", alignItems: "center" }}
          >
            <View
              style={[
                styles.tabBarIconView,
                isFocused && {
                  backgroundColor: "#fff",
                  shadowColor: '#A9D1FF',
                  shadowOffset: {
                    width: 0,
                    height: 3
                  },
                  shadowRadius: 5,
                  shadowOpacity: 1.0
                },
              ]}
            >
              {renderTabIcon(isFocused, label)}
            </View>
            <Text
              style={
                isFocused
                  ? styles.tabBarLabelActive
                  : styles.tabBarLabelInActive
              }
            >
              {label}
            </Text>
          </TouchableOpacity>
        );
      })}
    </LinearGradient>
  );
}
function AppBottomStack() {
  return (
    <BottomStack.Navigator
      options={{
        headerShown: false,
      }}
      tabBar={(props) => {
        return <MyTabBar {...props} />;
      }}
    >
      <BottomStack.Screen
        options={{
          headerShown: false,
          tabBarActiveBackgroundColor: "#025ED8",
          tabBarInactiveBackgroundColor: "#025ED8",
          tabBarLabelStyle: styles.tabBarLabelActive,
          tabBarStyle: { display: "flex" },
          tabBarIcon: ({ focused }) => (
            <View
              style={[
                styles.tabBarIconView,
                focused && { backgroundColor: "#fff" },
              ]}
            >
              <TabHomeIcon color={focused ? "#025ED8" : "#fff"} />
            </View>
          ),
        }}
        name="Trang chủ"
        component={HomeStack}
      />
      <BottomStack.Screen
        name="Văn bản đến"
        component={VBDenStack}
        options={{
          headerShown: false,
          tabBarActiveBackgroundColor: "#025ED8",
          tabBarInactiveBackgroundColor: "#025ED8",
          tabBarLabelStyle: styles.tabBarLabelActive,
          tabBarIcon: ({ focused }) => (
            <View
              style={[
                styles.tabBarIconView,
                focused && { backgroundColor: "#fff" },
              ]}
            >
              <TabInComingDocxIcon color={focused ? "#025ED8" : "#fff"} />
            </View>
          ),
        }}
      />
      <BottomStack.Screen
        name="Văn bản đi"
        component={VBDiStack}
        options={{
          headerShown: false,
          tabBarActiveBackgroundColor: "#025ED8",
          tabBarInactiveBackgroundColor: "#025ED8",
          tabBarLabelStyle: styles.tabBarLabelActive,
          tabBarIcon: ({ focused }) => (
            <View
              style={[
                styles.tabBarIconView,
                focused && { backgroundColor: "#fff" },
              ]}
            >
              <TabOutGoingDocxIcon color={focused ? "#025ED8" : "#fff"} />
            </View>
          ),
        }}
      />
      <BottomStack.Screen
        name="Tra cứu"
        component={VBTimKiemStack}
        options={{
          headerShown: false,
          tabBarActiveBackgroundColor: "#025ED8",
          tabBarInactiveBackgroundColor: "#025ED8",
          tabBarLabelStyle: styles.tabBarLabelActive,
          tabBarIcon: ({ focused }) => (
            <View
              style={[
                styles.tabBarIconView,
                focused && { backgroundColor: "#fff" },
              ]}
            >
              <TabSearchIcon color={focused ? "#025ED8" : "#fff"} />
            </View>
          ),
        }}
      />
    </BottomStack.Navigator>
  );
}

function HomeStack() {
  return (
    <Stack.Navigator
      initialRouteName="HomeScreen"
      screenOptions={{
        headerShown: false,
      }}
    >
      <Stack.Screen
        name="HomeScreen"
        component={HomeScreen}
        options={{
          gestureEnabled: true,
          gestureDirection: "horizontal",
          headerShown: false,
        }}
      />
      {/* <Stack.Screen
        name="WaitProcessDocxScreen"
        component={WaitProcessDocxScreen}
        options={{
          gestureEnabled: true,
          gestureDirection: "horizontal",
          headerShown: false,
        }}
      /> */}
      {/* <Stack.Screen
        name="VBPhoiHopScreen"
        component={VBPhoiHopScreen}
        options={{
          gestureEnabled: true,
          gestureDirection: "horizontal",
          headerShown: false,
        }}
      /> */}
      {/* <Stack.Screen
        name="VBThongBaoScreen"
        component={VBThongBaoScreen}
        options={{
          gestureEnabled: true,
          gestureDirection: "horizontal",
          headerShown: false,
        }}
      /> */}
    </Stack.Navigator>
  );
}

function VBDenStack() {
  return (
    <Stack.Navigator
      initialRouteName="VBDenScreen"
      screenOptions={{
        headerShown: false,
      }}
    >
      {/* <Stack.Screen
        name="VBDenScreen"
        component={VBDenScreen}
        options={{ gestureEnabled: true, gestureDirection: "horizontal" }}
      /> */}
    </Stack.Navigator>
  );
}
function VBDiStack() {
  return (
    <Stack.Navigator
      initialRouteName="VBDiScreen"
      screenOptions={{
        headerShown: false,
      }}
    >
      {/* <Stack.Screen
        name="VBDiScreen"
        component={VBDiScreen}
        options={{ gestureEnabled: true, gestureDirection: "horizontal" }}
      /> */}
      {/* <Stack.Screen
        name="VBDaBanHanhScreen"
        component={VBDaBanHanhScreen}
        options={{ gestureEnabled: true, gestureDirection: "horizontal" }}
      /> */}
    </Stack.Navigator>
  );
}
function VBTimKiemStack() {
  return (
    <Stack.Navigator
      initialRouteName="VbTimKiemScreen"
      screenOptions={{
        headerShown: false,
      }}
    >
      {/* <Stack.Screen
        name="VbTimKiemScreen"
        component={VbTimKiemScreen}
        options={{ gestureEnabled: true, gestureDirection: "horizontal" }}
      /> */}
    </Stack.Navigator>
  );
}

export default function DrawerNavigatorStack() {
  return (
    <Stack.Navigator
      screenOptions={{
        gestureEnabled: true,
        gestureDirection: "horizontal",
        headerShown: false,
      }}
    >
      {/* <Stack.Screen
        options={{ headerShown: false }}
        name="AppDrawerStack"
        component={AppDrawerStack}
      /> */}
      {/* home */}
      {/* <Stack.Screen
        name="WaitProcessDocxFilter"
        component={WaitProcessDocxFilter}
        options={{ gestureEnabled: true, gestureDirection: "horizontal" }}
      /> */}
      {/* <Stack.Screen
        name="VBPhoiHopFilter"
        component={VBPhoiHopFilter}
        options={{ gestureEnabled: true, gestureDirection: "horizontal" }}
      /> */}
      {/* <Stack.Screen
        name="VBThongBaoFilter"
        component={VBThongBaoFilter}
        options={{ gestureEnabled: true, gestureDirection: "horizontal" }}
      /> */}
      {/* vb den */}
      {/* <Stack.Screen
        name="ThongTinLuanChuyenScreen"
        component={ThongTinLuanChuyenScreen}
        options={{ gestureEnabled: true, gestureDirection: "horizontal" }}
      /> */}
      {/* <Stack.Screen
        name="WaitProcessDocxDetailScreen"
        component={WaitProcessDocxDetailScreen}
        options={{ gestureEnabled: true, gestureDirection: "horizontal" }}
      /> */}
      {/* <Stack.Screen
        name="TinhTrangFilterScreen"
        component={TinhTrangFilterScreen}
        options={{ gestureEnabled: true, gestureDirection: "horizontal" }}
      /> */}
      {/* <Stack.Screen
        name="ChooseLanhDaoCongTyScreen"
        component={ChooseLanhDaoCongTyScreen}
        options={{ gestureEnabled: true, gestureDirection: "horizontal" }}
      /> */}
      {/* <Stack.Screen
        name="FileViewScreen"
        component={FileViewScreen}
        options={{ gestureEnabled: true, gestureDirection: "horizontal" }}
      /> */}
      {/* <Stack.Screen
        name="ChoosePhongBanPhanCongScreen"
        component={ChoosePhongBanPhanCongScreen}
        options={{ gestureEnabled: true, gestureDirection: "horizontal" }}
      />
      <Stack.Screen
        name="ChooseNhomNguoiDungScreen"
        component={ChooseNhomNguoiDungScreen}
        options={{ gestureEnabled: true, gestureDirection: "horizontal" }}
      />
      <Stack.Screen
        name="ToChucPhanCongThucHienScreen"
        component={ToChucPhanCongThucHienScreen}
        options={{ gestureEnabled: true, gestureDirection: "horizontal" }}
      />
      <Stack.Screen
        name="NhiemVuDaPhanCongScreen"
        component={NhiemVuDaPhanCongScreen}
        options={{ gestureEnabled: true, gestureDirection: "horizontal" }}
      /> */}
      {/* <Stack.Screen
        name="ChooseTrangThaiScreen"
        component={ChooseTrangThaiScreen}
        options={{ gestureEnabled: true, gestureDirection: "horizontal" }}
      />
      <Stack.Screen
        name="ChoosePhongBanPhanCongTaskScreen"
        component={ChoosePhongBanPhanCongTaskScreen}
        options={{ gestureEnabled: true, gestureDirection: "horizontal" }}
      />
      <Stack.Screen
        name="ToChucPhanCongThucHienTaskScreen"
        component={ToChucPhanCongThucHienTaskScreen}
        options={{ gestureEnabled: true, gestureDirection: "horizontal" }}
      />
      <Stack.Screen
        name="ChooseNhomNguoiDungTaskScreen"
        component={ChooseNhomNguoiDungTaskScreen}
        options={{ gestureEnabled: true, gestureDirection: "horizontal" }}
      />
      <Stack.Screen
        name="ChooseLanhDaoChoYKienScreen"
        component={ChooseLanhDaoChoYKienScreen}
        options={{ gestureEnabled: true, gestureDirection: "horizontal" }}
      /> */}
      {/* van ban ban hanh */}
      {/* <Stack.Screen
        name="VBDaBanHanhDetailScreen"
        component={VBDaBanHanhDetailScreen}
        options={{ gestureEnabled: true, gestureDirection: "horizontal" }}
      />
      <Stack.Screen
        name="ChooseNhomNguoiDungVBBHScreen"
        component={ChooseNhomNguoiDungVBBHScreen}
        options={{ gestureEnabled: true, gestureDirection: "horizontal" }}
      />
      <Stack.Screen
        name="ThongTinLuanChuyenVBBHScreen"
        component={ThongTinLuanChuyenVBBHScreen}
        options={{ gestureEnabled: true, gestureDirection: "horizontal" }}
      />
      <Stack.Screen
        name="VBDiDetailScreen"
        component={VBDiDetailScreen}
        options={{ gestureEnabled: true, gestureDirection: "horizontal" }}
      /> */}
      {/* <Stack.Screen
        name="ChooseNhomNguoiDungVBDiScreen"
        component={ChooseNhomNguoiDungVBDiScreen}
        options={{ gestureEnabled: true, gestureDirection: "horizontal" }}
      />
      <Stack.Screen
        name="ChoosNguoiDuocChuyenXuLyVBDiScreen"
        component={ChoosNguoiDuocChuyenXuLyVBDiScreen}
        options={{ gestureEnabled: true, gestureDirection: "horizontal" }}
      />
      <Stack.Screen
        name="ChooseDSNguoiBoSungThongTinVBDiScreen"
        component={ChooseDSNguoiBoSungThongTinVBDiScreen}
        options={{ gestureEnabled: true, gestureDirection: "horizontal" }}
      />
      <Stack.Screen
        name="ThongTinLuanChuyenVBDicreen"
        component={ThongTinLuanChuyenVBDicreen}
        options={{ gestureEnabled: true, gestureDirection: "horizontal" }}
      />
      <Stack.Screen
        name="FileViewVBDiScreen"
        component={FileViewVBDiScreen}
        options={{ gestureEnabled: true, gestureDirection: "horizontal" }}
      />
      <Stack.Screen
        name="TinhTrangVBDiFilterScreen"
        component={TinhTrangVBDiFilterScreen}
        options={{ gestureEnabled: true, gestureDirection: "horizontal" }}
      />
      <Stack.Screen
        name="ChooseLanhDaoChoYKienVBDiScreen"
        component={ChooseLanhDaoChoYKienVBDiScreen}
        options={{ gestureEnabled: true, gestureDirection: "horizontal" }}
      />
      {/* VB tim kiem stack */}
      {/* <Stack.Screen
        name="ChooseVbTimKiemCoQuanGuiScreen"
        component={ChooseVbTimKiemCoQuanGuiScreen}
        options={{ gestureEnabled: true, gestureDirection: "horizontal" }}
      />
      <Stack.Screen
        name="ChooseVbTimKiemNguoiKyScreen"
        component={ChooseVbTimKiemNguoiKyScreen}
        options={{ gestureEnabled: true, gestureDirection: "horizontal" }}
      />
      <Stack.Screen
        name="ChooseVbTimKiemLoaiVanBanScreen"
        component={ChooseVbTimKiemLoaiVanBanScreen}
        options={{ gestureEnabled: true, gestureDirection: "horizontal" }}
      /> */} 
    </Stack.Navigator>
  );

}

