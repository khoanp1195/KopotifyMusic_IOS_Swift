import {createSlice, createAsyncThunk} from '@reduxjs/toolkit';
import {get} from '../../services/ApiServices';
import {RESONSE_STATUS_SUCCESS} from 'helpers/Constants';
import {BASE_URL} from 'helpers/Constants';
import {isNullOrUndefined} from 'helpers/Functions';
import axios from 'axios';

export const fetchCountDashboard = createAsyncThunk(
  'dashboard/fetchCountDashboard',
  async (subSite: any) => {
    const res = await get(
      `/${subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=Get&function=GetCountNotify&status=0&params=Status`,
    );

    if (!isNullOrUndefined(res)) {
      if (res.data.status === RESONSE_STATUS_SUCCESS) {
        return res.data.data[0];
      }
    }
    return null;
  },
);


//fetchGetNewDocument
export const fetchGetNewDocument = createAsyncThunk(
  'dashboard/fetchGetNewDocument',
  async (payload: any) => {
    const { limit, offset } = payload;
    const LangId = 1066;
    const Params = {
      Offset: offset,
      Limit: limit,
      LangId: LangId
    };
    console.log('Params', Params);
    try {
      let responseGetnewDocument = null;
      const url =`https://vnadmsuatportal.vuthao.com/psd/workflow/_layouts/15/VuThao.Bidv.API/ApiNotify.ashx?func=GetViewDocumentNew&LangId=${LangId}&Params=${JSON.stringify(Params)}&Limit=${limit}&Offset=${offset}`;
      console.log("url =>>> " + url)
      try{
        const response = await axios.get(url, {
          headers: {
            'Content-Type': 'application/json', // Adjust the content type as needed
          },
        });
        if (response?.status === 200) {
          responseGetnewDocument = response?.data.data;
          console.log('responseGetnewDocument day nha : =>> ' + responseGetnewDocument);
        } else {
          console.error('Load Data Failed:');
        }
        return {
          dataNewDocument: response?.data.data,
        };

      }catch(ex)
      {
        console.error('Error in GET request:', ex);
      }
      console.log('responseGetnewDocument =>>> ', responseGetnewDocument);ß
      if (!isNullOrUndefined(responseGetnewDocument)) {
        if (responseGetnewDocument.data.status === RESONSE_STATUS_SUCCESS) {
          return responseGetnewDocument.data.data;
        }
      }
      return null; // Return null if no response or status is not successful
    } catch (error) {
      console.error('Error fetching data:', error);
      throw error; // You might want to handle or log the error accordingly
    }
  }
);



// List<KeyValuePair<string, string>> lstGet = new List<KeyValuePair<string, string>>();
// lstGet.Add(new KeyValuePair<string, string>("func", "GetViewDocumentNew"));
// lstGet.Add(new KeyValuePair<string, string>("LangId", CmmVariable.SysConfig.LangCode));
// lstGet.Add(new KeyValuePair<string, string>("Params", "LangId,Offset,Limit"));
// lstGet.Add(new KeyValuePair<string, string>("Offset", _offset.ToString()));
// lstGet.Add(new KeyValuePair<string, string>("Limit", _limit.ToString()));
//      const url = `${BaseUrl}/workflow/_layouts/15/VuThao.Bidv.API/ApiWorkflow.ashx?func=WorkflowButtons&data=${JSON.stringify(data)}`;
//https://vnadmsuatportal.vuthao.com/psd/API/ApiMobile.ashx?func=GetViewDocumentNew&LangId=1066&Params=LangId%2COffset%2CLimit&Offset=0&Limit=5 
const dashBoardSlice = createSlice({
  name: 'dashboard',
  initialState: {
    dashboardCountData: {
      ViecCanXuLy: 0,
      ThongBao: 0,
      VanBanPhoiHop: 0,
    },
    isLoading: false,
    totalRecord: 0,
    dataNewDocument:[]
  },
  reducers: {},
  extraReducers: builder => {
    builder.addCase(fetchCountDashboard.fulfilled, (state: any, action) => {
      state.dashboardCountData = action.payload;
    });

    builder.addCase(fetchGetNewDocument.fulfilled, (state: any, action) => {
      state.dataNewDocument = action.payload?.dataNewDocument
    })
  },
});

const {reducer} = dashBoardSlice;
export default reducer;
