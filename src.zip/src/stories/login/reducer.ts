import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';
import { get, post } from '../../services/ApiServices';
import { BASE_URL, RESONSE_STATUS_SUCCESS } from 'helpers/Constants';
import { isNullOrUndefined } from 'helpers/Functions';
interface PayloadAction {
    userName: String;
    password: String;
}

export const loginRequestApi = createAsyncThunk(
    'login/loginRequest',
    async (payload: PayloadAction) => {
        let data = new FormData();
        console.log('payloadpayload', payload);

        // const jsonData = { UserName: "vnadmsuat.adminsite", Password: "vnadmsuat@123$%" }
        const jsonData = { UserName: payload.userName, Password: payload.password }
        data.append("data", JSON.stringify(jsonData));
        let config = {
            method: 'post',
            url: 'https://vnadmsuatportal.vuthao.com/psd/api/ApiMobile.ashx?func=AdfsLogin',
            data: data,
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'multipart/form-data',
            },
        };
        const a = await axios(config);
        const response = await axios(config);
        console.log('responseresponse222', response.data);
        if (response?.data?.status === RESONSE_STATUS_SUCCESS) {
            return {
                username: payload.userName,
                password: payload.password
            }
        }
        return;
    }
);

export const fetchCurrentUser = createAsyncThunk(
    'home/currentUser',
    async ({ subSite, deviceInfo }: any) => {
        const res = await post(
            `/${subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=Get&function=CurrentUser`,
            deviceInfo,
        );
        if (!isNullOrUndefined(res)) {
            if (res.data.status.toString() === RESONSE_STATUS_SUCCESS) {
                return res.data.data;
            }
        }

        return null;
    },
);
export const fetchRealSite = createAsyncThunk(
    'fetchRealSite',
    async (accountName: any) => {
        const url =
            '/pa/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=GetRealSite';
        const data = { AccountName: accountName };
        const response = await post(url, data);
        if (response?.data?.status === RESONSE_STATUS_SUCCESS) {
            return response.data.data;
        }
    },
);

export const logOut = createAsyncThunk(
    'logOut',
    async ({ deviceId, subSite }: any) => {
        const res = await get(
            `/${subSite}/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=Get&function=SignOut&DeviceId=${deviceId}&params=DeviceId`,
        );
        return res;
    },
);

const loginSlice = createSlice({
    name: 'login',
    initialState: {
        isLogin: false,
        isAuth: false,
        subSite: 'pa',
        dataCurrentUsers: [],
        isLogging: false,
        isLoading: false,
        isShowWarning: false
    },
    reducers: {
        logoutAction(state, action) {
            state.isLogin = false;
            state.isAuth = false;
            state.isLogging = false;
        },
        setIsLogging(state, action) {
            return { ...state, isError: action.payload };
        },
        setHideWarning(state, action) {
            return { ...state, isShowWarning: false };
        },
    },
    extraReducers: builder => {
        builder
            .addCase(loginRequestApi.pending, (state: any) => {
                state.isLoading = true;
                state.isLogging = false;
                state.isShowWarning = false;
            })
            .addCase(loginRequestApi.fulfilled, (state: any, action: any) => {
                state.isLoading = false;
                if (!isNullOrUndefined(action.payload?.username)) {
                    state.isAuth = true;
                    state.isLogging = true;
                } else {
                    state.isAuth = false;
                    state.isLogging = false;
                    state.isShowWarning = true;
                }
            })
            .addCase(loginRequestApi.rejected, (state: any) => {
                state.isLoading = false;
                state.isLogging = false;
                state.isShowWarning = true;
            })
            .addCase(fetchCurrentUser.fulfilled, (state: any, action) => {
                if (!isNullOrUndefined(action.payload)) {
                    state.dataCurrentUsers = action.payload;
                }
            })
            .addCase(fetchRealSite.pending, (state: any) => {
                state.isLogin = false;
            })
            .addCase(fetchRealSite.fulfilled, (state: any, action) => {
                if (!isNullOrUndefined(action.payload)) {
                    state.subSite = action.payload[0].RealSite;
                    state.isLogin = true;
                } else {
                    state.isLogin = false;
                }
            })
            .addCase(fetchRealSite.rejected, (state: any) => {
                state.isLogin = false;
            });
    },
});
export const { logoutAction, setIsLogging, setHideWarning } = loginSlice.actions;
const { reducer } = loginSlice;
export default reducer;
