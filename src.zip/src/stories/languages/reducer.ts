import { createSlice, } from '@reduxjs/toolkit';

const languagesSlice = createSlice({
  name: 'languages',
  initialState: {
    languages: require("../../languages/en").default,
    languagesText: 'EN'
  },
  reducers: {
    setLanguagesAction(state, action) {
      const isEng = action.payload === 'EN'
      return {
        ...state,
        languages: isEng ? require("../../languages/vi").default : require("../../languages/en").default,
        languagesText: isEng ? 'VI' : 'EN'
      };
    },
  },
  extraReducers: builder => {

  },
});
export const { setLanguagesAction } = languagesSlice.actions;
const { reducer } = languagesSlice;
export default reducer;
