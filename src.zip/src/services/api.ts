export const BaseUrl = 'https://bidvdpm.vuthao.com'; 
// export const BaseUrl = 'https://petrolimex.vuthao.com';                 // DEV
// export const BaseUrl = 'https://papetrolimexuat.vuthao.com';              // UAT
//export const BaseUrl = 'https://eofficeuat.petrolimexaviation.com.vn';    // MIG
//export const BaseUrl = 'https://eoffice.petrolimexaviation.com.vn';         // LIVE