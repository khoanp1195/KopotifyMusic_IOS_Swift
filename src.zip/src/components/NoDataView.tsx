import React, {FC} from 'react';
import {
  ImageBackground,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import {FontSize} from 'helpers/Constants';
import colors from '../helpers/Colors';

interface Props {
  onRetryPress?: () => any;
}

const NoDataView: FC<Props> = (props: Props) => {
  return (
    <ImageBackground
      style={styles.viewNoData}
      source={require('../assets/images/img_avatar_grey.png')}>
      <Text style={styles.textNoData}>Không có dữ liệu</Text>
    </ImageBackground>
  );
};

const styles = StyleSheet.create({
  viewNoData: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  textNoData: {
    fontSize: FontSize.LARGE_X,
    color: colors.primary,
  },
});

export default React.memo(NoDataView);
