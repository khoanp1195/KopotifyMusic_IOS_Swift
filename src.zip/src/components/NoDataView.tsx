import React, { FC } from "react";
import {
  ImageBackground,
  StyleSheet,
  Text,
} from "react-native";
import { FontSize } from "../themes/const";
import colors from "../themes/Color";

interface Props {
  onRetryPress: () => any;
}

const NoDataView: FC<Props> = (props: Props) => {
  return (
    <ImageBackground
      style={styles.viewNoData}
      source={require("../assets/img_bg.png")}
    >
      <Text style={styles.textNoData}>Không có dữ liệu</Text>
    </ImageBackground>
  );
};

const styles = StyleSheet.create({
  viewNoData: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  textNoData: {
    fontSize: FontSize.LARGE_X,
    color: colors.primary,
  },
});

export default NoDataView;
