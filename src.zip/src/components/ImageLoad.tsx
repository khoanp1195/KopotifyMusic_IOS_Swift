import React, { useCallback, useState } from 'react';
import PropTypes from 'prop-types';
import { Image, ImageBackground, ActivityIndicator, View, StyleSheet } from 'react-native';
import FastImage from 'react-native-fast-image';

const ImageLoad = (props: any) => {
    const {
        style, source
    } = props;

    const [image, setImage] = useState(source)

    const onError = useCallback(() => {
        setImage(require('../assets/images/avatar80.png'))
    }, [])

    return (
        <FastImage
            style={style}
            source={image}
            resizeMode={FastImage.resizeMode.cover}
            onError={onError}
        />
    );
}

export default ImageLoad