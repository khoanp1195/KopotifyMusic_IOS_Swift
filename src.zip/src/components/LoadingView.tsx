import React, { FC } from "react";
import { ActivityIndicator, StyleSheet, View } from "react-native";
import colors from "../themes/Color";
const LoadingView: FC = (props: any) => {
  const { isLoading = false, color = colors.primary } = props;
  if (!isLoading) return null;
  return (
    <View style={styles.viewLoading}>
      <ActivityIndicator color={color} />
    </View>
  );
};
const styles = StyleSheet.create({
  viewLoading: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: "rgba(0, 0, 0, 0.333333)",
    alignItems: "center",
    justifyContent: "center",
  },
});

export default LoadingView;
