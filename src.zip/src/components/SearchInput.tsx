import { StyleSheet, View } from "react-native";
import React from "react";
import TextInputCustom from "./TextInputCustom";
import colors from "../themes/Color";
import { FontSize, dimensWidth } from "../themes/const";
import { SearchIcon } from "../assets/SVG";

interface Props {
  filterText: string;
  onChangeFilterText: (text: string) => void;
}
const SearchInput = ({ filterText, onChangeFilterText }: Props) => {
  return (


   <TextInputCustom
      placeholder="Tìm kiếm …"
      placeholderTextColor={colors.lightBlack}
      numberOfLines={1}
      onChangeText={(text) => onChangeFilterText(text)}
      value={filterText}
      autoCapitalize="none"
      style={styles.userNameInput}
    />

 
  );
};
const styles = StyleSheet.create({
  userNameInput: {
    marginHorizontal: 15,
    paddingStart: 15,
    width: '95%',
    backgroundColor: 'rgba(128, 128, 128, 0.1)',
    borderRadius: dimensWidth(10),
    color: colors.lightBlack,
    fontSize: FontSize.SMALL,
    height: dimensWidth(37),
    justifyContent: 'center'
  },
  inputContainer:{
    flexDirection: 'row',
    alignItems: 'center',

  },
  icon:{
    marginRight: 10
  },

});
export default SearchInput;
