import React, { memo } from 'react';
import { Image, StyleSheet } from 'react-native';

const Logo = () => (
  <Image source={require('../assets/icon_loginvna.png')} style={styles.image} />
);

const styles = StyleSheet.create({
  image: {
    width: 432,
    height: 300,
    marginTop: 50,
  },
});

export default memo(Logo);
