import React, { memo } from 'react';
import { View, StyleSheet, Text, Image } from 'react-native';
import { TextInput as Input } from 'react-native-paper';
import { theme } from '../core/theme';
import { Icon } from 'react-native-elements/dist/icons/Icon';

type Props = React.ComponentProps<typeof Input> & { errorText?: string };

const TextInput = ({ errorText, ...props }: Props) => (
  <View style={styles.container}>
  <Input
    style={styles.input}
    selectionColor={theme.colors.borderColor}
    right={
      <View style={styles.iconContainer}>
      <Image
        source={require('../assets/icon_eye.png')} // Provide the path to your image
        style={styles.image}
      />
    </View>
    }
    underlineColor="transparent"
    mode="outlined"
    {...props}
  />

{/* <View style={styles.input}>
      <Image
        source={require('../assets/icon_eye.png')} // Provide the path to your image
        style={styles.image}
      />
    </View> */}

  {/* {errorText ? <Text style={styles.error}>{errorText}</Text> : null} */}
  {/* <View style={styles.container}>
        <Image
          source={require('../assets/icon_eye.png')} // Provide the path to your image
          style={styles.image}
        />
      </View> */}
</View>
);

const styles = StyleSheet.create({
  container: {
    width: '100%',
    marginVertical: 12,
  },
  iconContainer:{
    width: 20,
    height:20,
  },
  input: {
    backgroundColor: theme.colors.borderColor,

  },
  error: {
    fontSize: 14,
    color: theme.colors.error,
    paddingHorizontal: 4,
    paddingTop: 4,
  },
  image:{
    color: theme.colors.error,
    height: 20,
    width:25,
    resizeMode:'stretch',
    position:'absolute'
  }
});
// vthu1
// VTlamson123!@#

export default memo(TextInput);
