import React, { useState, useMemo, memo } from "react";
import { View, StyleSheet, Image } from "react-native";
import FastImage from "react-native-fast-image";
import { BaseUrl } from "../services/api";

const CachedImage = (props: any) => {
    console.log(props)
    return (
        <View style={props.itemAvatar}>
            <Image style={[props.itemAvatar, StyleSheet.absoluteFill]} resizeMode="cover" source={require('../assets/images/avatar80.png')} />
            <FastImage
                style={props.itemAvatar}
                source={{
                    uri: BaseUrl + `/${props.subSite}` + props.ImagePath,
                    headers: { Authorization: `${props.token}` },
                    priority: FastImage.priority.normal
                }}
                resizeMode={FastImage.resizeMode.cover}
            />
        </View>
    )
}

export default CachedImage
