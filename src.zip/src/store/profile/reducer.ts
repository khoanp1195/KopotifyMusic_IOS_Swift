import {
  createAsyncThunk,
  createEntityAdapter,
  createSlice,
} from '@reduxjs/toolkit';
import axios from 'axios';
import { arrayIsEmpty, isNullOrUndefined } from '../../helpers/formater';
import { BaseUrl } from '../../services/api';

//Get Data Dang xu ly
export const fetchCurrentUsers = createAsyncThunk(
  'profile/fetchCurrentUsers',
  async ({ subSite, deviceInfo }: any) => {
      const form = new FormData();
      form.append("data", JSON.stringify(deviceInfo));
      const res = await axios({
        method: 'post', url: `${BaseUrl}/workflow/_layouts/15/VuThao.Bidv.API/ApiUser.ashx?func=GetUserInfo`, data: form,
        headers: {
          'Content-Type': `multipart/form-data`,
        },
      });
  
      return res?.data?.data;
    },
);

//Logout
export const logout = createAsyncThunk (
  'profile/logout', async(deviceId: any, payload: any) => {
      const res = await axios.get(
          `${BaseUrl}/_layouts/15/VuThao.Bidv.API/APIExportData.ashx?func=DeleteUser`,
      );
      return res
      console.log('logout => ' + res)
  }
)

// Define the initial state
const initialState = {
loading: false,
error: null,
token: '',
isLogging: false,
isAuth: false,
isLogin: false,
};

const usersSlice = createSlice({
  name: 'profile',
  initialState,
  reducers: {
      setCurrentUser(state, action) {
          return { ...state, dataCurrentUsers: action.payload }
        },
      logoutAction(state, action)
      {
          state.isLogin = false;
          state.isAuth = false
          state.token = '';
          state.isLogging = false
          console.log('logout => ' +   state.isLogin )
      }
  },
  extraReducers: (builder) => {
    builder
    builder.addCase(fetchCurrentUsers.fulfilled, (state: any, action) => {
      state.dataCurrentUsers = action.payload;
    });
  },
});

export const { logoutAction, setCurrentUser } = usersSlice.actions;
const { reducer } = usersSlice;
export default reducer;
