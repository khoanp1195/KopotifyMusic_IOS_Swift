import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';
import { Alert, Platform } from 'react-native';
import { isNullOrUndefined } from '../../helpers/formater';
import { BaseUrl } from '../../services/api';
import { RESONSE_STATUS_SUCCESS } from '../../themes/const';

interface PayloadAction {
  userName: String;
  password: String;
}
export const loginRequestApi = createAsyncThunk(
  'loginRequest',
  async (payload: PayloadAction) => {
    let xmls = `<?xml version="1.0" encoding="utf-8"?>\
      <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">\
      <soap:Body>\
        <Login xmlns="http://schemas.microsoft.com/sharepoint/soap/">\
          <username>${payload.userName}</username>\
          <password>${payload.password}</password>\
        </Login>\
        </soap:Body>\
</soap:Envelope>`;
    let SOAPAction = 'http://schemas.microsoft.com/sharepoint/soap/Login';
    try {
      const response = await axios.post(
        `${BaseUrl}/_vti_bin/authentication.asmx`,
        xmls,
        {
          headers: {
            'Content-Type': 'text/xml; charset=utf-8',
            SOAPAction: SOAPAction,
          },
        },
      );
      if (!isNullOrUndefined(response.headers["set-cookie"])) {
        return {
          token: response.headers["set-cookie"],
          username: payload.userName,
          password: payload.password,
   
        }     
      }
      console.log(response.headers["set-cookie"])
    } catch (error) {
      console.log(error)
      return
    }
  },
);
//Logout
export const logout = createAsyncThunk (
  'profile/logout', async(deviceId: any, payload: any) => {
      const res = await axios.get(
          `${BaseUrl}/_layouts/15/VuThao.Bidv.API/APIExportData.ashx?func=DeleteUser`,
      );
      return res
      console.log('logout => ' + res)
  }
)

const loginSlice = createSlice({
  name: 'loginRequest',
  initialState: {
    isLogin: false,
    isLoading: false,
    subSite: '',
    changeSiteNotification: "",
    token: '',
    isLogging: false,
    isAuth: false,
    dataCurrentUsers: [],
    remoteMessage: {}
  },
  reducers: {
    logoutAction(state, action) {
      state.isLogin = false;
      state.isAuth = false
      state.token = '';
      state.changeSiteNotification = '';
      state.isLogging = false
    },
    setCurrentUser(state, action) {
      return { ...state, dataCurrentUsers: action.payload }
    },
    setSubSite(state, action) {
      return { ...state, subSite: action.payload }
    },
    setIsLogging(state, action) {
      return { ...state, isError: action.payload }
    },
  },
  extraReducers: builder => {
    builder
      .addCase(loginRequestApi.pending, (state: any) => {
        state.isLoading = true;
        state.isLogging = true
      })
      .addCase(loginRequestApi.fulfilled, (state: any, action) => {
        if (!isNullOrUndefined(action.payload)) {
          state.token = action?.payload?.token
          state.isAuth = true
          state.isLogging = true;
          state.isLogin = true;
          Alert.alert('Thông báo', 'Đăng nhập thành công.');
            console.log( state.token)
        } else {
          Alert.alert('Thông báo', 'Thông tin đăng nhập không chính xác. Vui lòng thử lại');
          state.isAuth = false;
       
          state.isLogging = false;
        }
      })

  },
});
export const { logoutAction,setCurrentUser, setSubSite, setIsLogging } = loginSlice.actions;
const { reducer } = loginSlice;
export default reducer;
