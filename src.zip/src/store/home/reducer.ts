import {
  createAsyncThunk,
  createEntityAdapter,
  createSlice,
} from '@reduxjs/toolkit';
import axios from 'axios';
import { arrayIsEmpty, isNullOrUndefined } from '../../helpers/formater';
import { BaseUrl } from '../../services/api';
interface UserData {
  id: number;
  email: string;
  first_name: string;
  last_name: string;
  avatar: string;
}

//Get Data Dang xu ly
export const fetchDANGXLAPI = createAsyncThunk(
  'home/fetchDANGXL',
  async (payload: any) => {
      const {status,limit, offset} = payload
      const reponseDangXL = await axios.get(
          `${BaseUrl}/workflow/_layouts/15/VuThao.Bidv.API/ApiNotify.ashx?func=${status}&Limit=${limit}&Offset=${offset}`,
          );
     // console.log("Data dang xu ly " + reponseDangXL)
      return {
          data: reponseDangXL?.data?.data?.data,
          offset,
          // limit: 20,
          totalRecord: reponseDangXL?.data?.data?.total,
          status        
      }
  },
);
//Get Data Da Xu Ly
export const fetchDAXULYLAPI = createAsyncThunk(
  'home/fetchDAXL',
  async (payload: any) => {
      const { limit, offset} = payload
      const reponseDangXL = await axios.get(
          `${BaseUrl}/workflow/_layouts/15/VuThao.Bidv.API/ApiNotify.ashx?func=GetCompletedNotify&Limit=${limit}&Offset=${offset}`,
          );
     // console.log("Data dang xu ly " + reponseDangXL)
      return {
          data: reponseDangXL?.data?.data?.data,
          offset: 0,
          limit: 20,
          totalRecord: reponseDangXL?.data?.data?.total,
      }
  },
);

//Get GetWorkflowItem
export const fetchGetWorkflowItem = createAsyncThunk(
  'home/workflowItem',
  async ({itemId, ListName}: any) => {
    // const {itemId, listName} = payload
    const data = {
      ItemID:1820,
      ListName: "Kế hoạch Chuẩn bị đầu tư",
    };
    if (ListName === 'Kế hoạch Chuẩn bị đầu tư') {
      const dataViewFields = 'ID;Author;Title;TMDTDuKien;TenDuAn;YearCategory;LinhVuc;DonViDauMoi'
      const data = {ViewFields: dataViewFields};
      const gridInfos = {
        ListName: 'Chi tiết kế hoạch dự án',
        ViewFields: 'ProjectStep;TotalDays;FromDate;ToDate',
      };
      const gridInfosArr = [gridInfos]
     const data2 = {GridInfos: gridInfosArr}; 
     const form = new FormData();
     form.append("data",JSON.stringify(data2))
     const url =   `${BaseUrl}/workflow/_layouts/15/VuThao.Bidv.API/ApiWorkflow.ashx?func=WorkflowFormDetail`;
     const response = await axios({
      method: 'GET', url: url, data: form,
      headers: {
          'Content-Type': 'multipart/form-data',
      },
      });
      let retdata
      retdata = response.data.WorkflowItem;
      console.log('retdata' + retdata)
      return retdata
    }
  }
)

export const usersAdapter = createEntityAdapter<UserData>();
// Define the initial state
const initialState = {
data: [], // You can define the initial state structure here
error: null,
totalRecord: 0,
retdata: [],
isLoadingDangXuLy: false,
isLoadMoreDangXuly: false
};

const homeSlice = createSlice({
  name: 'home',
  initialState,
  reducers: {
      SetisLoadingDangXuly(state,action){
        return {
          ...state,
          isLoadingDangXuLy: action.payload
        }
      }
  },
  extraReducers: (builder) => {
    builder

    //-------fetchDANGXLAPI----------
      .addCase(fetchDANGXLAPI.pending, (state) => {
        state.isLoadingDangXuLy = true;
      })
      .addCase(fetchDANGXLAPI.fulfilled, (state: any, action) => {
        state.loading = false;
        state.data = action.payload.data;
        state.totalRecord = action.payload.totalRecord;
        state.isLoadMoreDangXuly = action.payload.data.length !== 0
        state.isLoadingDangXuLy = false;
        console.log(state.totalRecord)
      })
      .addCase(fetchDANGXLAPI.rejected, (state, action) => {
        state.isLoadingDangXuLy = false;
       // state.error = action.error.message;
      })
      //------------------------------


      .addCase(fetchDAXULYLAPI.fulfilled, (state, action) => {
        // state.loading = false;
        state.data = action.payload.data;
        state.totalRecord = action.payload.totalRecord;
        console.log(state.totalRecord)
      })
      .addCase(fetchGetWorkflowItem.fulfilled, (state, action) => {
        // state.loading = false;
        state.retdata = action.payload.retdata;
        console.log("detail data " + state.data)
      })
  },
});
export const { SetisLoadingDangXuly } = homeSlice.actions;
const { reducer } = homeSlice;
export default reducer;
