import {
  createAsyncThunk,
  createEntityAdapter,
  createSlice,
} from '@reduxjs/toolkit';
import axios from 'axios';

import { arrayIsEmpty, isNullOrUndefined } from '../../helpers/formater';
import { BaseUrl } from '../../services/api';
interface UserData {
  id: number;
  email: string;
  first_name: string;
  last_name: string;
  avatar: string;
}


//Get Data Dang xu ly
export const fetchDANGXLAPI = createAsyncThunk(
  'home/fetchDANGXL',
  async (payload: any) => {
      const {status,limit, offset} = payload
      const reponseDangXL = await axios.get(
          `${BaseUrl}/workflow/_layouts/15/VuThao.Bidv.API/ApiNotify.ashx?func=${status}&Limit=${limit}&Offset=${offset}`,
          );
     // console.log("Data dang xu ly " + reponseDangXL)
      return {
          data: reponseDangXL?.data?.data?.data,
          offset: 0,
          limit: 20,
          totalRecord: reponseDangXL?.data?.data?.total,
          status        
      }
 
  },
);
//Get Data Da Xu Ly
export const fetchDAXULYLAPI = createAsyncThunk(
  'home/fetchDAXL',
  async (payload: any) => {
      const { limit, offset} = payload
      const reponseDangXL = await axios.get(
          `${BaseUrl}/workflow/_layouts/15/VuThao.Bidv.API/ApiNotify.ashx?func=GetCompletedNotify&Limit=${limit}&Offset=${offset}`,
          );
     // console.log("Data dang xu ly " + reponseDangXL)
      return {
          data: reponseDangXL?.data?.data?.data,
          offset: 0,
          limit: 20,
          totalRecord: reponseDangXL?.data?.data?.total,
         
      }
 
  },
);




export const usersAdapter = createEntityAdapter<UserData>();

// Define the initial state
const initialState = {
data: [], // You can define the initial state structure here
loading: false,
error: null,
totalRecord: 0
};


const usersSlice = createSlice({
  name: 'home',
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(fetchDANGXLAPI.pending, (state) => {
        state.loading = true;
      })
      .addCase(fetchDANGXLAPI.fulfilled, (state, action) => {
        state.loading = false;
        state.data = action.payload.data;
        state.totalRecord = action.payload.totalRecord;
        console.log(state.totalRecord)
      })
      .addCase(fetchDAXULYLAPI.fulfilled, (state, action) => {
        state.loading = false;
        state.data = action.payload.data;
        state.totalRecord = action.payload.totalRecord;
        console.log(state.totalRecord)
      })
      .addCase(fetchDANGXLAPI.rejected, (state, action) => {
        state.loading = false;
       // state.error = action.error.message;
      });
  },
});

export const {  } = usersSlice.actions;
const { reducer } = usersSlice;
export default reducer;
