import {
  createAsyncThunk,
  createEntityAdapter,
  createSlice,
} from '@reduxjs/toolkit';
import axios from 'axios';
import { arrayIsEmpty, isNullOrUndefined } from '../../helpers/formater';
import { BaseUrl } from '../../services/api';
interface UserData {
  id: number;
  email: string;
  first_name: string;
  last_name: string;
  avatar: string;
}

//Get Data Dang xu ly
export const fetchDANGXLAPI = createAsyncThunk(
  'home/fetchDANGXL',
  async (payload: any) => {
      const {status,limit, offset} = payload
      const reponseDangXL = await axios.get(
          `${BaseUrl}/workflow/_layouts/15/VuThao.Bidv.API/ApiNotify.ashx?func=${status}&Limit=${limit}&Offset=${offset}`,
          );
     // console.log("Data dang xu ly " + reponseDangXL)
      return {
          data: reponseDangXL?.data?.data?.data,
          offset,
          // limit: 20,
          totalRecord: reponseDangXL?.data?.data?.total,
          status        
      }
  },
);
//Get Data Da Xu Ly
export const fetchDAXULYLAPI = createAsyncThunk(
  'home/fetchDAXL',
  async (payload: any) => {
      const { limit, offset} = payload
      const reponseDangXL = await axios.get(
          `${BaseUrl}/workflow/_layouts/15/VuThao.Bidv.API/ApiNotify.ashx?func=GetCompletedNotify&Limit=${limit}&Offset=${offset}`,
          );
     // console.log("Data dang xu ly " + reponseDangXL)
      return {
          data: reponseDangXL?.data?.data?.data,
          offset: 0,
          limit: 20,
          totalRecord: reponseDangXL?.data?.data?.total,
      }
  },
);



//GetData Dang Xu Ly Filter
export const fetchGetDataFilterAPI = createAsyncThunk(
  'home/fetchDataFilter',
  async(payload: any) => {
    const { limit, offset, KeyWord, count,FromDate,ToDate,TinhTrang} = payload
    const responseDataFilter = await axios.get(
      // `${BaseUrl}/workflow/_layouts/15/VuThao.Bidv.API/ApiNotify.ashx?&limit=99&offset=0&count=-1&KeyWord=&FromDate=2023%2F06%2F25&ToDate=2023%2F09%2F09&func=GetInprocessNotify`,
      `${BaseUrl}/workflow/_layouts/15/VuThao.Bidv.API/ApiNotify.ashx?&limit=99&offset=0&count=${count}&KeyWord=${KeyWord}&FromDate=${FromDate}&ToDate=${ToDate}&func=${TinhTrang}`,
    );
   console.log("fetchGetDataFilterAPI: =====>>" + responseDataFilter?.data?.data?.data)
    return{
      data: responseDataFilter?.data?.data?.data
    }
  }
  
)




//Get GetWorkflowItem
export const fetchGetWorkflowItem = createAsyncThunk(
  'home/workflowItem',
  async ({workflowItemIDD, ListName}: any) => {
    // const {itemId, listName} = payload
    console.log('fetchGetWorkflowItem - data: ' + workflowItemIDD, ListName)
    try {
      const data = {
        ItemID: workflowItemIDD,
        ListName: ListName,
      };
    
      let retdata = null; // Initialize retdata to null
    
      if (data.ListName === 'Kế hoạch Chuẩn bị đầu tư') {
        const dataViewFields = 'ID;Author;Title;TMDTDuKien;TenDuAn;YearCategory;LinhVuc;DonViDauMoi';
       
       
        const dataToSend = { 
          ItemID: workflowItemIDD,
          ListName: ListName,
          ViewFields: dataViewFields,
          GridInfos: [
            {
              ListName: "Chi tiết kế hoạch dự án",
              ViewFields: "ProjectStep;TotalDays;FromDate;ToDate"
            }
          ]};
        
        // Construct the URL with query parameters
        const url = `${BaseUrl}/workflow/_layouts/15/VuThao.Bidv.API/ApiWorkflow.ashx?func=WorkflowFormDetail&data=${JSON.stringify(dataToSend)}`;
    
        console.log('Url Here nhaaaaa : =>>> ' + url)
        try {
          // Make a GET request with Axios
          const response = await axios.get(url, {
            headers: {
              'Content-Type': 'application/json', // Adjust the content type as needed
            },
          });
    
          // Check if the response was successful and retrieve data
          if (response?.status === 200) {
            retdata = response?.data.data.WorkflowItem;
            console.log('retdata day nha : =>> ' + retdata);
          } else {
            console.error('Load Data Failed:', response?.data?.data.WorkflowItem[0].DonViDauMoi);
          }

          return {
            data: response?.data.data.WorkflowItem
          };
        } catch (ex) {
          console.error('Error in GET request:', ex);
        }
      
      }
    } catch (ex) {
      console.error('Error in fetchGetWorkflowItem:', ex);
    }
    

  //   try{
  //     const data = {
  //       ItemID:1820,
  //       ListName: "Kế hoạch Chuẩn bị đầu tư",
  //     };
  //     if (ListName === 'Kế hoạch Chuẩn bị đầu tư') {
  //       const dataViewFields = 'ID;Author;Title;TMDTDuKien;TenDuAn;YearCategory;LinhVuc;DonViDauMoi'
  //       const data = {ViewFields: dataViewFields};
  //       const gridInfos = {
  //         ListName: 'Chi tiết kế hoạch dự án',
  //         ViewFields: 'ProjectStep;TotalDays;FromDate;ToDate',
  //       };
  //       const gridInfosArr = [gridInfos]
  //      const data2 = {GridInfos: gridInfosArr}; 
  //      console.log('data2 =>>>' + data2)
  //      const form = new FormData();
  //      form.append("data",JSON.stringify(data2))

  //    const url =   `${BaseUrl}/workflow/_layouts/15/VuThao.Bidv.API/ApiWorkflow.ashx?func=WorkflowFormDetail`;
    
  //   const response = await axios({
  //     method: 'get', url: url, data: form,
  //     headers: {
  //         'Content-Type': `multipart/form-data`,
  //     },
  // });

  //     //  const reponse = await axios.get(
  //     //   `${BaseUrl}/workflow/_layouts/15/VuThao.Bidv.API/ApiWorkflow.ashx?func=WorkflowFormDetail`
  //     //   );
  //       let retdata = response?.data?.data?.WorkflowItem
  //       console.log('retdata: =>> ' + retdata)
  //      //  const response = await axios({
  //     //   method: 'get', url: url, data: form,
  //     //   headers: {
  //     //       'Content-Type': 'multipart/form-data',
  //     //   },
  //     //   });
  //       // let retdata
  //       // if(response?.headers.status === "SUCCESS")
  //       // {
  //       //   retdata = response.data;
  //       //   console.log('retdata: =>>>>>' + retdata)
  //       // }
  //       // else
  //       // {       
  //       //   retdata = response?.data?.data;
  //       //   console.log('Load DataFailed : =>>>>>' + retdata)
  //       // }
  //       return retdata
  //     }
  //   }catch(ex)
  //   {
  //     console.error('Error in fetchGetWorkflowItem:', ex);
  //   }
  }
)

export const usersAdapter = createEntityAdapter<UserData>();
// Define the initial state
const initialState = {
data: [], // You can define the initial state structure here
error: null,
totalRecord: 0,
retdata: [],
isLoadingDangXuLy: false,
isLoadMoreDangXuly: false,
dataFilterDangXL: []
};

const homeSlice = createSlice({
  name: 'home',
  initialState,
  reducers: {
      SetisLoadingDangXuly(state,action){
        return {
          ...state,
          isLoadingDangXuLy: action.payload
        }
      }
  },
  extraReducers: (builder) => {
    builder

    //-------fetchDANGXLAPI----------
      .addCase(fetchDANGXLAPI.pending, (state) => {
        state.isLoadingDangXuLy = true;
      })
      .addCase(fetchDANGXLAPI.fulfilled, (state: any, action) => {
        state.loading = false;
        state.data = action.payload.data;
        state.totalRecord = action.payload.totalRecord;
        state.isLoadMoreDangXuly = action.payload.data.length !== 0
        state.isLoadingDangXuLy = false;
        console.log(state.totalRecord)
      })
      .addCase(fetchDANGXLAPI.rejected, (state, action) => {
        state.isLoadingDangXuLy = false;
       // state.error = action.error.message;
      })
      //------------------------------

      .addCase(fetchGetDataFilterAPI.fulfilled, (state: any, action) => {
        state.loading = false;
        state.dataFilterDangXL = action.payload.data
      })


      .addCase(fetchDAXULYLAPI.fulfilled, (state, action) => {
        // state.loading = false;
        state.data = action.payload.data;
        state.totalRecord = action.payload.totalRecord;
        console.log(state.totalRecord)
      })
      .addCase(fetchGetWorkflowItem.fulfilled, (state, action) => {
        // state.loading = false;
        state.retdata = action.payload?.data
      })
  },
});
export const { SetisLoadingDangXuly } = homeSlice.actions;
const { reducer } = homeSlice;
export default reducer;
