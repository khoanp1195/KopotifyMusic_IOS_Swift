import moment from 'moment';

export const removeSpecialCharacters = str => {
  if (!str) {
    return '';
  }
  if (str.includes(';#')) {
    const separator = ';#';
    return str.split(separator)[1];
  } else {
    return str;
  }
};

export const removeNumbersAndHashes = str => {
  if (!str) {
    return '';
  }
  // Remove numbers
  str = str.replace(/\d+/g, '');

  // Remove '#'
  str = str.replace(/#/g, '');

  // Remove extra semicolons
  str = str.replace(/;;/g, ';');

  // Remove leading and trailing semicolons
  str = str.replace(/(^;)|(;$)/g, '');

  return str;
};

export const format_dd_mm_yyyy_hh_mm = date => {
  if (isNullOrUndefined(date)) {
    return '';
  }
  return moment(date).format('DD/MM/YYYY HH:mm');
};
export const format_dd_mm_yy = date => {
  return date ? moment(date).format('DD/MM/YYYY') : '';
};
export const format_mm_dd_yy = date => {
  return moment(date).format('MM/DD/YYYY');
};
export const format_mm_dd_hh_yy_mm_ss = date => {
  return moment(date).format('MM/DD/YYYY HH:mm:ss');
};
export const format_yy_mm_mm_dd_hh = date => {
  return moment(date).format('HH:mm DD/MM/YYYY');
};
export const formatDate = (date, format) => {
  return moment(date).format(format);
};

export const format_yy_mm_dd = 'YYYY-MM-DD';
export const arrayIsEmpty = array => {
  if (!Array.isArray(array)) {
    return true;
  }
  if (array.length === 0) {
    return true;
  }
  return false;
};
export const checkIsEmpty = text => {
  if (text?.length === 0 || text === undefined || text === null) {
    return true;
  }
  return false;
};
export function checkIsBefore(date1, date2) {
  return moment(date1).isBefore(date2);
}
export function checkIsAfter(date1, date2) {
  return moment(date1).isAfter(date2);
}

export function getExtension(filename) {
  var parts = filename.split('.');
  return parts[parts.length - 1];
}

export const splitID = text => {
  return text?.split(';')[0];
};

export const isNullOrUndefined = data => {
  return data === null || data === '' || data === undefined;
};

export const isNullOrEmpty = text => {
  return text === null || text === '';
};

export const checkNotNullAndEmpty = text => {
  if (text?.length !== 0 && text !== null) {
    return true;
  }
  return false;
};

export function byteConverter(bytes, decimals, only) {
  const K_UNIT = 1024;
  const SIZES = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB'];

  if (bytes == 0) {
    return '0 Byte';
  }

  if (only === 'MB') {
    return (bytes / (K_UNIT * K_UNIT)).toFixed(decimals) + ' MB';
  }

  let i = Math.floor(Math.log(bytes) / Math.log(K_UNIT));
  let resp =
    parseFloat((bytes / Math.pow(K_UNIT, i)).toFixed(decimals)) +
    ' ' +
    SIZES[i];

  return resp;
}

export const VersionCompare = (version1, version2) => {
  var regExStrip0 = /(\.0+)+$/;
  var segmentsA = version1.replace(regExStrip0, '').split('.');
  var segmentsB = version2.replace(regExStrip0, '').split('.');

  if (segmentsA > segmentsB) {
    return 1;
  } else if (segmentsA < segmentsB) {
    return -1;
  } else {
    return 0;
  }
};
