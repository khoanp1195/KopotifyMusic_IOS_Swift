const colors = {
  white: '#ffffff',
  black: '#000000',
  orange: '#DBA410',
  red: 'red',
  DarkCyan: '#006885',
  text_grey26: '#262626',
  text_grey_bc: '#BCBCBC'
};

export default colors;
