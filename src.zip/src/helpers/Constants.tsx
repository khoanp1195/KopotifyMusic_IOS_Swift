import {Dimensions} from 'react-native';
const DEV_URL = 'https://papetrolimex.vuthao.com';
const UAT_URL = 'https://papetrolimexuat.vuthao.com';
const MIG_url = 'https://eofficeuat.petrolimexaviation.com.vn'; /// UAT MIG
const LIVE_url = 'https://vnadmsuatportal.vuthao.com'; // LIVE
export const BASE_URL = LIVE_url;
export const RESONSE_STATUS_SUCCESS = 'SUCCESS';
export const RESONSE_STATUS_NONE = 'NONE';
export const RESONSE_STATUS_ERROR = 'ERR';

export const windowWidth = Dimensions.get('window').width;
export const dimensWidth = (width: any) => (width * windowWidth) / 414;
export const windowHeight = Dimensions.get('window').height;
export const dimnensHeight = (height: any) => (height * windowHeight) / 736;
export const FontSize = {
  SMALL1: dimensWidth(12),
  SMALL: dimensWidth(14),
  TEXT15: dimensWidth(15),
  MEDIUM: dimensWidth(16),
  LARGE: dimensWidth(18),
  LARGE_X: dimensWidth(20),
  LARGE_XX: dimensWidth(22),
  LARGE_XXX: dimensWidth(24),
};
export const FontFamily = {
  HERITAGE_BOLD: 'heritage_bold', //fontStyle="normal",fontWeight="800"
  HERITAGE_ITALIC: 'heritage_italic', //fontStyle="italic",fontWeight="400"
  HERITAGE_REGULAR: 'heritage_regular' //fontStyle="normal",fontWeight="400"
}
export enum BarStyle {
  darkContent = 'dark-content',
  lightContent = 'light-content',
}

export const bottomTabName = {
  TrangChu: 'Trang chủ',
  VanBanDen: 'Danh mục',
  VanBanDi: 'Tìm kiếm',
  Tracuu: 'Mục yêu thích',
};
